/*
 *  cufflinks.cpp
 *  Cufflinks
 *
 *  Created by Cole Trapnell on 3/23/09.
 *  Copyright 2009 Cole Trapnell. All rights reserved.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#else
#define PACKAGE_VERSION "INTERNAL"
#endif

#include <stdlib.h>
#include <getopt.h>
#include <string>

#include "common.h"
#include "hits.h"

#include <boost/thread.hpp>

#include "assemble.h"
#include "gtf_tracking.h"

using namespace std;

#if ENABLE_THREADS
const char *short_options = "m:p:s:F:c:I:j:Q:L:G:f:";
#else
const char *short_options = "m:s:F:c:I:j:Q:L:G:f:";
#endif

static struct option long_options[] = {
{"inner-dist-mean",			required_argument,       0,          'm'},
{"inner-dist-stddev",		required_argument,       0,          's'},
{"transcript-score-thresh", required_argument,       0,          't'},
{"min-isoform-fraction",    required_argument,       0,          'F'},
{"min-intron-fraction",    required_argument,       0,          'f'},
{"pre-mrna-fraction",		required_argument,		 0,			 'j'},
{"max-intron-length",		required_argument,		 0,			 'I'},
{"min-map-qual",			required_argument,		 0,			 'Q'},
{"label",					required_argument,		 0,			 'L'},
{"collapse-rounds",         required_argument,		 0,			 'c'},
{"GTF",					    required_argument,		 0,			 'G'},
#if ENABLE_THREADS
{"num-threads",				required_argument,       0,          'p'},
#endif
{0, 0, 0, 0} // terminator
};

void print_usage()
{
	//NOTE: SPACES ONLY, bozo
	fprintf(stderr, "cufflinks v%s\n", PACKAGE_VERSION); 
	fprintf(stderr, "-----------------------------\n"); 
    fprintf(stderr, "Usage:   cufflinks <hits.sam>\n");
	fprintf(stderr, "Options:\n\n");
	fprintf(stderr, "-m/--inner-dist-mean         the average inner distance between mates              [ default:     45 ]\n");
	fprintf(stderr, "-s/--inner-dist-std-dev      the inner distance standard deviation                 [ default:     20 ]\n");
	fprintf(stderr, "-c/--collapse-rounds         rounds of pre-assembly alignment collapse             [ default:      1 ]\n");
	fprintf(stderr, "-F/--min-isoform-fraction    suppress transcripts below this abundance level       [ default:   0.15 ]\n");
	fprintf(stderr, "-f/--min-intron-fraction     Filter spliced alignments below this level            [ default:   0.05 ]\n");
	fprintf(stderr, "-j/--pre-mrna-fraction       suppress intra-intronic transcripts below this level  [ default:   0.15 ]\n");
	fprintf(stderr, "-I/--max-intron-length       ignore alignments with gaps longer than this          [ default: 300000 ]\n");
	fprintf(stderr, "-Q/--min-map-qual            ignore alignments with lower than this mapping qual   [ default:      0 ]\n");
	fprintf(stderr, "-L/--label                   all transcripts have this prefix in their IDs         [ default:   CUFF ]\n");
	fprintf(stderr, "-G/--GTF                     quantitate against reference transcript annotations                      \n");
	
#if ENABLE_THREADS
	fprintf(stderr, "-p/--num-threads             number of threads used during assembly                [ default:      1 ]\n");
#endif
}

int parse_options(int argc, char** argv)
{
    int option_index = 0;
    int next_option;
    do {
        next_option = getopt_long(argc, argv, short_options, long_options, &option_index);
        switch (next_option) {
			case -1:     /* Done with options. */
				break;
			case 'm':
				inner_dist_mean = (uint32_t)parseInt(-200, "-m/--inner-dist-mean arg must be at least -200", print_usage);
				break;
			case 's':
				inner_dist_std_dev = (uint32_t)parseInt(0, "-s/--inner-dist-std-dev arg must be at least 0", print_usage);
				break;
			case 't':
				transcript_score_thresh = parseFloat(-99999999, 0, "-t/--transcript-score-thresh must less than or equal to 0", print_usage);
				break;
			case 'p':
				num_threads = (uint32_t)parseInt(1, "-p/--num-threads arg must be at least 1", print_usage);
				break;
			case 'c':
				pre_collapse_rounds = (uint32_t)parseInt(0, "-c/--collapse-rounds arg must be at least 0", print_usage);
				break;
			case 'F':
				min_isoform_fraction = parseFloat(0, 1.0, "-F/--min-isoform-fraction must be between 0 and 1.0", print_usage);
				break;
			case 'f':
				min_intron_fraction = parseFloat(0, 1.0, "-f/--min-intron-fraction must be between 0 and 1.0", print_usage);
				break;
			case 'I':
				max_intron_length = parseInt(1, "-I/--max-intron-length must be at least 1", print_usage);
				break;
			case 'j':
				pre_mrna_fraction = parseFloat(0, 1.0, "-I/--pre-mrna-fraction must be at least 0", print_usage);
				break;
			case 'Q':
			{
				int min_map_qual = parseInt(0, "-Q/--min-map-qual must be at least 0", print_usage);
				if (min_map_qual > 0)
				{
					long double p = (-1.0 * min_map_qual) / 10.0;
					max_phred_err_prob = pow(10.0L, p);
				}
				else
				{
					max_phred_err_prob = 1.0;
				}
				break;
			}
			case 'L':
			{
				user_label = optarg;
				break;
			}
			case 'G':
			{
				ref_gtf_filename = optarg;
				break;
			}
			default:
				print_usage();
				return 1;
        }
    } while(next_option != -1);
	
	max_inner_dist = inner_dist_mean + 3 * inner_dist_std_dev;
	inner_dist_norm = normal(inner_dist_mean, inner_dist_std_dev);
    //inner_dist_norm = normal(0, inner_dist_std_dev);
	return 0;
}

void driver(FILE* sam_hit_file, FILE* ref_gtf)
{
	ReadTable it;
	RefSequenceTable rt(true, false);
	
	SAMHitFactory hit_factory(it, rt);
	
	BundleFactory bundle_factory(hit_factory, sam_hit_file, ref_gtf);
	
#if ENABLE_THREDS
	boost::thread asm_thread(assemble_hits,
							 bundle_factory);
	asm_thread.join();
#else	
	assemble_hits(bundle_factory);
#endif
	
}

int main(int argc, char** argv)
{
	int parse_ret = parse_options(argc,argv);
    if (parse_ret)
        return parse_ret;
	
    if(optind >= argc)
    {
        print_usage();
        return 1;
    }
	
    string sam_hits_file_name = argv[optind++];
	
    // Open the approppriate files
    FILE* sam_hits_file = fopen(sam_hits_file_name.c_str(), "r");
    if (sam_hits_file == NULL)
    {
        fprintf(stderr, "Error: cannot open SAM file %s for reading\n",
                sam_hits_file_name.c_str());
        exit(1);
    }
	
	srand48(time(NULL));
	
	FILE* ref_gtf = NULL;
	if (ref_gtf_filename != "")
	{
		ref_gtf = fopen(ref_gtf_filename.c_str(), "r");
		if (!ref_gtf)
		{
			fprintf(stderr, "Error: cannot open GTF file %s for reading\n",
					ref_gtf_filename.c_str());
			exit(1);
		}
	}
	
    driver(sam_hits_file, ref_gtf);
	
	return 0;
}
