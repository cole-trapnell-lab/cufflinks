/*
 *  assemble.cpp
 *  cufflinks
 *
 *  Created by Cole Trapnell on 3/23/09.
 *  Copyright 2009 Cole Trapnell. All rights reserved.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <map>
#include <list>
#include <vector>
#include <deque>
#include <iostream>
#include <numeric>

#include <lemon/topology.h>

//#include <lemon/graph_utils.h>
#include <lemon/bipartite_matching.h>

#include <boost/thread.hpp>
#include <boost/ref.hpp>
// DON'T move this, or mystery compiler errors will result. Affects gcc >= 4.1
#include <boost/graph/vector_as_graph.hpp>

#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/depth_first_search.hpp>
#include <boost/graph/visitors.hpp>
#include <boost/graph/graph_traits.hpp>
#include <boost/numeric/ublas/io.hpp>
#include <boost/vector_property_map.hpp>

#include <boost/math/distributions/normal.hpp> // for normal_distribution
using boost::math::normal; // typedef provides default type is double.

#include "transitive_closure.h"

#include "common.h"
#include "assemble.h"
#include "abundances.h"
#include "bundles.h"
#include "filters.h"
#include "genes.h"

using namespace boost;
using namespace std;

struct HitBufBasket
{
	HitBufBasket(int coord, Scaffold* h, DAGNode d)
		: expiration_coord(coord), hit(h), node(d) {}
	int expiration_coord;
	Scaffold* hit;
	DAGNode node;
};

bool right_lt (const HitBufBasket& lhs, 
			   const HitBufBasket& rhs)
{
	return lhs.expiration_coord < rhs.expiration_coord;
}

struct Expired
{
	Expired(int ec) : expiration_coord(ec) {}
	bool operator()(const HitBufBasket& lhs)
	{
		return lhs.expiration_coord <= expiration_coord;
	}
	
	int expiration_coord;
};

enum ConnectState { UNKNOWN, CONNECT, DONT_CONNECT };

template <class CompatibilityMap, class ConnectMap,  class Tag>
struct connect_visitor
	: public base_visitor<connect_visitor<CompatibilityMap, ConnectMap,  Tag> >
{
    typedef Tag event_filter;
    connect_visitor(CompatibilityMap compatibility, ConnectMap connect, DAGNode t) 
		: _connect(connect),_compatibility(compatibility), _target(t) { }
	
    template <class Vertex, class Graph>
    void operator()(Vertex u, const Graph& g)
	{
		typedef graph_traits<Graph> GraphTraits;
		
		typename GraphTraits::adjacency_iterator v, vend;
		
		if (_compatibility[u] == true)
		{
			for (tie(v,vend) = adjacent_vertices(u, g); v != vend; ++v)
			{
				if (_compatibility[*v])
				{
					//fprintf(stderr, "Avoiding a redundant edge from %d to %d\n", u, *v);
					_connect[u] = DONT_CONNECT;
					return;
				}
			}
			
			// If we get here, u is compatible with the target, but has no
			// compatible successors, so it's safe to add the edge after the DFS
			_connect[u] = CONNECT;
		}
		else
		{
			_connect[u] = DONT_CONNECT;
		}
		//put(_compat, v, compatible);
    }
	
    ConnectMap _connect;
	CompatibilityMap _compatibility;
	DAGNode _target;
};

void find_path(const DAG& bundle_dag,
			   const adjacency_list<>& TC,
			   const DAGNode& source,
			   const DAGNode& target,
			   vector<DAGNode>& path)
{
	if (source == target)
		return;
	bool done = false;
	DAGNode curr = source;
	while(!done)
	{
		graph_traits<DAG>::adjacency_iterator i, iend;
		for (tie(i,iend) = adjacent_vertices(curr, bundle_dag); i != iend; ++i)
		{
			DAGNode I = *i;
			pair<adjacency_list<>::edge_descriptor, bool> p;
			p = edge(I, target, TC);
			if (p.second)
			{
				path.push_back(*i);
				curr = *i;
				break;
			}
			if (*i == target)
			{
				path.push_back(*i);
				done = true;
				break;
			}
		}
	}
}

void extend_chains_to_paths(const DAG& bundle_dag,
							vector<vector<DAGNode> >& chains,
							adjacency_list<>& TC,
							DAGNode source,
							DAGNode sink,
							vector<vector<DAGNode> >& paths)
{	
	//Extend each chain to paths
	for(size_t c = 0; c < chains.size(); ++c)
	{
		vector<DAGNode>& chain = chains[c];
		assert (!chain.empty());
		reverse(chain.begin(), chain.end());
		vector<DAGNode> path;
		find_path(bundle_dag, TC, source, chain[0], path);
		for (size_t n = 1; n < chain.size(); ++n)
		{
			assert (path.back() == chain[n - 1]);
			DAGNode last = chain[n-1];
			DAGNode next = chain[n];
			find_path(bundle_dag, TC, last, next, path);
		}
		find_path(bundle_dag, TC, chain.back(), sink, path);
		assert (path.back() == sink);
		path.pop_back();
		paths.push_back(path);
	}
}

template <class CompatibilityMap, class ConnectMap, class Tag>
connect_visitor<CompatibilityMap, ConnectMap, Tag>
record_connections(CompatibilityMap compatibility, 
				   ConnectMap connect, 
				   DAGNode target, 
				   Tag) 
{
    return connect_visitor<CompatibilityMap, ConnectMap, Tag> (compatibility, connect, target);
}



void guess_strand(int bundle_origin, 
				  const vector<Scaffold>& hits,
				  vector<uint8_t>& strand_guess)
{
	
	for (size_t i = 0; i < hits.size(); ++i)
	{
		if (hits[i].strand() == CUFF_STRAND_UNKNOWN)
			continue;
				
		for (int K = hits[i].left(); K < hits[i].right(); ++K)
			strand_guess[K - bundle_origin] |= hits[i].strand();

	}	
}

CuffStrand guess_strand_for_interval(const vector<uint8_t>& strand_guess, 
									 int left, 
									 int right)
{
	uint8_t guess = CUFF_STRAND_UNKNOWN;
	
	for (int i = left; i < right; ++i)
	{
		if (guess == CUFF_BOTH)
			return (CuffStrand)guess;
		guess |= strand_guess[i];
	}
	return (CuffStrand)guess;
}


long long weight_of_merge(Scaffold& lhs, 
						  Scaffold& rhs, 
						  double source_psi,
						  double target_psi)
{
	//double expected_cov_diff = max(1.0, 0.1 * (source_doc + target_doc));
	//normal cov_norm(0, expected_cov_diff);
	
	normal cov_test_norm(0, 1.0);

	double score = 0.0;
	
	// HACK: This early breakout prevents spliced reads that cross exactly one
	// intron from being matched up if they both cross the same intron.
	// Otherwise, we get phasing problems, as introns aren't matched up long 
	// distance.  Ugh..
	if (Scaffold::overlap_in_genome(lhs, rhs, 0))
	{
		bool lh_intron = lhs.has_intron();
		bool rh_intron = rhs.has_intron();
		
		if (lh_intron && rh_intron)
		{
			vector<pair<int, int> > lh_gaps = lhs.gaps();
			vector<pair<int, int> > rh_gaps = rhs.gaps();
			if (lh_gaps.size() == 1 && lh_gaps == rh_gaps)
				return 999999999;
		}

		//return 999999999;
	}
//	if (source_psi < 1 || target_psi < 1)
//	{
//		int a =4;
//	}
	if (source_psi > 0 && target_psi > 0 )
	{
		double test_stat = log(1.0 - abs(source_psi - target_psi));
		score = test_stat;
		assert (score <= 0.0);
	}
	else
	{
		return 999999999;
	}
	
	assert (score <= 0.0);
	if (score >= -1e-6)
		score = -1e-6;
	int weight = (int)(score * -1e6);
	
	//assert (a_scaff != b_scaff);
//#if ASM_VERBOSE
//	if (lh_intron && rh_intron)
//		fprintf(stderr, "Score between reads (%lf, %lf: %lf : %lf) = %d, distance = %d\n", source_doc, target_doc, cov_stat, cov_score, weight, rhs.left() - lhs.right());
//#endif
	return weight;
	
}

void strict_containment_collapse(vector<Scaffold>& scaffolds)
{
	vector<char> contained_by_somebody(scaffolds.size(),0);
	for (size_t i = 0; i < scaffolds.size(); ++i)
	{
		for (size_t j = 0; j < scaffolds.size(); ++j)
		{
			if (i == j)
				continue;
			if (scaffolds[i].strictly_contains(scaffolds[j]))
			{
				if (scaffolds[j].strictly_contains(scaffolds[i]) && i < j)
					continue; // shouldn't happen
				contained_by_somebody[j] = true;
			}
		}
	}
	
	vector<Scaffold> merged_scaffolds;
	for (size_t i = 0; i < scaffolds.size(); ++i)
	{
		if (!contained_by_somebody[i])
		{
			merged_scaffolds.push_back(scaffolds[i]);
		}
	}
	
	scaffolds = merged_scaffolds;
}

template<class Matcher>
void make_chains_from_matching(const ReachGraph& bp, 
							   const Matcher& matcher,
							   vector<vector<DAGNode> >& chains)
{
	// Make chains out of the matching
	ReachGraph::ANodeMap<ReachGraph::UEdge> matched_a_nodes(bp);
	matcher.aMatching(matched_a_nodes);
	
	ReachGraph::BNodeMap<ReachGraph::UEdge> matched_b_nodes(bp);
	matcher.bMatching(matched_b_nodes);
	
	set<ReachGraph::ANode> chain_heads;
	
	for (ReachGraph::ANodeIt i(bp); i!=lemon::INVALID; ++i)
	{
		int a_id = bp.aNodeId(i);
		ReachGraph::ANode a = bp.nodeFromANodeId(a_id);
		if (matched_a_nodes[a] == lemon::INVALID)
			chain_heads.insert(bp.nodeFromANodeId(bp.aNodeId(i)));
	}
	
	for (set<ReachGraph::ANode>::iterator i = chain_heads.begin();
		 i != chain_heads.end();
		 ++i)
	{
		vector<DAGNode> chain;
		ReachGraph::ANode n = *i;
		chain.push_back(bp.aNodeId(*i));
		while(true)
		{
			//int a_id = bp.aNodeId(n);
			int b_id = bp.bNodeId(n);
			
			ReachGraph::BNode b = bp.nodeFromBNodeId(b_id);
			
			if (matched_b_nodes[b] == lemon::INVALID)
			{
				break;
			}
			else
			{
				ReachGraph::ANode a_match_to_b = bp.source(matched_b_nodes[b]);
				chain.push_back(bp.aNodeId(a_match_to_b));
				n = a_match_to_b;
			}
		}
		chains.push_back(chain);
	}
	assert (chains.size() == chain_heads.size());
	
}


void approximate_match_collapse(vector<Scaffold>& scaffolds,
								double olap_fraction,
								int num_rounds)
{
	
	typedef lemon::SmartBpUGraph ContainmentGraph;
	normal norm(0, 0.1);
	bool performed_collapse = false;
	
	sort (scaffolds.begin(), scaffolds.end(), scaff_lt);
	
	while (num_rounds-- > 0)
	{
		
#if ASM_VERBOSE
		fprintf(stderr, "\tStarting new collapse round\n");
#endif
		
		// Remove identical or strictly contained elements
		size_t original_size = scaffolds.size();
		//strict_containment_collapse(scaffolds);
		size_t prelim_collapse_size = scaffolds.size();
#if ASM_VERBOSE
		fprintf (stderr, "\tPreliminary collapse had %lu scaffolds, left %lu scaffolds\n", original_size, prelim_collapse_size);
#endif
		if (original_size != prelim_collapse_size)
		{
			performed_collapse = true;
		}
		
		ContainmentGraph containment;
		//ReachGraph::UEdgeMap<long long> weights(containment);
		
		typedef pair<ContainmentGraph::ANode, ContainmentGraph::BNode> NodePair;
		vector<NodePair> node_ids;
		vector<size_t> A_to_scaff(scaffolds.size());
		vector<size_t> B_to_scaff(scaffolds.size());
		
		for (size_t n = 0; n < scaffolds.size(); ++n)
		{
			NodePair p = make_pair(containment.addANode(),
								   containment.addBNode());
			node_ids.push_back(p);
			A_to_scaff[containment.aNodeId(p.first)] = n;
			B_to_scaff[containment.bNodeId(p.second)] = n;
		}
		
		bool will_perform_collapse = false;
		for (size_t i = 0; i < scaffolds.size(); ++i)
		{
			for (size_t j = i; j < scaffolds.size(); ++j)
			{
				if (i == j)
					continue;
				
				if (Scaffold::overlap_in_genome(scaffolds[i], scaffolds[j], 0) &&
					Scaffold::compatible(scaffolds[i], scaffolds[j], true))
				{
					int left_diff = abs(scaffolds[i].left() - scaffolds[j].left());
					int right_diff = abs(scaffolds[i].right() - scaffolds[j].right());
					int larger_length = max(scaffolds[i].length(), scaffolds[j].length());
					if ((float)(left_diff + right_diff)/(float)larger_length <= olap_fraction)
					{

						const NodePair& nj = node_ids[j];
						const NodePair& ni = node_ids[i];
						assert (nj.first != ni.second);
						
						will_perform_collapse = true;
						ContainmentGraph::UEdge e = containment.addEdge(nj.first,
																		ni.second);	
					}
				}
			}
		}
		
		if (will_perform_collapse == false)
			return;
		
		lemon::MaxBipartiteMatching<ReachGraph>  matcher(containment);
		
		matcher.run();

		
		ContainmentGraph::UEdgeMap<bool> matched_edges(containment);
		vector<char> keep_scaffold(scaffolds.size(), 1);
		matcher.matching(matched_edges);
		
		vector<Scaffold> merged_scaffolds;
		
		vector<vector<DAGNode> > chains;
		
		make_chains_from_matching(containment,matcher, chains);
		for (size_t i = 0; i < chains.size(); ++i)
		{
			vector<Scaffold> chain;
			for (size_t j = 0; j < chains[i].size(); ++j)
			{
				chain.push_back(scaffolds[chains[i][j]]);				
			}
			merged_scaffolds.push_back(Scaffold(chain));
		}
		
		sort (merged_scaffolds.begin(), merged_scaffolds.end(), scaff_lt);
		scaffolds = merged_scaffolds;
		performed_collapse = true;
	}
	return;
}

bool collapse_contained_scaffolds(vector<Scaffold>& scaffolds)
{
	// The containment graph is a bipartite graph with an edge (u,v) when
	// u is (not necessarily properly) contained in v and is the two are
	// compatible.
	typedef lemon::SmartBpUGraph ContainmentGraph;
	normal norm(0, 0.1);
	bool performed_collapse = false;
	//sort (scaffolds.begin(), scaffolds.end(), scaff_lt);
	
	while (true)
	{
		
#if ASM_VERBOSE
		fprintf(stderr, "\tStarting new collapse round\n");
#endif
				
		// Remove identical or strictly contained elements
		size_t original_size = scaffolds.size();
		strict_containment_collapse(scaffolds);
		size_t prelim_collapse_size = scaffolds.size();
#if ASM_VERBOSE
		fprintf (stderr, "\tPreliminary collapse had %lu scaffolds, left %lu scaffolds\n", original_size, prelim_collapse_size);
#endif
		if (original_size != prelim_collapse_size)
		{
			performed_collapse = true;
		}
		
		ContainmentGraph containment;
		//ReachGraph::UEdgeMap<long long> weights(containment);
		
		typedef pair<ContainmentGraph::ANode, ContainmentGraph::BNode> NodePair;
		vector<NodePair> node_ids;
		vector<size_t> A_to_scaff(scaffolds.size());
		vector<size_t> B_to_scaff(scaffolds.size());
		
		for (size_t n = 0; n < scaffolds.size(); ++n)
		{
			NodePair p = make_pair(containment.addANode(),
								   containment.addBNode());
			node_ids.push_back(p);
			A_to_scaff[containment.aNodeId(p.first)] = n;
			B_to_scaff[containment.bNodeId(p.second)] = n;
		}
		
		bool will_perform_collapse = false;
		for (size_t i = 0; i < scaffolds.size(); ++i)
		{
			for (size_t j = 0; j < scaffolds.size(); ++j)
			{
				if (i == j)
					continue;

				if (scaffolds[i].contains(scaffolds[j]) &&
					Scaffold::compatible(scaffolds[i], scaffolds[j], true))
				{
					// To gaurd against the identity collapse, which won't 
					// necessary reduce the total number of scaffolds.
					if (scaffolds[j].contains(scaffolds[i]) && i < j)
						continue;
					const NodePair& nj = node_ids[j];
					const NodePair& ni = node_ids[i];
					assert (nj.first != ni.second);
										
					will_perform_collapse = true;
					ContainmentGraph::UEdge e = containment.addEdge(nj.first,
																	ni.second);						

				}
			}
		}
		
		if (will_perform_collapse == false)
			return performed_collapse;
		
		lemon::MaxBipartiteMatching<ReachGraph>  matcher(containment);

#if ASM_VERBOSE
		
		fprintf(stderr, "\tContainment graph has %d nodes, %d edges\n", containment.aNodeNum(), containment.uEdgeNum());
		fprintf(stderr, "\tFinding a maximum matching to collapse scaffolds\n");
#endif
		matcher.run();
#if ASM_VERBOSE
		fprintf(stderr, "\t\tWill collapse %d scaffolds\n", matcher.matchingSize());
#endif
		
		ContainmentGraph::UEdgeMap<bool> matched_edges(containment);
		vector<char> keep_scaffold(scaffolds.size(), 1);
		matcher.matching(matched_edges);
		
		vector<Scaffold> merged_scaffolds;
		
		vector<vector<DAGNode> > chains;
		
		make_chains_from_matching(containment,matcher, chains);
		for (size_t i = 0; i < chains.size(); ++i)
		{
			vector<Scaffold> chain;
			for (size_t j = 0; j < chains[i].size(); ++j)
			{
				chain.push_back(scaffolds[chains[i][j]]);
			}
			merged_scaffolds.push_back(Scaffold(chain));
		}

#if ASM_VERBOSE
		fprintf (stderr, "\t\tpre = %d, post = %d\n", (int)scaffolds.size(), (int)merged_scaffolds.size());
#endif
		sort (merged_scaffolds.begin(), merged_scaffolds.end(), scaff_lt);
		scaffolds = merged_scaffolds;
		performed_collapse = true;
	}
	return performed_collapse;
}

typedef property_map<DAG, vertex_name_t>::type HitsForNodeMap;

bool create_dag_for_bundle(vector<Scaffold>& hits,
						   DAG& bundle_dag)
{
	vector<Scaffold>::iterator hi =  hits.begin();
	bool found_compatible_scaffolds = false;
	
	typedef list<HitBufBasket> HitBuf;
	HitBuf hit_buf;
	
	HitsForNodeMap hits_for_node = get(vertex_name, bundle_dag);
	
	while (hi != hits.end())
	{
		int new_left = hi->left();
		int new_right = hi->right();

		HitBufBasket new_basket(new_right, &(*hi), add_vertex(bundle_dag));
		hits_for_node[new_basket.node] = new_basket.hit;
		
		HitBuf::iterator new_end = remove_if(hit_buf.begin(), 
											 hit_buf.end(), 
											 Expired(new_left));
		
		hit_buf.erase(new_end, hit_buf.end());

		// Now check the each hit in the buffer for compatibility with this
		// new one
		
		vector<const Scaffold*> containing_hits;
		
		boost::vector_property_map<bool> c(num_vertices(bundle_dag));
		boost::vector_property_map<ConnectState> connected(num_vertices(bundle_dag));

		for (HitBuf::iterator bi = hit_buf.begin();
			 bi != hit_buf.end();
			 ++bi)
			
		{
			const Scaffold& lhs = *(bi->hit);
			const Scaffold& rhs = *(new_basket.hit);

			assert (lhs.left() <= rhs.left());
			if (!lhs.contains(rhs))
			{
				if (Scaffold::compatible(lhs, rhs, true))
				{
					c[bi->node] = true;
				}
			}
		}
		
		for (HitBuf::iterator bi = hit_buf.begin();
			 bi != hit_buf.end();
			 ++bi)
			
		{
			if (connected[bi->node] == UNKNOWN)
			{
				depth_first_search(bundle_dag,
								   root_vertex(bi->node).
								   visitor(make_dfs_visitor(make_pair(record_connections(c, connected, new_basket.node, on_finish_vertex()), null_visitor()))));
			}
		}
		
		for (HitBuf::iterator bi = hit_buf.begin();
			 bi != hit_buf.end();
			 ++bi)
		{
			if (connected[bi->node] == CONNECT)
			{ 
				add_edge(bi->node, new_basket.node, bundle_dag);
				found_compatible_scaffolds = true;
			}
		}
		
		hit_buf.push_back(new_basket);
		
		++hi;
	}
	
	vector<bool> has_parent(num_vertices(bundle_dag), false);
	vector<bool> has_child (num_vertices(bundle_dag), false);
	
	graph_traits < DAG >::vertex_iterator u, uend;
	for (tie(u, uend) = vertices(bundle_dag); u != uend; ++u)
	{
		graph_traits < DAG >::adjacency_iterator v, vend;
		for (tie(v,vend) = adjacent_vertices(*u, bundle_dag); v != vend; ++v)
		{
			DAGNode U = *u;
			DAGNode V = *v;
			has_parent[V] = true;
			has_child[U] = true;
		}
	}
	
#ifdef DEBUG
	set<const Scaffold*> introns;
#endif
	for (size_t i = 0; i < num_vertices(bundle_dag); ++i)
	{
		if (has_child[i])
			continue;
		const Scaffold* hit_i = hits_for_node[i];

		for (size_t j = 0; j < num_vertices(bundle_dag); ++j)
		{
			if (has_parent[j])
				continue;
			const Scaffold* hit_j = hits_for_node[j];
			if (hit_i->right() < hit_j->left() &&
				hit_j->left() - hit_i->right() < olap_radius)
			{
				add_edge(i, j, bundle_dag);
			}
		}
	}
	
	return found_compatible_scaffolds;
}

inline bool partial_scaffold(const Scaffold& scaff)
{
	return scaff.has_unknown();
}


typedef map<DAGNode, pair<int, int> > DagToBp;
void reachability_graph(DAG& dag, 
						DAGNode src,
						DAGNode sink,
						ReachGraph& reach_graph,
						vector<ReachGraph::BNode> b_to_a,
						DagToBp& dag_to_bp,
						const adjacency_list<>& TC,
						const vector<bool>& scaffold_mask)
{	
	//typedef graph_traits<DAG>::vertex_descriptor Vertex;
	HitsForNodeMap hits_for_node = get(vertex_name, dag);
	
	//fprintf (stdout, "\tclosure edges:\t\t\t\%d\n", num_edges(TC));
	graph_traits < adjacency_list<> >::vertex_iterator v, vend;
	
	b_to_a.resize(num_vertices(TC));
	
	for (tie(v, vend) = vertices(TC); v != vend; ++v)
	{
		DagToBp::iterator itr = dag_to_bp.find(*v);
		if (itr == dag_to_bp.end())
		{
			ReachGraph::ANode A = reach_graph.addANode();
			int a = reach_graph.aNodeId(A);
			
			ReachGraph::BNode B = reach_graph.addBNode();
			int b = reach_graph.bNodeId(B);
			b_to_a[b] = A;
			dag_to_bp[*v] = make_pair(a, b);
			
		}
	}
	
	//size_t node_size = num_vertices(TC) * 
	//	(sizeof(ReachGraph::ANode) + sizeof(ReachGraph::BNode));
	
	//size_t edge_size = num_edges(TC) * sizeof(ReachGraph::UEdge);
			
	
	reach_graph.reserveEdge(num_edges(TC));
	reach_graph.reserveANode(num_vertices(TC));
	reach_graph.reserveBNode(num_vertices(TC));
	
	graph_traits < adjacency_list<> >::edge_iterator i, end;
	for (tie(i, end) = edges(TC); i != end; ++i)
	{
		int a_id = -1;
		int b_id = -1;
		DAGNode s = source(*i, TC);
		DAGNode t = target(*i, TC);

		DagToBp::iterator itr = dag_to_bp.find(s);
		if (itr == dag_to_bp.end())
		{
			assert (false);
		}
		else
		{
			a_id = itr->second.first;
		}
		
		itr = dag_to_bp.find(t);
		
		if (itr == dag_to_bp.end())
		{
			assert(false);
		}
		else
		{
			b_id = itr->second.second;
		}
		
		if (s == src || t == sink)
			continue;
		
		assert (a_id != -1);
		assert (b_id != -1);
		
		ReachGraph::ANode a_node = reach_graph.nodeFromANodeId(a_id);
		ReachGraph::BNode b_node = reach_graph.nodeFromBNodeId(b_id);
		ReachGraph::ANode a_for_b = b_to_a[b_id];
		
		assert (a_for_b != a_node);
		
		if (scaffold_mask[a_id] && 
			scaffold_mask[b_id])
		{
			reach_graph.addEdge(a_node, 
								b_node);
		}
	}
}

void add_junk_to_scaffold_mask(const vector<Scaffold>& scaffolds,
								  const vector<double>& scaff_doc,
								  vector<bool>& scaffold_mask)
{
	vector<char> contained_by_somebody(scaffolds.size(),0);
	for (size_t i = 0; i < scaffolds.size(); ++i)
	{
		const vector<AugmentedCuffOp>& ops = scaffolds[i].augmented_ops();
		for (size_t j = 0; j < scaffolds.size(); ++j)
		{
			for (size_t k = 0; k < ops.size(); k++)
			{
				if ((ops[k].opcode == CUFF_INTRON ||
					 (ops[k].opcode == CUFF_UNKNOWN && ops[k].genomic_length > max_inner_dist)) &&
					(scaffolds[j].left() > ops[k].g_left() &&  scaffolds[j].right() < ops[k].g_right()))
				{
					double contained_doc = scaff_doc[j];
					double container_doc = scaff_doc[i];
					if (contained_doc / container_doc < 0.1)
					{
#if ASM_VERBOSE
						fprintf(stderr, "Added purported garbage intra-intron read [%d-%d]\n", scaffolds[j].left(), scaffolds[j].right());
#endif
						contained_by_somebody[j] = true;
					}
				}
			}
		}
	}
	
	scaffold_mask = vector<bool>(scaffolds.size(), 0);
	for (size_t i = 0; i < scaffolds.size(); ++i)
	{
		if (contained_by_somebody[i])
			scaffold_mask[i] = true;
	}
}

void add_introns_to_scaffold_mask(const vector<Scaffold>& scaffolds,
								   const vector<double>& scaff_doc,
								   vector<bool>& scaffold_mask)
{	
	scaffold_mask = vector<bool>(scaffolds.size(), 0);
	for (size_t i = 0; i < scaffolds.size(); ++i)
	{
		if (scaffolds[i].has_intron())
			scaffold_mask[i] = true;
	}
}

void add_non_constitutive_to_scaffold_mask(const vector<Scaffold>& scaffolds,
										   const vector<double>& scaff_doc,
										   vector<bool>& scaffold_mask)
{	
	//scaffold_mask = vector<bool>(scaffolds.size(), 0);
	for (size_t i = 0; i < scaffolds.size(); ++i)
	{
		//if (!intron_scaffold_mask[i])
		{
			for (size_t j = 0; j < scaffolds.size(); ++j)
			{
				if (/*intron_scaffold_mask[j] && */
					Scaffold::overlap_in_genome(scaffolds[i], scaffolds[j], 0) &&
					!Scaffold::compatible(scaffolds[i], scaffolds[j], true))
				{
					scaffold_mask[i] = true;
				}
			}
		}
	}
}

void add_weights_to_reachability_graph(ReachGraph& bp,
									   const HitsForNodeMap& hits_for_node,
									   const vector<Scaffold>& hits,
									   const vector<Scaffold>& scaffolds,
									   ReachGraph::UEdgeMap<long long>& weights)
{

	// number of reads of reads spliced in to each scaffold
	vector<double> spliced_in(scaffolds.size(), 0.0);
	
	// number spliced in / length of scaffold
	vector<double> density(scaffolds.size(), 0.0);
	
	// number of reads spliced in to scaffold + those that just overlap it
	//vector<double> overlapping(scaffolds.size(), 0.0);
	
	for (size_t i = 0; i < scaffolds.size(); ++i)
	{
		for (size_t j = 0; j < hits.size(); ++j)
		{
			if (scaffolds[i].contains(hits[j]))
			{
				if (Scaffold::compatible(scaffolds[i],hits[j],true))
				{
					spliced_in[i]++;
				}
				//overlapping[i]++;
			}
		}
		density[i] = spliced_in[i] / scaffolds[i].length();
	}
	
	// percent spliced in = density / (total density of overlapping scaffolds) 
	vector<double> psi(scaffolds.size(), 0.0);
	vector<double> local_density(scaffolds.size(), 0.0);
	for (size_t i = 0; i < scaffolds.size(); ++i)
	{
		double total_density = 0.0;
		int num_overlaps = 0;
		double compatible_density = 0.0;
		for (size_t j = 0; j < scaffolds.size(); ++j)
		{
			if (Scaffold::overlap_in_genome(scaffolds[i],scaffolds[j], 0))
			{
				total_density += density[j];
				num_overlaps++;
				if (Scaffold::compatible(scaffolds[i], scaffolds[j], true))
				{
					compatible_density += density[j];
				}
			}
		}
		if (total_density)
			psi[i] = compatible_density / total_density;
		local_density[i] = compatible_density;
	}
	
//	for (size_t i = 0; i < scaffolds.size(); ++i)
//	{
//		fprintf(stderr, "%d - %d: count = %lf, density = %lf, local = %lf psi = %lf\n", 
//				scaffolds[i].left(),
//				scaffolds[i].right(),
//				spliced_in[i],
//				density[i],
//				local_density[i],
//				psi[i]);
//	}
	
	for (ReachGraph::UEdgeIt i(bp); i!=lemon::INVALID; ++i)
	{
		ReachGraph::ANode a = bp.source(i);
		ReachGraph::BNode b = bp.target(i);
		DAGNode a_dag = bp.aNodeId(a);
		int a_id_for_b = bp.aNodeId(b);
		ReachGraph::ANode a_for_b = bp.nodeFromANodeId(a_id_for_b);
		assert (a_for_b != lemon::INVALID);
		DAGNode b_dag = a_id_for_b;
		
		Scaffold* a_scaff = hits_for_node[a_dag];
		Scaffold* b_scaff = hits_for_node[b_dag];

		size_t aidx = a_scaff - &scaffolds[0];
		size_t bidx = b_scaff - &scaffolds[0];
		
		double a_psi = psi[aidx];
		
		double b_psi = psi[bidx];
		
		
		assert (a_psi != 1.0);
		assert (b_psi != 1.0);
		
		long long weight = weight_of_merge(*a_scaff, 
										   *b_scaff, 
										   a_psi,
										   b_psi);
		
		if (weight < 0)
			weight = 10000000;
		//fprintf(stderr, "Similarity between %d, %d = %.20lf\n", bp.aNodeId(a), a_id_for_b, weight);
		weights[i] = weight;
	}	
}

void make_scaffolds_from_paths(DAG& bundle_dag,
							   const vector<vector<DAGNode> >& paths,
							   vector<Scaffold>& scaffolds)
{
	HitsForNodeMap hits_for_node = get(vertex_name, bundle_dag);
	for (size_t p = 0; p < paths.size(); ++p)
	{
		const vector<DAGNode>& path = paths[p];
		
		vector<Scaffold> path_alignments;
		for (size_t m = 0; m < path.size(); ++m)
		{
			//fprintf(stderr, "%d ", scaff_id);
			path_alignments.push_back(*(hits_for_node[path[m]]));
		}
		//fprintf(stderr,"\n");
		//fprintf(stderr, "\tMerging path %d into scaffold\n", p);
		Scaffold s(path_alignments);
		
		//fprintf(stderr, "PATH %d\n-------------------------------------\n",s.get_id());
		scaffolds.push_back(s);
	}
	sort(scaffolds.begin(), scaffolds.end(), scaff_lt);
}

struct ScaffBelowThresh
{
	ScaffBelowThresh(double thresh) : _thresh(thresh) {}
	bool operator()(const Scaffold& s)
	{
		return s.score()/(double)s.mate_hits().size() < _thresh;
	}
	
	double _thresh;
};

struct WorstMateScoreBelowThresh
{
	WorstMateScoreBelowThresh(double thresh) : _thresh(thresh) {}
	bool operator()(const Scaffold& s)
	{
		return s.worst_mate_score() < _thresh;
	}
	
	double _thresh;
};

struct ScaffHasIntron
{
	ScaffHasIntron(HitsForNodeMap m)
	:_m(m) {}
	bool operator()(const DAGNode& n)
	{
		const Scaffold* s = _m[n];
		if (!s) 
			return false;
		return s->has_intron();
	}
	
	HitsForNodeMap _m;
};

bool remove_improbable_scaffolds(vector<Scaffold>& hits, 
								 vector<const MateHit*>& prev_chaff)
{
	vector<Scaffold>::iterator new_end = remove_if(hits.begin(), hits.end(), ScaffBelowThresh(transcript_score_thresh));
	if (new_end == hits.begin())
	{
		//			for (int S = 0; S < (int)hits.size(); ++S)
		//			{
		//				fprintf(stderr, "SCAFF_%d\t%lf\t%lf\t%lf\n", hits[S].get_id(), hits[S].score(), hits[S].score()/hits[S].mate_hits().size(), hits[S].worst_mate_score());
		//			}
		//fprintf(stderr, "Bundle is garbage!\n");
		return false;
	}
	if (new_end != hits.end())
	{
		vector<const MateHit*> chaff_hits;
		vector<const MateHit*> kept_hits;
		for(vector<Scaffold>::iterator i = hits.begin(); i != new_end; ++i)
			kept_hits.insert(kept_hits.begin(), i->mate_hits().begin(), i->mate_hits().end());
		
		for(vector<Scaffold>::iterator i = new_end; i != hits.end(); ++i)
			chaff_hits.insert(chaff_hits.begin(), i->mate_hits().begin(), i->mate_hits().end());
		
		sort(kept_hits.begin(), kept_hits.end());
		sort(chaff_hits.begin(), chaff_hits.end());
		
		vector<const MateHit*>::iterator ui;
		
		ui = unique(kept_hits.begin(), kept_hits.end());
		kept_hits.erase(ui, kept_hits.end());
		
		ui = unique(chaff_hits.begin(), chaff_hits.end());
		chaff_hits.erase(ui, chaff_hits.end());
		
		
		vector<const MateHit*> recovered_hits;
		
		set_difference(chaff_hits.begin(), chaff_hits.end(),
					   kept_hits.begin(), kept_hits.end(),
					   back_inserter(recovered_hits));
		
		if (prev_chaff == chaff_hits)
		{
			//fprintf(stderr, "Excluding %d hits from scaffold, can't place them\n", (int)chaff_hits.size());
		}
		else
		{
			//fprintf (stderr, "Reclaiming %d alignments from %d low probability assemblies\n", (int)recovered_hits.size(), (int)(hits.end() - new_end));
			
			prev_chaff = chaff_hits;
			hits.erase(new_end, hits.end());
			//for (size_t i = 0; i < recovered_hits.size(); ++i)
			//	hits.push_back(Scaffold(*(recovered_hits[i])));
		}
	}
	sort(hits.begin(), hits.end(), scaff_lt);
	return true;
}

struct ScaffBelowIntronDoc
{
	ScaffBelowIntronDoc(const map<pair<int, int>, int>& docs,
						double doc_thresh)
	: intron_doc(docs), bundle_doc_thresh(doc_thresh) {}
	
	const map<pair<int,int>, int >& intron_doc;
	double bundle_doc_thresh;
	
	bool operator()(const Scaffold& scaff)
	{
		const vector<AugmentedCuffOp>& ops = scaff.augmented_ops();
		for (size_t i = 0; i < ops.size(); ++i)
		{
			if (ops[i].opcode == CUFF_INTRON)
			{
				map<pair<int, int>, int>::const_iterator itr;
				itr = intron_doc.find(make_pair(ops[i].g_left(), ops[i].g_right()));
				assert (itr != intron_doc.end());
				double doc = itr->second;
				//fprintf(stderr, "doc = %f\n", doc);
				if (doc < bundle_doc_thresh)
					return true;
			}
		}
		return false;
	}
};	

void fill_gaps(vector<Scaffold>& scaffolds, int fill_size)
{
	for (size_t i = 0; i < scaffolds.size(); ++i)
		scaffolds[i].fill_gaps(fill_size);
}

void holdout_transitivity_hazards(vector<Scaffold>& hits, 
								  vector<Scaffold>& hazards)
{
	vector<pair<int,int> > introns;
	for (size_t i = 0; i < hits.size(); ++i)
	{
		const vector<AugmentedCuffOp>& ops = hits[i].augmented_ops();
		for (size_t j = 0; j < ops.size(); ++j)
		{
			const AugmentedCuffOp& op = ops[j];
			if (op.opcode == CUFF_INTRON)
				introns.push_back(make_pair(op.g_left(), op.g_right()));
		}
	}

	sort(introns.begin(), introns.end());
	vector<pair<int, int> >::iterator new_end = unique(introns.begin(), 
													   introns.end());
	introns.erase(new_end, introns.end());
	
	vector<pair<int, int> > evil_introns;
	for (size_t i = 0; i < introns.size(); ++i)
	{
		for (size_t j = i + 1; j < introns.size(); ++j)
		{
			if (overlap_in_genome(introns[i].first, introns[i].second,
								  introns[j].first, introns[j].second))
			{
				{
					evil_introns.push_back(introns[i]);
					evil_introns.push_back(introns[j]);
				}
			}
		}
	}
	
	sort(evil_introns.begin(), evil_introns.end());
	new_end = unique(evil_introns.begin(), evil_introns.end());
	evil_introns.erase(new_end, evil_introns.end());
	
	vector<Scaffold> filtered_hits;
	for (size_t i = 0; i < hits.size(); ++i)
	{
		bool overlaps_evil_intron = false;
		const vector<AugmentedCuffOp>& ops = hits[i].augmented_ops();
		for (size_t j = 0; j < ops.size(); ++j)
		{
			const AugmentedCuffOp& op = ops[j];
			if (op.opcode == CUFF_UNKNOWN)
			{
				for (size_t k = 0; k < evil_introns.size(); ++k)
				{
					
					if (overlap_in_genome(op.g_left(), op.g_right(),
										  evil_introns[k].first, evil_introns[k].second))
					{
						overlaps_evil_intron = true;
//						int left_diff = abs(op.g_left() - evil_introns[j].first);
//						int right_diff = abs(op.g_right() - evil_introns[j].second);
//						if (left_diff + right_diff > max_inner_dist)
//						{
//							overlaps_evil_intron = true;
//							break;
//						}
					}
				}				  
			}
		}
		if (overlaps_evil_intron)
		{
			hazards.push_back(hits[i]);
		}	
		else
		{
			filtered_hits.push_back(hits[i]);
		}
	}
	
#if ASM_VERBOSE
	fprintf(stderr, "Held out %lu scaffolds as transitivity hazards\n", hazards.size());
#endif
	hits = filtered_hits;
}


bool make_scaffolds(int bundle_left,
					int bundle_length,
					vector<Scaffold>& hits,
					vector<Scaffold>& scaffolds)
{
	if (hits.empty())
		return true;

	int intron_hits = 0;
	for (size_t i = 0; i < hits.size(); ++i)
	{
		if (hits[i].has_intron())
		{
			intron_hits++;
		}
	}
	
	if (!intron_hits)
	{
#if ASM_VERBOSE
		fprintf(stderr, "No introns in bundle, collapsing all hits to single transcript\n");
#endif
		scaffolds.push_back(Scaffold(hits));
		fill_gaps(scaffolds, 2 * olap_radius);
	}
	else
	{
#if ASM_VERBOSE
		fprintf(stderr, "Bundle has %d spliced reads\n", intron_hits);
#endif
#if ASM_VERBOSE
		FILE* f_verbose = stderr;
#endif

		vector<Scaffold> hazards;
		holdout_transitivity_hazards(hits, hazards);
		
		vector<Scaffold> orig_hits = hits;
		
#if ASM_VERBOSE
		fprintf(f_verbose,"\tPerforming preliminary containment collapse\n");
		size_t pre_hit_collapse_size = hits.size();
#endif
		if (perform_full_collapse)
		{
			collapse_contained_scaffolds(hits);	
		}

		vector<Scaffold> without_unknown;
		for (size_t i = 0; i < hits.size(); ++i)
		{
			if (!hits[i].has_unknown())
			{
				without_unknown.push_back(hits[i]);
			}
		}	
		hits = without_unknown;
		
		//approximate_match_collapse(hits, .05, pre_collapse_rounds);
			
	
#if ASM_VERBOSE
		size_t post_hit_collapse_size = hits.size();
		fprintf(f_verbose,"\tIgnoring %lu strictly contained scaffolds\n", pre_hit_collapse_size - post_hit_collapse_size);
#endif
		
		vector<int> depth_of_coverage(bundle_length,0);
		map<pair<int,int>, int> intron_depth_of_coverage;
		compute_doc(bundle_left, 
					hits, 
					depth_of_coverage, 
					intron_depth_of_coverage,
					false);

		normal norm(0, 0.1);
		
		bool first_round = false;
		//bool first_round = false;
		vector<const MateHit*> prev_chaff;
		while (true)
		{		
			static size_t MAX_BUNDLE_ALIGNMENTS = 0xFFFF;
			
			sort(hits.begin(), hits.end(), scaff_lt);
			
			if (hits.size() >= MAX_BUNDLE_ALIGNMENTS)
			{
#if ASM_VERBOSE
				fprintf(f_verbose, "Warning: bundle too large, skipping assembly\n");
#endif
				return false;
			}
			
			DAG bundle_dag;
			
			if (hits.empty())
				return true;
#if ASM_VERBOSE
			fprintf(f_verbose, "\tCalculating scaffold densities\n");
#endif
			vector<double> scaff_doc;
			record_doc_for_scaffolds(bundle_left, 
									 hits, 
									 depth_of_coverage, 
									 intron_depth_of_coverage,
									 scaff_doc);
#if ASM_VERBOSE
			fprintf(f_verbose, "\tCreating compatibility graph\n");
#endif
			if (!create_dag_for_bundle(hits, bundle_dag))
			{
				//scaffolds = hits;
				//create_dag_for_bundle(hits, bundle_dag, first_round ? -2 : -999999);
				break;
			} 
			
			HitsForNodeMap hits_for_node = get(vertex_name, bundle_dag);
			
			vector<char> has_parent(num_vertices(bundle_dag) + 2, false);
			vector<char> has_child (num_vertices(bundle_dag) + 2, false);
			
			graph_traits < DAG >::vertex_iterator u, uend;
			for (tie(u, uend) = vertices(bundle_dag); u != uend; ++u)
			{
				graph_traits < DAG >::adjacency_iterator v, vend;
				for (tie(v,vend) = adjacent_vertices(*u, bundle_dag); v != vend; ++v)
				{
					DAGNode U = *u;
					DAGNode V = *v;
					has_parent[V] = true;
					has_child[U] = true;
				}
			}
			
			DAGNode source = add_vertex(bundle_dag);
			DAGNode sink = add_vertex(bundle_dag);
			
#ifdef DEBUG
			set<const Scaffold*> introns;
#endif
			for (size_t i = 0; i < num_vertices(bundle_dag); ++i)
			{
				
#ifdef DEBUG
				const Scaffold* hit = hits_for_node[i];
				if (hit && first_round && hit->has_intron())
				{
					//add_edge(source, i, bundle_dag);
					//add_edge(i, sink, bundle_dag);

					introns.insert(hit);
					//fprintf(stderr, "[%d] %d, %d\n", hit->get_id(), hit->left(), hit->right());

				}
#endif
				if (!has_parent[i] && i != sink && i != source)
					add_edge(source, i, bundle_dag);
				
				if (!has_child[i] && i != source && i != sink)
					add_edge(i, sink, bundle_dag);
			}
			
			ReachGraph bp;
			
#if ASM_VERBOSE
			fprintf(f_verbose, "\tConstructing reachability graph\n");
#endif
			vector<ReachGraph::BNode> b_to_a;
			adjacency_list<> TC;
			
			transitive_closure(bundle_dag, TC);
			DagToBp dag_to_bp;
			
			vector<bool> scaffold_mask;

			scaffold_mask = vector<bool>(hits.size(), false);
			add_non_constitutive_to_scaffold_mask(hits, scaff_doc, scaffold_mask);
			reachability_graph(bundle_dag, source, sink,  bp, b_to_a, dag_to_bp, TC, scaffold_mask);
			
			ReachGraph::UEdgeMap<long long> cov_weights(bp);
			add_weights_to_reachability_graph(bp, hits_for_node, orig_hits, hits, cov_weights);				
			
			vector<vector<DAGNode> > chains;
			if (first_round)
			{
#if ASM_VERBOSE
				fprintf(f_verbose, "\tPerforming initial intronic matching\n");
#endif
				typedef lemon::MinCostMaxBipartiteMatching<ReachGraph,ReachGraph::UEdgeMap<long long> > InitialMatcher;
				InitialMatcher init_matcher(bp, cov_weights);
				init_matcher.run();

#if ASM_VERBOSE
				fprintf(f_verbose, "\tConverting matching into chain decomposition\n");
#endif
				make_chains_from_matching<InitialMatcher>(bp, init_matcher, chains);

#if ASM_VERBOSE
				fprintf(f_verbose, "\tConverting matching into chain decomposition\n");
#endif
			}
			else
			{
#if ASM_VERBOSE
				fprintf(f_verbose, "\tPerforming weighted matching\n");
#endif
				typedef lemon::MinCostMaxBipartiteMatching<ReachGraph,ReachGraph::UEdgeMap<long long> > Matcher;
				Matcher matcher(bp, cov_weights);
				matcher.run();
				make_chains_from_matching<Matcher>(bp, matcher, chains);
			}
#if ASM_VERBOSE
			fprintf(f_verbose, "\tFound %d distinct chains\n", (int)chains.size());
#endif		
			vector<vector<DAGNode> > paths;
			extend_chains_to_paths(bundle_dag, chains, TC, source, sink, paths);
			
	#ifdef DEBUG
			set<const Scaffold*> path_introns;
			for (size_t p = 0; p < paths.size(); ++p)
			{
				const vector<DAGNode>& path = paths[p];
				for (size_t m = 0; m < path.size(); ++m)
				{
					const Scaffold* hit = hits_for_node[path[m]];
					if (hit && first_round && hit->has_intron())
					{
						path_introns.insert(hit);
					}
				}
			}
			
			assert (introns == path_introns);
	#endif

#if ASM_VERBOSE
			fprintf(f_verbose, "\tCreating scaffolds for %d paths\n", (int)paths.size());
#endif
			vector<Scaffold> new_scaffs;
			make_scaffolds_from_paths(bundle_dag, paths, new_scaffs);
#if ASM_VERBOSE
			fprintf(f_verbose, "\tCollapsing scaffolds\n");
#endif
			
			collapse_contained_scaffolds(new_scaffs);
			hits = new_scaffs;
			first_round = false;
		}
	
		scaffolds = hits;
		
		// One last collapse attempt...
		vector<Scaffold> new_scaffs = scaffolds;
#if ASM_VERBOSE
		fprintf(stderr, "Performing final collapse round\n");
#endif
		
		//remove_improbable_scaffolds(new_scaffs, prev_chaff);
		fill_gaps(new_scaffs, 2 * olap_radius);
		collapse_contained_scaffolds(new_scaffs);
		sort(new_scaffs.begin(), new_scaffs.end(), scaff_lt);
		scaffolds = new_scaffs;
		
	}
	
	// Cleave the partials at their unknowns to minimize FPKM dilation on  
	// the low end of the expression profile. 
	vector<Scaffold> completes; 
	for (size_t i = 0; i < scaffolds.size(); ++i) 
	{ 
		vector<Scaffold> c; 
		scaffolds[i].get_complete_subscaffolds(c); 
		completes.insert(completes.end(), c.begin(), c.end()); 
	} 
	scaffolds = completes;
	
	for (size_t i = 0; i < scaffolds.size(); ++i)
	{
		//assert(!scaffolds[i].has_unknown());
		
		const vector<const MateHit*>& supporting = scaffolds[i].mate_hits();
		CuffStrand s = CUFF_STRAND_UNKNOWN;
		for (size_t j = 0; j < supporting.size(); ++j)
		{

//			assert (supporting[j]->strand() == CUFF_STRAND_UNKNOWN || 
//					s == supporting[j]->strand());
			if (supporting[j]->strand() != CUFF_STRAND_UNKNOWN)
				s = supporting[j]->strand();
		}
		scaffolds[i].strand(s);
		
//		if (!scaffolds[i].has_intron())
//			scaffolds[i].strand(CUFF_STRAND_UNKNOWN);
	}
	
	return true;
}

void add_non_shadow_scaffs(const vector<Scaffold>& lhs, 
						   const vector<Scaffold>& rhs,
						   vector<Scaffold>& scaffolds,
						   bool include_unknown_strand)
{
	for (size_t i = 0; i < lhs.size(); ++i)
	{
		bool add_to_asm = true;
		if (lhs[i].strand() == CUFF_STRAND_UNKNOWN)
		{
			for (size_t j = 0; j < rhs.size(); ++j)
			{
				if (include_unknown_strand || 
					rhs[j].strand() != CUFF_STRAND_UNKNOWN)
				{
					if (Scaffold::overlap_in_genome(lhs[i], rhs[j], 0) &&
						Scaffold::compatible(lhs[i], rhs[j], true))
					{
						add_to_asm = false;
						break;
					}
				}
			}
		}
		if (add_to_asm)
		{
			scaffolds.push_back(lhs[i]);	
		}
	}
}

bool scaffolds_for_bundle(const HitBundle& bundle, 
						  vector<Scaffold>& scaffolds,
						  BundleStats* stats = NULL)
{
	vector<Scaffold> hits;
	
	for (size_t i = 0; i < bundle.non_redundant_hits().size(); ++i)
	{
		const MateHit& hit = bundle.non_redundant_hits()[i];
		hits.push_back(Scaffold(hit));
	}

	filter_introns(bundle.length(), 
				   bundle.left(), 
				   hits, 
				   min_intron_fraction, 
				   false,
				   true);
	
	vector<uint8_t> strand_guess(bundle.length(), CUFF_STRAND_UNKNOWN);
	guess_strand(bundle.left(),
				 hits,
				 strand_guess);
	
	for (size_t i = 0; i < hits.size(); ++i)
	{
		if (hits[i].strand() == CUFF_STRAND_UNKNOWN)
		{
			uint8_t guess = CUFF_STRAND_UNKNOWN;
			Scaffold& hit = hits[i];
			const vector<AugmentedCuffOp>& ops = hit.augmented_ops();
			for (size_t j = 0; j < ops.size(); ++j)
			{
				const AugmentedCuffOp& op = ops[j];
				if (op.opcode == CUFF_UNKNOWN && op.genomic_length > (int)min_intron_length)
				{
					guess |= guess_strand_for_interval(strand_guess, 
													   hit.left() - bundle.left(),
													   hit.right() - bundle.left());
					
					break;
				}
			}

			if (guess != CUFF_BOTH && guess != CUFF_STRAND_UNKNOWN)
				hits[i].strand((CuffStrand)guess);
			//else
			//	fprintf(stderr, "Unknown strand for pair [%d-%d]\n", hit.left(), hit.right());
		}
	}
	
	vector<Scaffold> fwd_hits, rev_hits;
	bool saw_fwd = false;
	bool saw_rev = false;
	
	for (size_t i = 0; i < hits.size(); ++i)
	{
		const Scaffold& hit = hits[i];
		CuffStrand hs = hit.strand();
		if (hs == CUFF_FWD)
			saw_fwd = true;
		if (hs == CUFF_REV)
			saw_rev = true;
		
		if (hs != CUFF_REV) 
			fwd_hits.push_back(hit);
		if (hs != CUFF_FWD)
			rev_hits.push_back(hit);
	}
	
	{
#if ASM_VERBOSE
		fprintf (stderr, "Filtering forward strand\n");
#endif
		filter_hits(bundle.length(), bundle.left(), fwd_hits);
#if ASM_VERBOSE
		fprintf (stderr, "Filtering reverse strand\n");
#endif
		filter_hits(bundle.length(), bundle.left(), rev_hits);
	}

	vector<Scaffold> fwd_scaffolds;
	vector<Scaffold> rev_scaffolds;
	
	bool assembled_successfully = false;
	
	if (saw_fwd && saw_rev)
	{
#if ASM_VERBOSE
		fprintf (stderr, "Saw both strands, assembling both halves\n");
		fprintf (stderr, "Forward strand:\n");
#endif
		assembled_successfully |= make_scaffolds(bundle.left(), bundle.length(), fwd_hits, fwd_scaffolds);

#if ASM_VERBOSE
		fprintf (stderr, "reverse strand:\n");
#endif
		assembled_successfully |= make_scaffolds(bundle.left(), bundle.length(), rev_hits, rev_scaffolds);
		
		add_non_shadow_scaffs(fwd_scaffolds, rev_scaffolds, scaffolds, true);
		add_non_shadow_scaffs(rev_scaffolds, fwd_scaffolds, scaffolds, false);
	}
	else
	{
		if (saw_fwd || (!saw_fwd && !saw_rev))
		{
#if ASM_VERBOSE
			fprintf (stderr, "Saw forward strand only\n");
#endif
			assembled_successfully |= make_scaffolds(bundle.left(), 
													 bundle.length(), 
													 fwd_hits, 
													 fwd_scaffolds);
			scaffolds.insert(scaffolds.end(),fwd_scaffolds.begin(), fwd_scaffolds.end());
		}
		else
		{
#if ASM_VERBOSE
			fprintf (stderr, "Saw reverse strand only\n");
#endif
			assembled_successfully |= make_scaffolds(bundle.left(), 
													 bundle.length(), 
													 rev_hits, 
													 rev_scaffolds);
			scaffolds.insert(scaffolds.end(),rev_scaffolds.begin(), rev_scaffolds.end());
		}
	}
	
	// Make sure all the reads are accounted for, including the redundant ones...
	for (size_t i = 0; i < scaffolds.size(); ++i)
	{
		scaffolds[i].clear_hits();
		for (size_t j = 0; j < bundle.hits().size(); ++j)
		{
			const MateHit& h = bundle.hits()[j];
			scaffolds[i].add_hit(&h);
		}
	}
	
	sort(scaffolds.begin(), scaffolds.end(), scaff_lt);
	
	return assembled_successfully;
}


//static long double min_abundance = 0.000001;

#if ENABLE_THREADS
mutex out_file_lock;
mutex thread_pool_lock;
int curr_threads = 0;

void decr_pool_count()
{
	thread_pool_lock.lock();
	curr_threads--;
	thread_pool_lock.unlock();	
}
#endif

void genes_in_bundle(const vector<Scaffold>& scaffolds,
					 vector<vector<Scaffold> >& scaffolds_by_gene,
					 bool allow_mixed_strand)
{
	typedef adjacency_list <vecS, vecS, undirectedS> CoExonGraph;
	
	CoExonGraph G;
	for (size_t i = 0; i < scaffolds.size(); ++i)
		add_vertex(G);
	
	for (size_t i = 0; i < scaffolds.size(); ++i)
	{
		const vector<AugmentedCuffOp>& i_ops = scaffolds[i].augmented_ops();
		for (size_t j = i + 1; j < scaffolds.size(); ++j)
		{
			if (!allow_mixed_strand &&
				!Scaffold::strand_agree(scaffolds[i],
										scaffolds[j]))
				continue;
			
			const vector<AugmentedCuffOp>& j_ops = scaffolds[j].augmented_ops();
			for (size_t K = 0; K < i_ops.size(); K++)
			{
				for (size_t L = 0; L < j_ops.size(); L++)
				{
					if (AugmentedCuffOp::overlap_in_genome(i_ops[K], j_ops[L]) &&
						i_ops[K].opcode == CUFF_MATCH &&
						j_ops[L].opcode == CUFF_MATCH)
					{
						add_edge(i, j, G);
						break;
					}
				}
			}
		}
	}
	
	std::vector<int> component(num_vertices(G));
	connected_components(G, &component[0]);

	vector<vector<int> > genes(scaffolds.size());
	for (size_t i = 0; i < scaffolds.size(); ++i)
	{
		genes[component[i]].push_back(i);
	}
	for (size_t i = 0; i < genes.size(); ++i)
	{
		vector<Scaffold> scaffolds_for_gene;
		for (size_t j = 0; j < genes[i].size(); ++j)
		{
			scaffolds_for_gene.push_back(scaffolds[genes[i][j]]);
		}
		if (!scaffolds_for_gene.empty())
			scaffolds_by_gene.push_back(scaffolds_for_gene);
	}
}

void finalize_genes(vector<Scaffold>& scaffolds,
					vector<MateHit>& alignments,
					vector<double>& gammas,
					ublas::matrix<double>& gamma_covariance,
					bool valid_covariance,
					long double map_mass,
					const RefSequenceTable& rt,
					vector<Gene>& genes)
{	
#if ASM_VERBOSE
	fprintf(stderr, "%lu isoforms with %lu abundances\n", scaffolds.size(), gammas.size());
#endif	
	
	if (scaffolds.empty())
		return;
	
	vector<Scaffold> scaffs_above_thresh;
	vector<double> kept_abundances;
	double max_fwd_ab = -1.0;
	double max_rev_ab = -1.0;

	for (size_t s_id = 0; s_id < scaffolds.size(); ++s_id)
	{
		Scaffold& s = scaffolds[s_id];
		if (s.strand() == CUFF_FWD || s.strand() == CUFF_STRAND_UNKNOWN)
		{
			if (gammas[s_id] > max_fwd_ab)
				max_fwd_ab = gammas[s_id];
		}
		if (s.strand() == CUFF_REV || s.strand() == CUFF_STRAND_UNKNOWN)
		{			
			if (gammas[s_id] > max_rev_ab)
				max_rev_ab = gammas[s_id];
		}
	}
	
	vector<bool> keep_scaffold_mask(scaffolds.size(), false);
	int num_kept = 0;
	for (size_t s_id = 0; s_id < scaffolds.size(); ++s_id)
	{
		Scaffold& s = scaffolds[s_id];

		double s_ab = gammas[s_id];
		
		double density_score = (s_ab / (s.strand() == CUFF_FWD ? max_fwd_ab : max_rev_ab));
		
		if (density_score > min_isoform_fraction && !s.augmented_ops().empty())
		{
			keep_scaffold_mask[s_id] = true;
			num_kept++;
			//scaffs_above_thresh.push_back(s);
			//kept_abundances.push_back(s_ab);
		}
	}
	
	ublas::matrix<double> new_cov = ublas::zero_matrix<double>(num_kept,num_kept);
	
	size_t next_cov_row = 0;
	for (size_t s_id = 0; s_id < scaffolds.size(); ++s_id)
	{
		Scaffold& s = scaffolds[s_id];
		
		double s_ab = gammas[s_id];
		
		if (keep_scaffold_mask[s_id])
		{
			keep_scaffold_mask[s_id] = true;
			//num_kept++;
			scaffs_above_thresh.push_back(s);
			kept_abundances.push_back(s_ab);
			size_t next_cov_col = 0;
			for (size_t o_id = 0; o_id < scaffolds.size(); ++o_id)
			{
				if (keep_scaffold_mask[o_id])
				{
					new_cov(next_cov_row,next_cov_col) = gamma_covariance(s_id, o_id);
					next_cov_col++;
				}
			}
			next_cov_row++;
		}
		
	}
	
	scaffolds = scaffs_above_thresh;
	gammas = kept_abundances;
	gamma_covariance = new_cov;
	
	if (scaffolds.empty())
	{
		//fprintf(stderr, "Warning: no isoforms left after junk filtering\n");
		//fprintf(stderr, "Major isoform has abundance %lf\n", major_isoform_ab);
		return;
	}
	
	// Now compute FPKM for the whole gene
	//Scaffold smashed_gene;
	//Scaffold::merge(scaffolds, smashed_gene, false);
	
	vector<Isoform> fwd_isoforms;
	vector<Isoform> rev_isoforms;
	//double fwd_frac = 0.0;
	//double rev_frac = 0.0;
	
	int next_fwd_gene = get_next_gene_id();
	int next_rev_gene = get_next_gene_id();
	
	vector<double> counts;
	calc_isoform_counts(scaffolds,alignments,gammas,counts);
	double total_gene_mass = accumulate(counts.begin(), counts.end(), 0.0);
	
	vector<double> FPKMs;
	calc_isoform_fpkms(scaffolds,map_mass, counts, FPKMs);
	
	vector<double> FPKM_variances;
	calc_isoform_fpkm_variances(total_gene_mass,
								map_mass,
								scaffolds,
								valid_covariance,
								gammas,
								gamma_covariance,
								FPKM_variances);
	
	vector<ConfidenceInterval> FPKM_conf(scaffolds.size(), ConfidenceInterval(0.0, 0.0));
	bool valid_isoform_FPKM = valid_covariance && 
		gamma_covariance.size1() == scaffolds.size() &&
		gamma_covariance.size2() == scaffolds.size();
	calc_isoform_fpkm_conf_intervals(total_gene_mass,
									 map_mass,
									 scaffolds,
									 FPKMs,
									 valid_isoform_FPKM,
									 FPKM_variances,
									 FPKM_conf);

	double fwd_gene_FPKM = 0;
	double rev_gene_FPKM = 0;
	
	for (size_t s_id = 0; s_id < scaffolds.size(); ++s_id)
	{		
		Scaffold& s = scaffolds[s_id];
		double FPKM = FPKMs[s_id];
		if (s.strand() == CUFF_FWD || s.strand() == CUFF_STRAND_UNKNOWN)
		{
			fwd_gene_FPKM += FPKM;
		}
		else
		{
			rev_gene_FPKM += FPKM;
		}
	}
	
	double avg_read_length = 0;
	for (size_t i = 0; i < alignments.size(); ++i)
	{
		if (alignments[i].left_alignment())
			avg_read_length += alignments[i].left_alignment()->read_len(); 
		if (alignments[i].right_alignment())
			avg_read_length += alignments[i].right_alignment()->read_len(); 
	}
	
	avg_read_length /= alignments.size();
	
	for (size_t s_id = 0; s_id < scaffolds.size(); ++s_id)
	{
		Scaffold& s = scaffolds[s_id];
		
		double s_ab = gammas[s_id];
		
		int s_len = s.length();
		
		ConfidenceInterval error_bar;
		if (FPKM_conf.empty())
		{
			error_bar = ConfidenceInterval(0, s.strand() == CUFF_FWD ? fwd_gene_FPKM : rev_gene_FPKM);
			fprintf(stderr, "Warning: no error bars!\n");
		}
		else
		{
			error_bar = FPKM_conf[s_id];
		}
		
		double FPKM = FPKMs[s_id];
		double density_score = (s_ab / (s.strand() == CUFF_FWD ? max_fwd_ab : max_rev_ab));
		double density_per_bp = FPKM;
		
		density_per_bp *= (map_mass / 1000000.0); // yields (mass/(length/1000))
		density_per_bp *= (s_len/ 1000.0);
		density_per_bp /= s_len;
		density_per_bp *= avg_read_length;
		//double density_per_bp = (FPKM * (map_mass / 1000000.0) * 1000.0);
		
#if ASM_VERBOSE
		fprintf(stderr, "Considering isoform with FMI %lf\n", density_score);
#endif
		
		if (density_score > min_isoform_fraction)
		{
			if (s.strand() == CUFF_FWD || s.strand() == CUFF_STRAND_UNKNOWN)
			{
				fwd_isoforms.push_back(Isoform(s,
											   next_fwd_gene,
											   (int)s_id,
											   FPKM, 
											   s_ab,
											   error_bar,
											   density_per_bp, 
											   density_score));
			}
			else
			{
				rev_isoforms.push_back(Isoform(s, 
											   next_rev_gene,
											   (int)s_id,
											   FPKM, 
											   s_ab,
											   error_bar,
											   density_per_bp, 
											   density_score));
			}
		}
	}
	
	if (!fwd_isoforms.empty())
	{
		double gene_FPKM = fwd_gene_FPKM;
		Gene g(fwd_isoforms, gene_FPKM);
		genes.push_back(g);
	}
	if (!rev_isoforms.empty())
	{
		double gene_FPKM = rev_gene_FPKM;
		Gene g(rev_isoforms, gene_FPKM);
		genes.push_back(g);	
	}
}

void quantitate_gene(vector<Scaffold>& scaffolds,
					 const RefSequenceTable& rt,
					 HitBundle& bundle, 
					 long double map_mass,
					 vector<Gene>& genes)
{
	if (scaffolds.empty())
		return;
	
	vector<double> gammas;
	ublas::matrix<double> gamma_covariance;
	
	set<const MateHit*> hits_in_gene_set;
	
	for (size_t i = 0; i < scaffolds.size(); ++i)
	{			
		hits_in_gene_set.insert(scaffolds[i].mate_hits().begin(),
								scaffolds[i].mate_hits().end());
	}
	
	vector<MateHit> hits_in_gene;
	for(set<const MateHit*>::iterator itr = hits_in_gene_set.begin();
		itr != hits_in_gene_set.end();
		++itr)
	{
		hits_in_gene.push_back(**itr);
	}
	
	sort(hits_in_gene.begin(), hits_in_gene.end(), mate_hit_lt);
	
	bool success = calculate_gammas(scaffolds, 
									hits_in_gene, 
									gammas, 
									gamma_covariance);	
	//cerr << gamma_covariance << endl;
	
	finalize_genes(scaffolds,
				   hits_in_gene,
				   gammas,
				   gamma_covariance,
				   success,
				   map_mass,
				   rt,
				   genes);
}

void quantitate_genes(vector<Scaffold>& scaffolds,
					  const RefSequenceTable& rt,
					  HitBundle& bundle, 
					  long double map_mass,
					  vector<Gene>& genes)
{	
	vector<Scaffold> partials;
	vector<Scaffold> completes;
		
	for (size_t i = 0; i < scaffolds.size(); ++i)
	{
		if (scaffolds[i].has_unknown())
		{
			partials.push_back(scaffolds[i]);
		}
		else
		{
			completes.push_back(scaffolds[i]);
		}
	}
	
	scaffolds = completes;
	
	vector<vector<Scaffold> > scaffolds_by_gene;
	genes_in_bundle(scaffolds, scaffolds_by_gene, true);
	
	for (vector<vector<Scaffold> >::iterator itr = scaffolds_by_gene.begin();
		 itr != scaffolds_by_gene.end();
		 ++itr)
	{
#if ASM_VERBOSE
		fprintf(stderr, "Calculating abundances\n");
#endif
		quantitate_gene(*itr,
						rt,
						bundle, 
						map_mass,
						genes);
	}
}

void assemble_bundle(const RefSequenceTable& rt,
					 HitBundle* bundle_ptr, 
					 long double map_mass,
					 FILE* ftranscripts,
					 FILE* fgene_abundances,
					 FILE* ftrans_abundances)
{
	
	HitBundle& bundle = *bundle_ptr;

#if ENABLE_THREADS	
	boost::this_thread::at_thread_exit(decr_pool_count);

	out_file_lock.lock();
#endif
	
//	fprintf(fstats,"%d\t%s\t%d\t%d\t%lu\n",
//			bundle.id(),
//			rt.get_name(bundle.ref_id()),
//			bundle.left(),
//			bundle.right(),
//			bundle.non_redundant_hits().size()
//			);
	
	//fprintf(fbundle_tracking, "OPEN %d\n", bundle.id());
	
#if ENABLE_THREADS
	out_file_lock.unlock();
#endif
	
	vector<Scaffold> scaffolds;
	
	if (ref_gtf_filename != "")
	{
		scaffolds = bundle.ref_scaffolds();
	}
	else 
	{
		bool success = scaffolds_for_bundle(bundle, scaffolds, NULL);
		if (!success)
		{
//#if ENABLE_THREADS
//			out_file_lock.lock();
//#endif
//			fprintf(fbundle_tracking, "CLOSE %d\n", bundle.id());
//#if ENABLE_THREADS
//			out_file_lock.unlock();
//#endif
			delete bundle_ptr;
			return;
		}
	}
	
	vector<Gene> genes;
	quantitate_genes(scaffolds, 
					 rt, 
					 bundle, 
					 map_mass, 
					 genes);

	filter_junk_genes(genes);

#if ENABLE_THREADS	
	out_file_lock.lock();
#endif
	
	size_t num_scaffs_reported = 0;
	for (size_t i = 0; i < genes.size(); ++i)
	{
		const Gene& gene = genes[i];
		const vector<Isoform>& isoforms = genes[i].isoforms();
		for (size_t j = 0; j < isoforms.size(); ++j)
		{
			const Isoform& iso = isoforms[j];
			
			vector<const MateHit*> H(iso.scaffold().mate_hits().size(), 0);
			copy(iso.scaffold().mate_hits().begin(), 
				 iso.scaffold().mate_hits().end(),
				 H.begin());
			
			vector<string> isoform_exon_recs;
							 
			iso.get_gtf(isoform_exon_recs, rt);
			
			for (size_t g = 0; g < isoform_exon_recs.size(); ++g)
			{
				fprintf(ftranscripts, "%s", isoform_exon_recs[g].c_str());
			}
			
			fflush(ftranscripts);
			
			fprintf(ftrans_abundances,"%s\t%d\t%s\t%d\t%d\t%lg\t%lg\t%lg\t%lg\t%lg\t%lg\t%d\n", 
					iso.trans_id().c_str(),
					bundle.id(),
					rt.get_name(bundle.ref_id()),
					iso.scaffold().left(),
					iso.scaffold().right(),
					iso.FPKM(),
					iso.FMI(),
					iso.fraction(),
					iso.confidence().low,
					iso.confidence().high,
					iso.coverage(),
					iso.scaffold().length());
			fflush(ftrans_abundances);
			
			num_scaffs_reported++;
		}
		
		fprintf(fgene_abundances,"%s\t%d\t%s\t%d\t%d\t%lg\n",
				gene.gene_id().c_str(),
				bundle.id(),
				rt.get_name(bundle.ref_id()),
				gene.left(),
				gene.right(),
				gene.FPKM());
		fflush(ftrans_abundances);
	}

	//fprintf(fbundle_tracking, "CLOSE %d\n", bundle.id());
	
	if (ref_gtf_filename != "" && num_scaffs_reported > bundle.ref_scaffolds().size())
	{
		fprintf(stderr, "Error: reported more isoforms than in reference!\n");
		exit(1);
	}
	
#if ENABLE_THREADS
	out_file_lock.unlock();
#endif
	
	delete bundle_ptr;
}

bool assemble_hits(BundleFactory& bundle_factory)
{
	fprintf(stderr, "Counting hits in map\n");
	long double map_mass = get_map_mass(bundle_factory);
	
	bundle_factory.load_ref_rnas();
	
	fprintf(stderr, "\tTotal map density: %Lf\n", map_mass);
	
	srand(time(0));
	
	HitBundle bundle;
	
	int num_bundles = 0;
	vector<size_t> bundle_sizes;
	vector<size_t> nr_bundle_sizes;
	vector<int> bundle_compatible;
	vector<int> bundle_uncollapsible;
	vector<int> bundle_spans;
	
	RefSequenceTable& rt = bundle_factory.hit_factory().ref_table();

	//FILE* fbundle_tracking = fopen("open_bundles", "w");
	
	//FILE* fstats = fopen("bundles.stats", "w");
	FILE* ftrans_abundances = fopen("transcripts.expr", "w");
	fprintf(ftrans_abundances,"trans_id\tbundle_id\tchr\tleft\tright\tFPKM\tFMI\tfrac\tFPKM_conf_lo\tFPKM_conf_hi\tcoverage\tlength\n");
	
	FILE* fgene_abundances = fopen("genes.expr", "w");
	fprintf(fgene_abundances,"gene_id\tbundle_id\tchr\tleft\tright\tFPKM\n");
	FILE* ftranscripts = fopen("transcripts.gtf", "w");

	while(true)
	{
		HitBundle* bundle_ptr = new HitBundle();
		
		if (!bundle_factory.next_bundle(*bundle_ptr))
		{
			delete bundle_ptr;
			break;
		}
		
		HitBundle& bundle = *bundle_ptr;
		
		if (bundle.right() - bundle.left() > 3000000)
		{
			fprintf(stderr, "Warning: large bundle encountered...\n");
		}
		if (bundle.hits().size())
		{
			BundleStats stats;
			num_bundles++;
#if ENABLE_THREADS			
			while(1)
			{
				thread_pool_lock.lock();
				if (curr_threads < num_threads)
				{
					thread_pool_lock.unlock();
					break;
				}
				
				thread_pool_lock.unlock();

				boost::this_thread::sleep(boost::posix_time::milliseconds(5));
				
			}
#endif
			fprintf(stderr, "Processing bundle [ %s:%d-%d ] with %d non-redundant alignments\n", 
					rt.get_name(bundle.ref_id()),
					bundle.left(),
					bundle.right(),
					(int)bundle.non_redundant_hits().size());

#if ENABLE_THREADS			
			thread_pool_lock.lock();
			curr_threads++;
			thread_pool_lock.unlock();

			thread asmbl(assemble_bundle,
						 boost::cref(rt), 
						 bundle_ptr, 
						 map_mass, 
						 ftranscripts, 
						 fgene_abundances,
						 ftrans_abundances
						 );
#else
			assemble_bundle(boost::cref(rt), 
							bundle_ptr, 
							map_mass, 
							ftranscripts,
							fgene_abundances,
							ftrans_abundances);
#endif			

		}
	}

#if ENABLE_THREADS	
	while(1)
	{
		thread_pool_lock.lock();
		if (curr_threads == 0)
		{
			thread_pool_lock.unlock();
			break;
		}
		
		thread_pool_lock.unlock();
		//fprintf(stderr, "waiting to exit\n");
		boost::this_thread::sleep(boost::posix_time::milliseconds(5));
	}
#endif
	
	return true;
}
