#ifndef ABUNDANCES_H
#define ABUNDANCES_H
/*
 *  abundances.h
 *  cufflinks
 *
 *  Created by Cole Trapnell on 4/27/09.
 *  Copyright 2009 Cole Trapnell. All rights reserved.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdint.h>
#include <vector>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/vector.hpp>
#include "hits.h"
#include "scaffolds.h"
#include "bundles.h"

namespace ublas = boost::numeric::ublas;

struct ConfidenceInterval
{
	ConfidenceInterval(double Low = 0.0, double High = 0.0) 
	: low(Low), high(High) {}
	double low;
	double high;
};


bool gamma_map(const vector<Scaffold>& transcripts,
			   const vector<MateHit>& alignments,
			   const vector<int>& collapse_counts,
			   vector<double>& gamma_map_estimate,
			   ublas::matrix<double>& gamma_covariance);

void gamma_mle(const vector<Scaffold>& transcripts,
			   const vector<MateHit>& alignments,
			   const vector<int>& collapse_counts,
			   vector<double>& gammas);


bool calculate_gammas(const vector<Scaffold>& scaffolds,
					  const vector<MateHit>& hits_in_gene,
					  vector<double>& gammas,
					  ublas::matrix<double>& gamma_covariance);


void calc_isoform_counts(const vector<Scaffold>& transcripts,
						 const vector<MateHit>& alignments,
						 const vector<double>& gammas,
						 vector<double>& counts);

void calc_isoform_fpkms(const vector<Scaffold>& transcripts,
						long double map_mass,
						const vector<double>& counts,
						vector<double>& FPKMs);

void calc_isoform_fpkm_variances(double total_gene_mass,
								 long double map_mass,
								 const vector<Scaffold>& transcripts,
								 bool valid_covariance,
								 const vector<double>& gammas,
								 const ublas::matrix<double>& gamma_covariance,
								 vector<double>& variances);

void calc_isoform_fpkm_conf_intervals(double total_gene_mass,
									  long double map_mass,
									  const vector<Scaffold>& transcripts,
									  const vector<double>& FPKMs,
									  bool  valid_isoform_fpkm,
									  const vector<double>& variances,
									  vector<ConfidenceInterval>& FPKM_conf);

void calc_isoform_group_fpkm(const vector<Scaffold>& group_transcripts,
							 long double map_mass,
							 vector<double> group_transcript_counts,
							 double& group_count,
							 double& group_FPKM);

void calc_isoform_group_fpkm_variance(double total_group_mass,
									  long double map_mass,
									  const vector<Scaffold>& group_transcripts,
									  const vector<double>& group_gammas,
									  const ublas::matrix<double>& group_gamma_covariance,
									  double& variance);

double compute_doc(int bundle_origin, 
				   const vector<Scaffold>& scaffolds,
				   vector<int>& depth_of_coverage,
				   map<pair<int, int>, int>& intron_depth_of_coverage,
				   bool exclude_intra_intron);

double major_isoform_intron_doc(map<pair<int, int>, int>& intron_doc);

void record_doc_for_scaffolds(int bundle_origin, 
							  const std::vector<Scaffold>& hits,
							  const std::vector<int>& depth_of_coverage,
							  const std::map<std::pair<int, int>, int>& intron_depth_of_coverage,
							  std::vector<double>& scaff_doc);

void record_doc_for_scaffolds(int bundle_origin, 
							  const std::vector<Scaffold>& hits,
							  const std::vector<int>& depth_of_coverage,
							  std::vector<double>& scaff_doc);

void record_min_doc_for_scaffolds(int bundle_origin, 
								  const std::vector<Scaffold>& hits,
								  const std::vector<int>& depth_of_coverage,
								  const std::map<std::pair<int, int>, int>& intron_depth_of_coverage,
								  std::vector<double>& scaff_doc);


double get_intron_doc(const Scaffold& s,
					  const map<pair<int, int>, int >& intron_depth_of_coverage);

double get_scaffold_doc(int bundle_origin, 
						const Scaffold& s,
						const vector<int>& depth_of_coverage);

double get_scaffold_min_doc(int bundle_origin, 
							const Scaffold& s,
							const vector<int>& depth_of_coverage);

long double get_map_mass(BundleFactory& bundle_factory);

#endif
