/*
 *  cuffdiff.cpp
 *  cufflinks
 *
 *  Created by Cole Trapnell on 10/21/09.
 *  Copyright 2009 Cole Trapnell. All rights reserved.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#else
#define PACKAGE_VERSION "INTERNAL"
#endif


#include <stdlib.h>
#include <getopt.h>
#include <string>
#include <numeric>
#include <cfloat>
#include <iostream>

#include "common.h"
#include "hits.h"
#include "bundles.h"
#include "abundances.h"

#include <boost/thread.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/graph_traits.hpp>
#include <boost/graph/connected_components.hpp>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/matrix_proxy.hpp>
#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/ublas/vector_proxy.hpp>
#include <boost/numeric/ublas/io.hpp>


#include "gtf_tracking.h"


// Need at least this many reads in a locus to do any testing on it
double min_read_count = 1000.0;
double FDR = 0.05; 
using namespace std;
using namespace boost;

#if ENABLE_THREADS
const char *short_options = "m:p:s:F:c:I:j:Q:L:G:";
#else
const char *short_options = "m:s:F:c:I:j:Q:L:G:";
#endif

#define FDR_OPTION 260

static struct option long_options[] = {
{"inner-dist-mean",			required_argument,       0,          'm'},
{"inner-dist-stddev",		required_argument,       0,          's'},
{"transcript-score-thresh", required_argument,       0,          't'},
{"min-isoform-fraction",    required_argument,       0,          'F'},
{"pre-mrna-fraction",		required_argument,		 0,			 'j'},
{"max-intron-length",		required_argument,		 0,			 'I'},
{"min-map-qual",			required_argument,		 0,			 'Q'},
{"label",					required_argument,		 0,			 'L'},
{"min-alignment-count",     required_argument,		 0,			 'c'},
{"GTF",					    required_argument,		 0,			 'G'},
{"FDR",					    required_argument,		 0,			 FDR_OPTION},
#if ENABLE_THREADS
{"num-threads",				required_argument,       0,          'p'},
#endif
{0, 0, 0, 0} // terminator
};

void print_usage()
{
	fprintf(stderr, "cuffdiff v%s\n", PACKAGE_VERSION); 
	fprintf(stderr, "-----------------------------\n"); 
	
	//NOTE: SPACES ONLY, bozo
    fprintf(stderr, "Usage:   cuffdiff <transcripts.gtf> <sample1_hits.sam> <sample2_hits.sam> [... sampleN_hits.sam]\n");
	fprintf(stderr, "Options:\n\n");
	fprintf(stderr, "-m/--inner-dist-mean         the average inner distance between mates              [ default:     45 ]\n");
	fprintf(stderr, "-s/--inner-dist-std-dev      the inner distance standard deviation                 [ default:     20 ]\n");
	fprintf(stderr, "-Q/--min-map-qual            ignore alignments with lower than this mapping qual   [ default:      0 ]\n");
	fprintf(stderr, "-c/--min-alignment-count     minimum number of alignments in a locus for testing   [ default:   1000 ]\n");
	fprintf(stderr, "--FDR						  False discovery rate used in testing   [ default:   0.05 ]\n");
	
#if ENABLE_THREADS
	fprintf(stderr, "-p/--num-threads             number of threads used during assembly                [ default:      1 ]\n");
#endif
}

int parse_options(int argc, char** argv)
{
    int option_index = 0;
    int next_option;
    do {
        next_option = getopt_long(argc, argv, short_options, long_options, &option_index);
        switch (next_option) {
			case -1:     /* Done with options. */
				break;
			case 'm':
				inner_dist_mean = (uint32_t)parseInt(-200, "-m/--inner-dist-mean arg must be at least -200", print_usage);
				break;
			case 'c':
				min_read_count = (uint32_t)parseInt(0, "-c/--min-alignment-count arg must be at least 0", print_usage);
				break;
			case 's':
				inner_dist_std_dev = (uint32_t)parseInt(0, "-s/--inner-dist-std-dev arg must be at least 0", print_usage);
				break;
			case 'p':
				num_threads = (uint32_t)parseInt(1, "-p/--num-threads arg must be at least 1", print_usage);
				break;
			case FDR_OPTION:
				FDR = (double)parseFloat(0.00, 1.00, "--FDR arg must be between 0 and 1", print_usage);
				break;
			case 'Q':
			{
				int min_map_qual = parseInt(0, "-Q/--min-map-qual must be at least 0", print_usage);
				if (min_map_qual > 0)
				{
					long double p = (-1.0 * min_map_qual) / 10.0;
					max_phred_err_prob = pow(10.0L, p);
				}
				else
				{
					max_phred_err_prob = 1.0;
				}
				break;
			}
			case 'G':
			{
				ref_gtf_filename = optarg;
				break;
			}
			default:
				print_usage();
				return 1;
        }
    } while(next_option != -1);
	
	max_inner_dist = inner_dist_mean + 3 * inner_dist_std_dev;
	inner_dist_norm = normal(inner_dist_mean, inner_dist_std_dev);

	return 0;
}

// like a normal bundle factory, except the user must explicitly ask for 
// a range of alignments for the bunde.  NOTE: this factory does NOT seek 
// backwards - it is up to you to ask for monotonically increasing loci
class LocusBundleFactory
{
public:
	LocusBundleFactory(SAMHitFactory& fac, FILE* hfile)
		: sam_hit_fac(fac), hit_file(hfile) {}
	
	bool next_bundle(HitBundle& bundle_out, 
					 RefID ref_id, 
					 int left_boundary, 
					 int right_boundary);
	
	SAMHitFactory& hit_factory() { return sam_hit_fac; } 
	
	void reset() { rewind(hit_file); }
	
private:
	SAMHitFactory sam_hit_fac;
	FILE* hit_file;
};

bool LocusBundleFactory::next_bundle(HitBundle& bundle_out, 
									 RefID ref_id, 
									 int left_boundary, 
									 int right_boundary)
{
	HitBundle bundle = bundle_out;
	
	if (feof(hit_file))
	{
		return false;
	}
	char bwt_buf[2048];
	
	RefID last_ref_id_seen = 0;
	int last_pos_seen = 0;
	
	off_t curr_pos = ftello(hit_file);
	
	
	while (fgets(bwt_buf, 2048, hit_file))
	{
		// Chomp the newline
		char* nl = strrchr(bwt_buf, '\n');
		if (nl) *nl = 0;
		
		shared_ptr<ReadHit> bh(new ReadHit());
		
		if (!sam_hit_fac.get_hit_from_buf(bwt_buf, *bh, false))
		{
			continue;
		}
		
		if (bh->ref_id() == 84696373) // corresponds to SAM "*" under FNV hash. unaligned read record  
			continue;
		
		bool hit_within_boundary = false;
		
		if (bh->ref_id() != ref_id)
		{
			RefSequenceTable& rt = sam_hit_fac.ref_table();
			const char* gtf_name = rt.get_name(ref_id);
			const char* sam_name = rt.get_name(bh->ref_id());
			if (!gtf_name)
			{
				// The GTF name isn't even inthe SAM file, we'll never find
				// records by advancing the SAM.  Give up.  hit_within_boundary
				// will remain false, and we'll break out of the loop and 
				// reset the SAM file pointer
			}
			else
			{
				// the LocusBundleFactory's ref table should be populated with all 
				// values from the SAM
				assert (sam_name); 
				int c = strcmp(gtf_name, sam_name);
				
				if (c > 0)
				{
					// we need to keep advancing the SAM file, to catch up
					// with the GTF file
					continue;
				}
				else
				{
					// else the GTF file is before the SAM file, we'll never find
					// records by advancing the SAM.  Give up.  hit_within_boundary
					// will remain false, and we'll break out of the loop and 
					// reset the SAM file pointer
				}
			}
		}
		else
		{
			if (bh->right() < left_boundary)
				continue;
			
			if (bh->error_prob() > max_phred_err_prob)
				continue;
			
			if (bh->left() <= right_boundary)
				hit_within_boundary = true;
		}
		
		if (hit_within_boundary)
		{
			if (bh->left() < last_pos_seen)
			{
				fprintf(stderr, "Error: this SAM file doesn't appear to be correctly sorted!\n");
				fprintf(stderr, "\tcurrent hit is at %s:%d, last one was at %s:%d\n", 
						sam_hit_fac.ref_table().get_name(bh->ref_id()),
						bh->left(),
						sam_hit_fac.ref_table().get_name(last_ref_id_seen),
						last_pos_seen);
				
				exit(1);
			}
			
			bundle.add_open_hit(bh);
		}
		else
		{
			fseeko(hit_file, curr_pos, SEEK_SET);
			break;
		}
		
		last_ref_id_seen = bh->ref_id();
		last_pos_seen = bh->left();
		
		curr_pos = ftello(hit_file);
	}
	
	bundle.finalize_open_mates();
	bundle_out = bundle;
	bundle_out.finalize();
	assert (!bundle_out.ref_scaffolds().empty());
	return true;
}

void make_sample_bundles(vector<Scaffold>& ref_mrnas,
						 vector<LocusBundleFactory>& bundle_factories,
						 vector<HitBundle*>& locus_bundles)
{
	RefID ref_id = 0;
	int left_boundary = 999999999;
	int right_boundary = -1;
	for (size_t i = 0; i < ref_mrnas.size(); ++i)
	{
		assert (ref_id == 0 || ref_mrnas[i].ref_id());
		ref_id = ref_mrnas[i].ref_id();
		
		if (ref_mrnas[i].left() < left_boundary)
			left_boundary = ref_mrnas[i].left();
		if (ref_mrnas[i].right() > right_boundary)
			right_boundary = ref_mrnas[i].right();
	}
	
	for (size_t i = 0; i < bundle_factories.size(); ++i)
	{
		LocusBundleFactory& fac = bundle_factories[i];
		HitBundle* bundle = new HitBundle;
		for (size_t j = 0; j < ref_mrnas.size(); ++j)
		{
			bundle->add_ref_scaffold(ref_mrnas[j]);
		}
		
		fac.next_bundle(*bundle, ref_id, left_boundary, right_boundary);
		assert (!bundle->ref_scaffolds().empty());
		locus_bundles.push_back(bundle);
	}
}	

struct QuantGroup
{
	QuantGroup() : 
		valid_quant(true), 
		scaffold_idx(-1),
		FPKM(0), 
		FPKM_variance(0), 
		count(0), 
		est_length(0), 
		gamma(0), 
		kappa(0),
		classcode(0){}
	
	bool valid_quant;  // false if the MAP restimation failed for this sample in this locus
	string description; // like "TSSGROUP_001", or "ENSMUST0000567" if only one isoform
	string parent_id; // like "XLOC_000001"
	
	string tss_id; // for individual isoforms only
	
	set<string> gene_names; // like "Myog", for easy grepping.
	
	int scaffold_idx;
	
	// TODO: eliminate locus tag, just build it from chr, left, and right
	string locus_tag; // like "chr1:1000-2000"
	
	vector<string> names;
	vector<string> closest_ref_matches;
	
	set<string> protein_ids;

	string chr;
	int	   left;
	int	   right;
	
	double FPKM;
	double FPKM_variance;
	
	double count;
	double est_length;
	double gamma;
	ublas::matrix<double> gamma_covariance;
	
	double kappa;
	ublas::matrix<double> kappa_covariance;
	
	char classcode;
	
	vector<QuantGroup> sub_quants;
	
};


enum TestStatus {
	NOTEST,  // successful calculation, test not performed
	OK,      // successful numerical calc, test performed
	FAIL     // numerical exception, test not performed
				 }; 

// Stores the differential expression of an isoform or set of isoforms in two
// different samples, along with a significance test statistic for the difference.
struct SampleDifference
{
	SampleDifference() :
		sample_1(-1), 
		sample_2(-1), 
		value_1(0.0),
		value_2(0.0),
		test_stat(0.0),
		tested_group_id(-1),
		test_status(NOTEST),
		significant(false){}
	
	size_t sample_1;
	size_t sample_2;
	
	double value_1;
	double value_2;
	double differential;
	double test_stat;
	double p_value;
	
	size_t tested_group_id; // which scaffolds' FPKMs contribute
	
	string locus_desc;
	set<string> gene_names;
	set<string> protein_ids;
	vector<string> names; // isoforms or tss groups (e.g.) involved in this test
	
	TestStatus test_status;
	bool significant;
};

void get_alignments_from_scaffolds(const vector<Scaffold>& scaffolds,
								   vector<MateHit>& alignments)
{
	set<const MateHit*> hits_in_gene_set;
	
	for (size_t i = 0; i < scaffolds.size(); ++i)
	{			
		hits_in_gene_set.insert(scaffolds[i].mate_hits().begin(),
								scaffolds[i].mate_hits().end());
	}
	
	for(set<const MateHit*>::iterator itr = hits_in_gene_set.begin();
		itr != hits_in_gene_set.end();
		++itr)
	{
		alignments.push_back(**itr);
	}
	
	sort(alignments.begin(), alignments.end(), mate_hit_lt);
}

bool quantitate_transcript_gammas(const vector<Scaffold>& scaffolds,
							const vector<MateHit>& hits_in_gene,
							QuantGroup& quant_group)
{
	int N = scaffolds.size();
	
	vector<double> gammas;
	
	//quant_group.gammas = vector<double>(N, 0.0);
	quant_group.gamma_covariance = ublas::zero_matrix<double>(N,N);
	
	if (hits_in_gene.empty())
		return true;
	
	bool success = calculate_gammas(scaffolds, 
									hits_in_gene, 
									gammas, 
									quant_group.gamma_covariance);
	
	// cerr << quant_group.gamma_covariance << endl;
	
	for (size_t i = 0; i < quant_group.sub_quants.size(); ++i)
	{
		quant_group.sub_quants[i].gamma = gammas[i];
		quant_group.sub_quants[i].est_length = scaffolds[i].length();
	}
	
	return success;
}

// Calculates the gammas for a single loci in multiple samples
void quantitate_locus_gammas(const vector<HitBundle*>& locus_for_samples,
							 vector<bool>& successes,
							 vector<QuantGroup>& quants)
{
	successes = vector<bool>(locus_for_samples.size(), false);
	for (size_t i = 0; i < locus_for_samples.size(); ++i)
	{
		const vector<Scaffold>& scaffolds = locus_for_samples[i]->ref_scaffolds();
		vector<MateHit> alignments;
		get_alignments_from_scaffolds(scaffolds, alignments);
		QuantGroup& quant_group = quants[i];
		quant_group.sub_quants = vector<QuantGroup>(scaffolds.size());
		successes[i] = quantitate_transcript_gammas(scaffolds,
													alignments,
													quant_group);
	}
}

typedef map<string, SampleDifference > SampleDiffs;

struct FPKMContext
{
	FPKMContext(double c, double r, double v, double m)
		: counts(c), FPKM(r), FPKM_variance(v), log_sample_mass(m) {}
	double counts;
	double FPKM;
	double FPKM_variance;
	double log_sample_mass;
};

struct FPKMTracking
{
	string locus_tag;
	char classcode;
	string tss_id; // for individual isoforms only
	set<string> gene_names;
	set<string> protein_ids;
	vector<string> names; // isoforms or tss groups (e.g.) involved in this test
	vector<string> ref_match_ids;
	
	TestStatus test_status;
	
	vector<FPKMContext> fpkm_series;
};

typedef map<string,  FPKMTracking> FPKMTrackingTable;

// This performs a between-group test on an isoform or TSS grouping, on two 
// different samples.
bool test_diffexp(size_t sample1,
				  size_t sample2,
				  size_t transcript_group_id,
				  const FPKMContext& curr,
				  const FPKMContext& prev,
				  SampleDifference& test)
{
	bool performed_test = false;
	if (curr.FPKM > 0.0 && prev.FPKM > 0.0)
	{
		assert (curr.FPKM_variance > 0.0 && prev.FPKM_variance > 0.0);
		double log_curr = log(curr.counts);
		double log_prev = log(prev.counts);
		
		double curr_log_fpkm_var = (curr.FPKM_variance) / (curr.FPKM * curr.FPKM);
		double prev_log_fpkm_var = (prev.FPKM_variance) / (prev.FPKM * prev.FPKM);
		
		//double prev_log_fpkm_var = 1.0 / prev.FPKM_variance;
		//double curr_log_fpkm_var = 1.0 / curr.FPKM_variance;
		
		// Note: this is written a little differently in the supplement, 
		// where the numerator of the tests includes an explicit sum of
		// logs to get the isoform counts in log space.  We have already
		// performed X_g * gamma_j here, so we just take the log of 
		// that product.
		
		double numerator = (log_curr + prev.log_sample_mass - log_prev - curr.log_sample_mass);
		double denominator = sqrt(prev_log_fpkm_var + curr_log_fpkm_var);
		double stat = numerator / denominator;
		
		normal norm;
		double t1, t2;
		if (stat > 0.0)
		{
			t1 = stat;
			t2 = -stat;
		}
		else
		{
			t1 = -stat;
			t2 = stat;
		}
		double tail_1 = cdf(norm, t1);
		double tail_2 = cdf(norm, t2);
		
		double differential;
		if (curr.FPKM == 0.0 && prev.FPKM != 0.0)
		{
			differential = DBL_MAX;
		}
		else
		{
			differential = log(curr.FPKM) - log(prev.FPKM);
		}
		
		double p_value = 1.0 - (tail_1 - tail_2);
			
		//test = SampleDifference(sample1, sample2, prev.FPKM, curr.FPKM, stat, p_value, transcript_group_id);
		test.p_value = p_value;
		test.sample_1 = sample1;
		test.sample_2 = sample2;
		test.differential = differential;
		test.test_stat = stat;
		test.value_1 = prev.FPKM;
		test.value_2 = curr.FPKM;
		test.tested_group_id = transcript_group_id;
		
		performed_test = true;
	}
	else
	{
		if (curr.FPKM > 0.0)
		{
			//test = SampleDifference(sample1, sample2, 0, curr.FPKM, DBL_MAX, 0, transcript_group_id); 
			test.p_value = 0;
			test.sample_1 = sample1;
			test.sample_2 = sample2;
			test.test_stat = DBL_MAX;
			test.value_1 = 0;
			test.value_2 = curr.FPKM;
			test.tested_group_id = transcript_group_id;
			performed_test = true;
		}
		else if (prev.FPKM > 0.0)
		{
			//test = SampleDifference(sample1, sample2, prev.FPKM, 0, -DBL_MAX, 0, transcript_group_id); 
			test.p_value = 0;
			test.sample_1 = sample1;
			test.sample_2 = sample2;
			test.test_stat = -DBL_MAX;
			test.value_1 = prev.FPKM;
			test.value_2 = 0;
			test.tested_group_id = transcript_group_id;
			performed_test = true;
		}
	}	
	
	test.test_status = performed_test ? OK : NOTEST;
	return performed_test;
}

// This performs between-group tests on isoforms or TSS groupings in a single
// locus, on two different samples.
int get_de_tests(size_t curr_sample_idx,
				 const QuantGroup& curr_quant_group,
				 long double curr_mass,
				 size_t prev_sample_idx,
				 const QuantGroup& prev_quant_group,
				 long double prev_mass,
				 SampleDiffs& isoform_de_tests,
				 bool enough_reads)
{
	int total_iso_de_tests = 0;

	assert (curr_quant_group.sub_quants.size() == prev_quant_group.sub_quants.size());
	
	double log_mass_curr = log(curr_mass);
	double log_mass_prev = log(prev_mass);
	
	for (size_t j = 0; j < curr_quant_group.sub_quants.size(); ++j)
	{
		const QuantGroup& curr_jq = curr_quant_group.sub_quants[j];
		const QuantGroup& prev_jq = prev_quant_group.sub_quants[j];
		
		
		double curr = curr_jq.FPKM;
		double prev = prev_jq.FPKM;
		
		double curr_fpkm_var = curr_jq.FPKM_variance;
		double prev_fpkm_var = prev_jq.FPKM_variance;
		
		double curr_counts = curr_jq.count;
		double prev_counts = prev_jq.count;
		
		const string& name = curr_jq.description;
		
		pair<SampleDiffs::iterator, bool> inserted;
		inserted = isoform_de_tests.insert(make_pair(name,SampleDifference())); 
		SampleDifference test;
		FPKMContext r1(curr_counts, curr, curr_fpkm_var, log_mass_curr);
		FPKMContext r2(prev_counts, prev, prev_fpkm_var, log_mass_prev);
		
		test.test_status = FAIL;
		if (curr_quant_group.valid_quant && 
			prev_quant_group.valid_quant)
		{
			if (test_diffexp(curr_sample_idx, prev_sample_idx, j, r1, r2, test))
			{
				total_iso_de_tests++;
			}
			else
			{
				test.test_stat = 0;
				test.p_value = 1.0;
			}
			if (enough_reads) 
				test.test_status = OK;
			else
				test.test_status = NOTEST;
			
		}
		else
		{
			test.test_stat = 0;
			test.test_stat = 1.0;
		}
		
		test.gene_names = curr_jq.gene_names;
		test.protein_ids = curr_jq.protein_ids;
		test.locus_desc = prev_jq.locus_tag;
		test.names = curr_jq.names;
		inserted.first->second = test;
	}

	return total_iso_de_tests;
}

typedef vector<size_t> tss_cluster;

void find_tss_clusters(const vector<HitBundle*>& locus_for_samples,
					   vector<vector<tss_cluster> >& tss_clusters_for_bundles,
					   int tss_cluster_radius = 50)
{
	for (size_t i = 0; i < locus_for_samples.size(); ++i)
	{
		vector<tss_cluster> scaffolds_by_tss;
		
		const vector<Scaffold>& scaffolds = locus_for_samples[i]->ref_scaffolds();
		typedef adjacency_list <vecS, vecS, undirectedS> CoTSSGraph;
		
		CoTSSGraph G;
		vector<pair<int, int> > tss_windows;
		
		for (size_t i = 0; i < scaffolds.size(); ++i)
		{
			add_vertex(G);
			int i_tss_left_edge;
			int i_tss_right_edge;
			
			const vector<AugmentedCuffOp>& i_ops = scaffolds[i].augmented_ops();
			
			if (scaffolds[i].strand() == CUFF_FWD)
			{
				size_t i_fp_ex = 0;
				i_tss_left_edge = i_ops[i_fp_ex].g_left() - tss_cluster_radius;
				i_tss_right_edge = i_tss_left_edge + 2 * tss_cluster_radius;
			}
			else
			{
				size_t i_fp_ex = i_ops.size() - 1;
				i_tss_left_edge = i_ops[i_fp_ex].g_right() - tss_cluster_radius;
				i_tss_right_edge = i_tss_left_edge + 2 * tss_cluster_radius;
			}
			tss_windows.push_back(make_pair(i_tss_left_edge,i_tss_right_edge));
		}
		
		
		for (size_t i = 0; i < scaffolds.size(); ++i)
		{
			for (size_t j = i + 1; j < scaffolds.size(); ++j)
			{
				if (!Scaffold::strand_agree(scaffolds[i],
											scaffolds[j]))
				{
					continue;
				}
				if (::overlap_in_genome(tss_windows[i].first, tss_windows[i].second,
										tss_windows[j].first, tss_windows[j].second))
								  
				{
					add_edge(i, j, G);
				}
			}
		}
		
		std::vector<int> component(num_vertices(G));
		connected_components(G, &component[0]);
		
		vector<vector<size_t> > tss(scaffolds.size());
		for (size_t i = 0; i < scaffolds.size(); ++i)
		{
			tss[component[i]].push_back(i);
		}
		for (size_t i = 0; i < tss.size(); ++i)
		{
			vector<size_t> scaffolds_for_tss;
			for (size_t j = 0; j < tss[i].size(); ++j)
			{
				scaffolds_for_tss.push_back(tss[i][j]);
			}
			if (!scaffolds_for_tss.empty())
				scaffolds_by_tss.push_back(scaffolds_for_tss);
		}
		tss_clusters_for_bundles.push_back(scaffolds_by_tss);
	}
}

void select_gammas(const QuantGroup& quant_group,
				   const vector<bool>& selected,
				   ublas::vector<double>& updated_gammas,
				   ublas::matrix<double>&  updated_gamma_cov)
{
	assert (selected.size() == quant_group.sub_quants.size());
	
	updated_gammas = ublas::vector<double>(quant_group.sub_quants.size(), 0.0);
	updated_gamma_cov = ublas::zero_matrix<double>(quant_group.sub_quants.size(), 
												   quant_group.sub_quants.size());

	
	for (size_t i = 0; i < selected.size(); ++i)
	{
		if (selected[i])
		{
			// then scaffolds[i] has a non-zero abundance, we need to fill
			// that in along with relevant cells from the covariance matrix
			updated_gammas(i) = quant_group.sub_quants[i].gamma;
			for (size_t j = 0; j < selected.size(); ++j)
			{
				if (selected[j])
				{
					updated_gamma_cov(i,j) = quant_group.gamma_covariance(i,j);
				}
			}
		}
	}
}

int next_tss_group_id = 0;

struct Outfiles
{
	vector<FILE*> isoform_de_outfiles;
	vector<FILE*> group_de_outfiles;
	vector<FILE*> gene_de_outfiles;
	vector<FILE*> cds_de_outfiles;
	
	vector<FILE*> diff_splicing_outfiles;
	vector<FILE*> diff_promoter_outfiles;
	vector<FILE*> diff_cds_outfiles;
	
	FILE* isoform_fpkm_tracking_out;
	FILE* tss_group_fpkm_tracking_out;
	FILE* gene_fpkm_tracking_out;
	FILE* cds_fpkm_tracking_out;
};

struct Tests
{
	vector<SampleDiffs> isoform_de_tests;
	vector<SampleDiffs> tss_group_de_tests;
	vector<SampleDiffs> gene_de_tests;
	vector<SampleDiffs> cds_de_tests;
	
	vector<SampleDiffs> diff_splicing_tests; // to be performed on the isoforms of a single tss group
	vector<SampleDiffs> diff_promoter_tests; // to be performed on the tss groups of a single gene
	vector<SampleDiffs> diff_cds_tests; // to be performed on the cds groups of a single gene
};

struct Tracking
{
	FPKMTrackingTable isoform_fpkm_tracking;
	FPKMTrackingTable tss_group_fpkm_tracking;
	FPKMTrackingTable gene_fpkm_tracking;
	FPKMTrackingTable cds_fpkm_tracking;
};

#if ENABLE_THREADS
mutex test_storage_lock; // don't modify the above struct without locking here
mutex thread_pool_lock;
int curr_threads = 0;

void decr_pool_count()
{
	thread_pool_lock.lock();
	curr_threads--;
	thread_pool_lock.unlock();	
}
#endif


// This takes an array of scaffolds and their global abundances, and a vector of 
// indexes specifying a subset of the scaffolds, and computes the global abundances
// for the subset.  scaffolds and member_quants use locus level addressing.
void calc_group_abundance(const vector<Scaffold>& scaffolds,
						  const QuantGroup& member_quants,
						  const vector<size_t>& members,
						  long double sample_mass,
						  QuantGroup& group_quant)
{
	vector<Scaffold> cluster_transcripts;
	vector<double> cluster_counts;
	vector<double> group_gammas(members.size(), 0.0);
	double estimated_length = 0;
	const ublas::matrix<double>& gamma_cov = member_quants.gamma_covariance;
	
	//tss_quant_group.sub_quants = vector<QuantGroup>(bundle_clusters[j].size());
	
	set<string> gene_names;
	set<string> protein_ids;
	
	ublas::matrix<double> group_gamma_cov(members.size(), 
										  members.size());
	for (size_t k = 0; k < members.size(); ++k)
	{
		size_t k_id = members[k];
		const string& gene_name = scaffolds[k_id].annotated_gene_name();
		gene_names.insert(gene_name);
		const string& protein_id = scaffolds[k_id].annotated_protein_id();
		protein_ids.insert(protein_id);
		cluster_transcripts.push_back(scaffolds[k_id]);
		double c = member_quants.sub_quants[k_id].count;
		cluster_counts.push_back(c);
		//cluster_counts.push_back(counts[bundle_clusters[j][k]]);
		
		group_gammas[k] = member_quants.sub_quants[k_id].gamma;
		estimated_length += group_gammas[k] * scaffolds[k_id].length();
		
		for (size_t m = 0; m < members.size(); ++m)
		{
			//fprintf(stderr, "%d x %d - %d x %d\n", gamma_cov.size1(), gamma_cov.size1(), group_gamma_cov.size1(), group_gamma_cov.size2());
			group_gamma_cov(k,m) = gamma_cov(k_id,
											 members[m]);
		}
		
	}
	
	double count = 0;
	
	double FPKM = 0;
	calc_isoform_group_fpkm(cluster_transcripts,
							sample_mass,
							cluster_counts,
							count,
							FPKM);
	
	double variance = 0;
	
	calc_isoform_group_fpkm_variance(count,
									 sample_mass,
									 cluster_transcripts,
									 group_gammas,
									 group_gamma_cov,
									 variance);
	
	group_quant.gene_names = gene_names;
	group_quant.protein_ids = protein_ids;
	
	group_quant.count = count;
	group_quant.FPKM = FPKM;
	group_quant.FPKM_variance = variance;
	group_quant.gamma = accumulate(group_gammas.begin(),
								   group_gammas.end(),
								   0.0);
	
	group_quant.est_length = group_quant.gamma > 0.0 ? 
		estimated_length / group_quant.gamma : 0.0;
}


// This takes an array of scaffolds and their global abundances, and a set of vectors of 
// indexes specifying subsets of the scaffolds, and computes the global abundances
// for the subsets.  scaffolds and member_quants use locus level addressing.
void calc_group_abundances(const vector<Scaffold>& scaffolds,
						   const QuantGroup& member_quants,
						   const vector<tss_cluster>& memberships,
						   long double sample_mass,
						   QuantGroup& groups)
{
	
	for (size_t j = 0; j < memberships.size(); ++j)
	{
		calc_group_abundance(scaffolds,
							 member_quants,
							 memberships[j],
							 sample_mass,
							 groups.sub_quants[j]);
	}
}

double entropy(const ublas::vector<double>& p)
{
	double e = 0;  
	for (size_t i = 0; i < p.size(); ++i)
	{
		double P = p[i];
		e -= (P * log(P));
	}
	return e;
}

double jensen_shannon_div(vector<ublas::vector<double> >& sample_kappas)
{
	assert (sample_kappas.size() > 1);
	for (size_t i = 0; i < sample_kappas.size(); ++i)
	{
		//cerr << sample_kappas[i] << endl;
		double kappa_sum = accumulate(sample_kappas[i].begin(), 
									  sample_kappas[i].end(), 0.0);
		assert (abs(kappa_sum - 1.0) < 1e-10);
	}
	
	size_t kappa_length = 0;
	for (size_t i = 1; i < sample_kappas.size(); ++i)
	{
		assert (sample_kappas[i].size() == sample_kappas[i-1].size());
		kappa_length = sample_kappas[i].size();
	}
	
	ublas::vector<double> avg_kappas = ublas::zero_vector<double>(kappa_length);
	for (size_t i = 0; i < sample_kappas.size(); ++i)
	{
		//cout << "kappa " << i<< " "<< sample_kappas[i] << endl;
		avg_kappas += sample_kappas[i];
	}
	avg_kappas /= sample_kappas.size();
	//cout << avg_kappas << endl;
	
	double avg_entropy = 0.0;
	for (size_t i = 0; i < sample_kappas.size(); ++i)
	{
		avg_entropy += entropy(sample_kappas[i]);
	}
	avg_entropy /= sample_kappas.size();
	//cout << avg_entropy << endl;

	double entropy_avg = entropy(avg_kappas);
	
	double js = entropy_avg - avg_entropy;
	return sqrt(js);
}

void jensen_shannon_gradient(vector<ublas::vector<double> >& sample_kappas,
							 double js,
							 ublas::vector<double>& gradient)
{
	assert (sample_kappas.size() > 1);
	size_t kappa_length = sample_kappas.front().size();
	for (size_t i = 1; i < sample_kappas.size(); ++i)
	{
		assert (sample_kappas[i].size() == sample_kappas[i-1].size());
		kappa_length = sample_kappas[i].size();
	}
	
	if (kappa_length == 0)
		return;
	
	gradient = ublas::zero_vector<double>(sample_kappas.size() * kappa_length);
	for (size_t i = 0; i < sample_kappas.size(); ++i)
	{
		for (size_t j = 0; j < kappa_length; ++j)
		{
			gradient(i*kappa_length + j) = sample_kappas[i](j);
		}
	}
	
	//cout << "t1: " << gradient<< endl;
	
	ublas::vector<double> denoms = ublas::zero_vector<double>(kappa_length);
	for (size_t i = 0; i < sample_kappas.size(); ++i)
	{
		denoms += sample_kappas[i];
	}
	denoms /= sample_kappas.size();
	
	//cout << "t2 " << denoms << endl;
	
	for (size_t i = 0; i < sample_kappas.size(); ++i)
	{
		for (size_t j = 0; j < kappa_length; ++j)
		{
			if (denoms(j) == 0.0 || gradient(i*kappa_length + j) == 0.0)
			{
				gradient(i*kappa_length + j) = 0.0;
			}
			else
			{
				gradient(i*kappa_length + j) /= denoms(j);
				gradient(i*kappa_length + j) = log(gradient(i*kappa_length + j));
				gradient(i*kappa_length + j) /= sample_kappas.size();
				gradient(i*kappa_length + j) *= (1.0/(2.0*js));
			}
		}
	}
}

void make_js_covariance_matrix(vector<ublas::matrix<double> >& kappa_covariances,
							   ublas::matrix<double>& js_covariance)
{
	size_t kappa_length = 0;
	for (size_t i = 1; i < kappa_covariances.size(); ++i)
	{
		assert (kappa_covariances[i].size1() == kappa_covariances[i-1].size1());
		assert (kappa_covariances[i].size2() == kappa_covariances[i-1].size2());

		kappa_length = kappa_covariances[i].size1();
	}
	
	if (kappa_length == 0)
		return;
	
	js_covariance = ublas::zero_matrix<double>(kappa_covariances.size() * kappa_length,
											   kappa_covariances.size() * kappa_length);
	for (size_t i = 0; i < kappa_covariances.size(); ++i)
	{
		for (size_t j = 0; j < kappa_length; ++j)
		{
			for (size_t k = 0; k < kappa_length; ++k)
			{
				js_covariance(i*kappa_length + j, i*kappa_length + k) = 
				kappa_covariances[i](j,k);
			}
		}
	}
}

// Takes the isoforms for a locus, an assignment of those isoforms to tss groups,
// and then calculates the kappas and their covariances for each tss group.  All
// information is stored in TSS QuantGroups

// gamma_cov must be NxN, where N = members.size()
void calc_kappas(const vector<size_t>& members,
				 const QuantGroup& member_quants,
				 const ublas::matrix<double>& gamma_cov,
				 QuantGroup& group_quant)
{
	size_t num_members = members.size();
	group_quant.kappa_covariance = ublas::matrix<double>(num_members, 
														 num_members);
	//cerr << gamma_cov <<endl;
	
	assert (gamma_cov.size1() == num_members);
	assert (gamma_cov.size2() == num_members);
			
	//tss_group.sub_quants = vector<QuantGroup>(isos_in_tss);
	
	double Z_kappa = 0.0;
	for (size_t k = 0; k < num_members; ++k)
	{
		if (member_quants.sub_quants[members[k]].est_length > 0)
		{
			Z_kappa += member_quants.sub_quants[members[k]].gamma /
					member_quants.sub_quants[members[k]].est_length;
		}
	}
	
	//bundle_tss_quant.sub_quants[j].kappa = 0;
	
	// k iterates over transcripts in the tss cluster j
	for (size_t k = 0; k < num_members; ++k)
	{
		size_t s_id_k = members[k];
		assert (k < group_quant.sub_quants.size());
		assert (s_id_k < member_quants.sub_quants.size());
		
		if (member_quants.sub_quants[members[k]].est_length > 0)
		{
			group_quant.sub_quants[k].kappa = member_quants.sub_quants[s_id_k].gamma /
				member_quants.sub_quants[s_id_k].est_length;
		}
		else
		{
			group_quant.sub_quants[k].kappa = 0;
		}
		
		group_quant.sub_quants[k].kappa /= Z_kappa;
		
		for (size_t m = 0; m < num_members; ++m)
		{
			size_t s_id_m = members[m];
			
			group_quant.kappa_covariance(k,m) = gamma_cov(k, m);
			double L = member_quants.sub_quants[s_id_k].est_length * 
					   member_quants.sub_quants[s_id_m].est_length;
			if (L > 0.0)
			{
				group_quant.kappa_covariance(k,m) /= (L * Z_kappa * Z_kappa);
			}
			else
			{
				group_quant.kappa_covariance(k,m) = 0.0;
			}
		}
	}
	//cerr << tss_group.kappa_covariance << endl;
}


// This performs within-group tests on a set of isoforms or a set of TSS groups.
// This is a way of looking for meaningful differential splicing or differential
// promoter use.
void get_ds_tests(size_t curr_sample_idx,
				 const QuantGroup& curr_quant_group,
				 size_t prev_sample_idx,
				 const QuantGroup& prev_quant_group,
				 SampleDiffs& diff_tests,
				 bool enough_reads)
{
	assert (curr_quant_group.sub_quants.size() == prev_quant_group.sub_quants.size());
//	if (curr_quant_group.sub_quants.size() < 2)
//		return 0;
	
#if VERBOSE
	fprintf(stderr, "\tCalculating JS divergences between samples %lu and %lu in locus %s\n",
			prev_sample_idx,
			curr_sample_idx,
			curr_quant_group.locus_tag.c_str());
#endif
	
	for (size_t j = 0; j < curr_quant_group.sub_quants.size(); ++j)
	{
		const QuantGroup& curr_tss = curr_quant_group.sub_quants[j];
		const QuantGroup& prev_tss = prev_quant_group.sub_quants[j];
		
		if (curr_tss.sub_quants.size() < 2)
			continue;
		
		assert (curr_tss.description == prev_tss.description);
		
		const string& name = curr_tss.description;
		
		pair<SampleDiffs::iterator, bool> inserted;
		inserted = diff_tests.insert(make_pair(name,SampleDifference())); 
		SampleDifference test;
		
		test.locus_desc = curr_tss.locus_tag;
		test.names = curr_tss.names;
		test.gene_names = curr_tss.gene_names;
		test.protein_ids = curr_tss.protein_ids;
		
		test.test_status = NOTEST;
		if (curr_tss.valid_quant && 
			prev_tss.valid_quant)
		{
			vector<ublas::vector<double> > sample_kappas;
			ublas::vector<double> curr_kappas(curr_tss.sub_quants.size());
			for (size_t i = 0; i < curr_tss.sub_quants.size(); ++i)
			{
				curr_kappas(i) = curr_tss.sub_quants[i].kappa;
			}
			
			ublas::vector<double> prev_kappas(curr_tss.sub_quants.size());
			for (size_t i = 0; i < prev_tss.sub_quants.size(); ++i)
			{
				prev_kappas(i) = prev_tss.sub_quants[i].kappa;
			}
			
			sample_kappas.push_back(prev_kappas);
			sample_kappas.push_back(curr_kappas);
			
			double js = jensen_shannon_div(sample_kappas);
			if (isnan(js) || isinf(js))
			{
				test.test_stat = 0;
				test.p_value = 1.0;
				test.value_1 = 0;
				test.value_2 = 0;
				test.test_status = NOTEST;
			}
			else
			{
				ublas::vector<double> js_gradient;
				jensen_shannon_gradient(sample_kappas, js, js_gradient);
				
				vector<ublas::matrix<double> > covariances;
				covariances.push_back(prev_tss.kappa_covariance);
				covariances.push_back(curr_tss.kappa_covariance);
				
				ublas::matrix<double> js_covariance;
				assert (covariances.size() > 0);
				for (size_t i = 0; i < covariances.size(); ++i)
				{
					assert (covariances[i].size1() > 0 && covariances[i].size2() > 0);
				}
				make_js_covariance_matrix(covariances,js_covariance);
				assert (js_covariance.size1() > 0 && js_covariance.size2() > 0);
				
				//cout << "grad: " << js_gradient << endl;
				//cout << "js_cov: " << js_covariance << endl;
				//cout << prod(js_covariance, js_gradient) << endl;

				double js_var = inner_prod(js_gradient, 
										   prod(js_covariance, js_gradient));
				if (js_var <= 0.0)
				{
					test.test_stat = 0;
					test.p_value = 1.0;
					test.value_1 = 0;
					test.value_2 = 0;
					test.differential = 0;
					test.test_status = OK;
				}
				else
				{
					normal test_dist(0,1.0);
					//double denom = sqrt(js_var);
					test.test_stat = js;
					double p = js/sqrt(js_var);
					test.p_value = 1.0 - cdf(test_dist, p);
					test.value_1 = 0;
					test.value_2 = 0;
					test.differential = js;
					test.test_status = OK;
				}
				if (isinf(test.test_stat) || isnan(test.test_stat))
				{
					fprintf(stderr, "Warning: test stat is invalid!\n");
					exit(1);
				}
			}
			if (test.test_status == OK && !enough_reads)
				test.test_status = NOTEST;
			inserted.first->second = test;
		}
		else
		{
			test.test_status = FAIL;
			test.test_stat = 0;
			test.p_value = 0.0;
			test.differential = 0.0;
			inserted.first->second = test;
		}
		
	}
	

}

void make_isoform_quants(const RefSequenceTable& rt, 
						 const vector<HitBundle*>& sample_bundles,
						 const vector<bool>& successes,
						 const vector<long double>& sample_masses,
						 vector<QuantGroup>& locus_isoforms)
{
	RefID bundle_chr_id = sample_bundles.front()->ref_id();
	assert (bundle_chr_id != 0);
	const char* chr_name = rt.get_name(bundle_chr_id);
	
	// create the isoform level quantitation records
	for (size_t i = 0; i < sample_bundles.size(); ++i)
	{
		QuantGroup& isoform_quant_group = locus_isoforms[i];
		const vector<Scaffold>& scaffolds = sample_bundles[i]->ref_scaffolds();
		isoform_quant_group.valid_quant = successes[i];
		
		long double mass = sample_masses[i];
		for (size_t j = 0; j < scaffolds.size(); ++j)
		{
			isoform_quant_group.sub_quants[j].description = scaffolds[j].annotated_trans_id();
			char locus_buf[256];
			int left = scaffolds[j].left();
			int right  = scaffolds[j].right();
			
			sprintf(locus_buf, 
					"%s:%d-%d",
					chr_name,
					scaffolds[j].left(),
					scaffolds[j].right());
			isoform_quant_group.sub_quants[j].chr = chr_name;
			isoform_quant_group.sub_quants[j].left = left;
			isoform_quant_group.sub_quants[j].right = right;
			isoform_quant_group.sub_quants[j].parent_id = scaffolds[j].annotated_gene_id();
			isoform_quant_group.sub_quants[j].tss_id = scaffolds[j].annotated_tss_id();
			isoform_quant_group.sub_quants[j].classcode = scaffolds[j].nearest_ref_classcode();
			isoform_quant_group.sub_quants[j].locus_tag = locus_buf;
		}
		
		if (successes[i])
		{
			vector<bool> all_isos = vector<bool>(scaffolds.size(), true);
			ublas::vector<double> gammas;
			ublas::matrix<double> gamma_covariance;
			select_gammas(isoform_quant_group, all_isos, gammas, gamma_covariance);
			
			vector<MateHit> alignments;
			get_alignments_from_scaffolds(scaffolds, alignments);
			
			vector<double> counts;
			
			vector<double> vgammas(gammas.begin(), gammas.end());
			calc_isoform_counts(scaffolds,alignments, vgammas, counts);
			double total_locus_mass = accumulate(counts.begin(), 
												 counts.end(), 
												 0.0);
			
			vector<double> FPKMs;
			calc_isoform_fpkms(scaffolds,
							   mass, 
							   counts, 
							   FPKMs);
			
			vector<double> FPKM_variances;
			
			
			calc_isoform_fpkm_variances(total_locus_mass,
										mass,
										scaffolds,
										true,
										vgammas,
										gamma_covariance,
										FPKM_variances);
			
			for (size_t j = 0; j < scaffolds.size(); ++j)
			{
				QuantGroup& iso_j = isoform_quant_group.sub_quants[j];
				isoform_quant_group.sub_quants[j].scaffold_idx = (int)j;
				const string& nearest = scaffolds[j].nearest_ref_id();
				if (nearest != "")
				{
					iso_j.closest_ref_matches.push_back(nearest);
				}
				else
				{
					iso_j.closest_ref_matches.push_back("-");
				}
				const string& trans_id = scaffolds[j].annotated_trans_id();
				iso_j.names.push_back(trans_id);
				
				iso_j.gene_names.insert(scaffolds[j].annotated_gene_name());
				string p_id = scaffolds[j].annotated_protein_id();
				if (p_id != "")
				{
					iso_j.protein_ids.insert(p_id);
				}
				iso_j.FPKM = FPKMs[j];
				iso_j.FPKM_variance = FPKM_variances[j];
				iso_j.count = counts[j];
				iso_j.kappa = 1.0; // when a QuantGroup contains only one isoform, kappa = 1
			}
		}
	}	
}
 
void group_quants_by_tss(const QuantGroup& locus_child_quants,
						 vector<vector<size_t> >& tss_groups)
{
	map<string, vector<size_t> > tmp;
	for (size_t i = 0; i < locus_child_quants.sub_quants.size(); ++i)
	{
		string tss_id = locus_child_quants.sub_quants[i].tss_id;
		pair<map<string, vector<size_t> >::iterator, bool> inserted;
		inserted = tmp.insert(make_pair(tss_id,vector<size_t>()));
		inserted.first->second.push_back(i);
	}
	
	tss_groups.clear();
	for (map<string, vector<size_t> >::iterator itr = tmp.begin();
		 itr != tmp.end();
		 ++itr)
	{
		tss_groups.push_back(itr->second);
	}
}

void make_tss_quants(const RefSequenceTable& rt, 
					 const vector<HitBundle*>& sample_bundles,
					 const vector<bool>& successes,
					 const vector<long double>& sample_masses,
					 const vector<QuantGroup>& locus_isoforms,
					 vector<QuantGroup>& tss_cluster_quants)
{
	RefID bundle_chr_id = sample_bundles.front()->ref_id();
	assert (bundle_chr_id != 0);
	const char* chr_name = rt.get_name(bundle_chr_id);
	
	vector<vector<tss_cluster> > tss_clusters; 
	//find_tss_clusters(sample_bundles, tss_clusters);
	//find_tss_clusters(sample_bundles, tss_clusters);
	
	// verify that ALL isoforms in this locus for all bundles have tss_id tags
	for (size_t i = 0; i < sample_bundles.size(); ++i)
	{
		const QuantGroup& isoform_quant_group = locus_isoforms[i];
		for (size_t j = 0; j < isoform_quant_group.sub_quants.size(); ++j)
		{
			if (isoform_quant_group.sub_quants[j].tss_id == "")
			{
				fprintf(stderr, "isoform %s has no tss_id, no tss grouping analysis available here\n", isoform_quant_group.sub_quants[j].description.c_str());
				return;
			}
		}
	}
	
	//int curr_tss_group_id = next_tss_group_id;
	for (size_t i = 0; i < sample_bundles.size(); ++i)
	{
		const vector<Scaffold>& scaffolds = sample_bundles[i]->ref_scaffolds();
		//const vector<double>& counts = locus_isoforms[i].counts;
		vector<tss_cluster> tss_memberships;
		long double mass = sample_masses[i];
		
		const QuantGroup& isoform_quant_group = locus_isoforms[i];
		group_quants_by_tss(isoform_quant_group, tss_memberships);
		
		QuantGroup& tss_quant_group = tss_cluster_quants[i];
		
		tss_quant_group.valid_quant = successes[i];
		
		tss_quant_group.sub_quants = vector<QuantGroup>(tss_memberships.size());
		
		// Set up the locus names and descriptions
		for (size_t tss = 0; tss < tss_memberships.size(); tss++)
		{
			char locus_buf[256];
			//tss_cluster_quants[i].sub_quants.push_back(Quant());
			
			
			int left = 1999999999;
			int right = -1;
			
			tss_quant_group.sub_quants[tss].sub_quants = 
				vector<QuantGroup>(tss_memberships[tss].size());
			for (size_t k = 0; k < tss_memberships[tss].size(); ++k)
			{
				left = min(isoform_quant_group.sub_quants[tss_memberships[tss][k]].left, left);
				right = max(isoform_quant_group.sub_quants[tss_memberships[tss][k]].right, right);
				
				tss_quant_group.sub_quants[tss].description = isoform_quant_group.sub_quants[tss_memberships[tss][k]].tss_id;
				string name = scaffolds[tss_memberships[tss][k]].annotated_trans_id();
				string gene_name = scaffolds[tss_memberships[tss][k]].annotated_gene_name();
				string gene_id = scaffolds[tss_memberships[tss][k]].annotated_gene_id();
				string protein_id = scaffolds[tss_memberships[tss][k]].annotated_protein_id();
				tss_quant_group.sub_quants[tss].names.push_back(name);
				tss_quant_group.sub_quants[tss].parent_id = gene_id;
				tss_quant_group.sub_quants[tss].gene_names.insert(gene_name);
				tss_quant_group.sub_quants[tss].protein_ids.insert(protein_id);
				tss_quant_group.sub_quants[tss].sub_quants[k] = isoform_quant_group.sub_quants[tss_memberships[tss][k]];
				tss_quant_group.sub_quants[tss].valid_quant = successes[i];

			}
			sprintf(locus_buf, 
					"%s:%d-%d",
					chr_name,
					left,
					right);
			tss_quant_group.sub_quants[tss].chr = chr_name;
			tss_quant_group.sub_quants[tss].left = left;
			tss_quant_group.sub_quants[tss].right = right;
			tss_quant_group.sub_quants[tss].locus_tag = locus_buf;
		}
		if (!successes[i])
			continue;
		
		
//		calc_group_abundances(scaffolds,
//							  isoform_quant_group,
//							  bundle_clusters,
//							  mass,
//							  tss_quant_group);
		for (size_t tss = 0; tss < tss_memberships.size(); tss++)
		{
			
			calc_group_abundance(scaffolds,
								 isoform_quant_group,
								 tss_memberships[tss],
								 mass,
								 tss_quant_group.sub_quants[tss]);
			
			const vector<size_t>& tss_members = tss_memberships[tss];
			ublas::matrix<double> combined = ublas::zero_matrix<double>(tss_members.size(),
																		tss_members.size());
			
			
			const ublas::matrix<double>& gamma_cov = locus_isoforms[i].gamma_covariance;
			//cerr << "locus isoform gamma cov" << gamma_cov << endl;
			for (size_t L = 0; L < tss_members.size(); ++L)
			{
				for (size_t K = 0; K < tss_members.size(); ++K)
				{
					combined(L,K) += gamma_cov(tss_members[L],tss_members[K]);
				}
			}
			
			calc_kappas(tss_memberships[tss],
						isoform_quant_group,
						combined,
						tss_quant_group.sub_quants[tss]);
		}
	}
}

// TODO: CDS clustering and TSS clustering are essentially the same code,
// should refactor to avoid duplication
void group_quants_by_cds(const QuantGroup& locus_child_quants,
						 vector<vector<size_t> >& cds_groups)
{
	map<string, vector<size_t> > tmp;
	for (size_t i = 0; i < locus_child_quants.sub_quants.size(); ++i)
	{
		// we should have already verified that everthing in this locus has a 
		// protein id
		assert (locus_child_quants.sub_quants[i].protein_ids.size() == 1);
		
		string cds_id = *(locus_child_quants.sub_quants[i].protein_ids.begin());
		pair<map<string, vector<size_t> >::iterator, bool> inserted;
		inserted = tmp.insert(make_pair(cds_id,vector<size_t>()));
		inserted.first->second.push_back(i);
	}
	
	cds_groups.clear();
	for (map<string, vector<size_t> >::iterator itr = tmp.begin();
		 itr != tmp.end();
		 ++itr)
	{
		cds_groups.push_back(itr->second);
	}
}

void make_cds_quants(const RefSequenceTable& rt, 
					 const vector<HitBundle*>& sample_bundles,
					 const vector<bool>& successes,
					 const vector<long double>& sample_masses,
					 const vector<QuantGroup>& locus_isoforms,
					 vector<QuantGroup>& cds_cluster_quants)
{
	RefID bundle_chr_id = sample_bundles.front()->ref_id();
	assert (bundle_chr_id != 0);
	const char* chr_name = rt.get_name(bundle_chr_id);
	
	vector<vector<tss_cluster> > cds_clusters; 
	//find_tss_clusters(sample_bundles, tss_clusters);
	//find_tss_clusters(sample_bundles, tss_clusters);
	
	// verify that ALL isoforms in this locus for all bundles have tss_id tags
	for (size_t i = 0; i < sample_bundles.size(); ++i)
	{
		const QuantGroup& isoform_quant_group = locus_isoforms[i];
		for (size_t j = 0; j < isoform_quant_group.sub_quants.size(); ++j)
		{
			if (isoform_quant_group.sub_quants[j].protein_ids.empty())
			{
				fprintf(stderr, "isoform %s has no p_id, no CDS grouping analysis available here\n", isoform_quant_group.sub_quants[j].description.c_str());
				return;
			}
		}
	}

	for (size_t i = 0; i < sample_bundles.size(); ++i)
	{
		const vector<Scaffold>& scaffolds = sample_bundles[i]->ref_scaffolds();
		//const vector<double>& counts = locus_isoforms[i].counts;
		vector<vector<size_t> > cds_memberships;
		long double mass = sample_masses[i];
		
		const QuantGroup& isoform_quant_group = locus_isoforms[i];
		group_quants_by_cds(isoform_quant_group, cds_memberships);
		
		QuantGroup& cds_quant_group = cds_cluster_quants[i];
		
		cds_quant_group.valid_quant = successes[i];
		
		cds_quant_group.sub_quants = vector<QuantGroup>(cds_memberships.size());
		
		// Set up the locus names and descriptions
		for (size_t cds = 0; cds < cds_memberships.size(); cds++)
		{
			char locus_buf[256];
			//tss_cluster_quants[i].sub_quants.push_back(Quant());
			
			
			int left = 1999999999;
			int right = -1;
			
			cds_quant_group.sub_quants[cds].sub_quants = 
			vector<QuantGroup>(cds_memberships[cds].size());
			for (size_t k = 0; k < cds_memberships[cds].size(); ++k)
			{
				size_t iso_k = cds_memberships[cds][k];
				left = min(isoform_quant_group.sub_quants[iso_k].left, left);
				right = max(isoform_quant_group.sub_quants[iso_k].right, right);
				
				string p_id = *(isoform_quant_group.sub_quants[iso_k].protein_ids.begin());
				sprintf(locus_buf, 
						"%s:%d-%d",
						chr_name,
						isoform_quant_group.sub_quants[iso_k].left,
						isoform_quant_group.sub_quants[iso_k].right);
				cds_quant_group.sub_quants[cds].description = p_id + "-[" + locus_buf + "]";
				string name = scaffolds[iso_k].annotated_trans_id();
				string gene_name = scaffolds[iso_k].annotated_gene_name();
				string gene_id = scaffolds[iso_k].annotated_gene_id();
				//string protein_id = scaffolds[iso_k].annotated_protein_id();
				cds_quant_group.sub_quants[cds].names.push_back(name);
				cds_quant_group.sub_quants[cds].parent_id = gene_id;
				cds_quant_group.sub_quants[cds].gene_names.insert(gene_name);
				cds_quant_group.sub_quants[cds].protein_ids.insert(p_id);
				cds_quant_group.sub_quants[cds].sub_quants[k] = isoform_quant_group.sub_quants[iso_k];
				cds_quant_group.sub_quants[cds].valid_quant = successes[i];
				
			}
			sprintf(locus_buf, 
					"%s:%d-%d",
					chr_name,
					left,
					right);
			cds_quant_group.sub_quants[cds].chr = chr_name;
			cds_quant_group.sub_quants[cds].left = left;
			cds_quant_group.sub_quants[cds].right = right;
			cds_quant_group.sub_quants[cds].locus_tag = locus_buf;
		}
		if (!successes[i])
			continue;
		
		for (size_t cds = 0; cds < cds_memberships.size(); cds++)
		{
			
			calc_group_abundance(scaffolds,
								 isoform_quant_group,
								 cds_memberships[cds],
								 mass,
								 cds_quant_group.sub_quants[cds]);
			
			const vector<size_t>& cds_members = cds_memberships[cds];
			ublas::matrix<double> combined = ublas::zero_matrix<double>(cds_members.size(),
																		cds_members.size());
			
			
			const ublas::matrix<double>& gamma_cov = locus_isoforms[i].gamma_covariance;
			//cerr << "locus isoform gamma cov" << gamma_cov << endl;
			for (size_t L = 0; L < cds_members.size(); ++L)
			{
				for (size_t K = 0; K < cds_members.size(); ++K)
				{
					combined(L,K) += gamma_cov(cds_members[L],cds_members[K]);
				}
			}
			
			calc_kappas(cds_memberships[cds],
						isoform_quant_group,
						combined,
						cds_quant_group.sub_quants[cds]);
		}
	}
}


void group_quants_by_gene(const QuantGroup& locus_child_quants,
								vector<vector<size_t> >& genes)
{
	map<string, vector<size_t> > tmp;
	for (size_t i = 0; i < locus_child_quants.sub_quants.size(); ++i)
	{
		string gene_id = locus_child_quants.sub_quants[i].parent_id;
		pair<map<string, vector<size_t> >::iterator, bool> inserted;
		inserted = tmp.insert(make_pair(gene_id,vector<size_t>()));
		inserted.first->second.push_back(i);
	}
	
	genes.clear();
	for (map<string, vector<size_t> >::iterator itr = tmp.begin();
		 itr != tmp.end();
		 ++itr)
	{
		genes.push_back(itr->second);
	}
}

void make_gene_quants(const RefSequenceTable& rt, 
						  const vector<HitBundle*>& sample_bundles,
						  const vector<bool>& successes,
						  const vector<long double>& sample_masses,
						  const vector<QuantGroup>& locus_isoforms,
						  const vector<QuantGroup>& locus_tss_clusters,
						  vector<QuantGroup>& gene_quants)
{
	RefID bundle_chr_id = sample_bundles.front()->ref_id();
	assert (bundle_chr_id != 0);
	const char* chr_name = rt.get_name(bundle_chr_id);
	
	
	//find_tss_clusters(sample_bundles, tss_clusters);
	
	//int curr_tss_group_id = next_tss_group_id;
	for (size_t i = 0; i < sample_bundles.size(); ++i)
	{
		const vector<Scaffold>& scaffolds = sample_bundles[i]->ref_scaffolds();
		long double mass = sample_masses[i];
		
		// A list of TSS groups for each gene
		vector<vector<size_t> > gene_tsses;
		
		// A list of isoforms for each gene
		vector<vector<size_t> > gene_isoforms;
		
		const QuantGroup& tss_quant_group = locus_tss_clusters[i];
		group_quants_by_gene(tss_quant_group,
							 gene_tsses);
		
		const QuantGroup& isoform_quant_group = locus_isoforms[i];
		group_quants_by_gene(isoform_quant_group,
							 gene_isoforms);
		
		QuantGroup& gene_quant_group = gene_quants[i];
		
		gene_quant_group.valid_quant = successes[i];
		
		//int next_tss_id = curr_tss_group_id;
		//next_tss_group_id = max(curr_tss_group_id + (int)bundle_clusters.size(),
		//						next_tss_group_id);
		
		gene_quant_group.sub_quants = vector<QuantGroup>(gene_tsses.size());
		
		// Set up the locus names and descriptions
		for (size_t curr_gene = 0; curr_gene < gene_tsses.size(); curr_gene++)
		{
			//tss_cluster_quants[i].sub_quants.push_back(Quant());
			assert (!gene_tsses[curr_gene].empty());
			
			string desc = tss_quant_group.sub_quants[gene_tsses[curr_gene].front()].parent_id;
			
			QuantGroup& gene_quant = gene_quant_group.sub_quants[curr_gene];
			
			// Make a copy of the TSS QuantGroup records for this gene
//			vector<QuantGroup> tss_clusters;
//			for (size_t j = 0; j < genes[curr_gene].size(); ++j)
//			{
//				const QuantGroup& tss = tss_quant_group.sub_quants[genes[curr_gene][j]];
//				tss_clusters.push_back(tss);
//			}
			
			// Set the gene's description
			gene_quant.description = desc;
			int left = 1999999999;
			int right = -1;
			
			//gene_quant_group.sub_quants[curr_gene].sub_quants = 
			//	vector<QuantGroup>(genes[curr_gene].size());
			
			const vector<size_t>& tsses_in_gene = gene_tsses[curr_gene];
			gene_quant.valid_quant = successes[i];
			gene_quant.sub_quants = 
				vector<QuantGroup>(tsses_in_gene.size());
			
			// iterate through each TSS in this gene, extracting the maximal
			// locus description that comes from each TSS's isoforms
			for (size_t k = 0; k < tsses_in_gene.size(); ++k)
			{
				const QuantGroup tss_quant = tss_quant_group.sub_quants[tsses_in_gene[k]];
				left = min(tss_quant.left, left);
				right = max(tss_quant.right, right);
				
				string name = tss_quant.description;
				set<string> gene = tss_quant.gene_names;
				
				//gene_quant_group.sub_quants[curr_gene].sub_quants
				gene_quant.names.push_back(name);
				const set<string>& gene_names = tss_quant.gene_names;
				gene_quant.gene_names.insert(gene_names.begin(),
											 gene_names.end());
				gene_quant.sub_quants[k] = tss_quant;
				gene_quant.sub_quants[k].valid_quant = successes[i];
			}
			char locus_buf[256];
			sprintf(locus_buf, 
					"%s:%d-%d",
					chr_name,
					left,
					right);
			
			gene_quant.locus_tag = locus_buf;
			// Set the gene's description
			gene_quant.description = desc + "-[" + locus_buf + "]"; 
			if (successes[i])
			{
				
				// For TSS 
				// groups A and B, TSSGammaCovariance(A,B) = 
				// Sum_{i in A}Sum_{j in B}IsoformGammaCovariance(i,j)
				ublas::matrix<double> combined = ublas::zero_matrix<double>(tsses_in_gene.size(),
																			tsses_in_gene.size());
				//cerr << "combined " << combined << endl;
				vector<tss_cluster> isos_in_tsses(tsses_in_gene.size());
				for (size_t j = 0; j < tsses_in_gene.size(); ++j)
				{
					const QuantGroup tss_j = tss_quant_group.sub_quants[tsses_in_gene[j]];
					for (size_t k = 0; k < tss_j.sub_quants.size(); ++k)
					{
						int scaff_idx = tss_j.sub_quants[k].scaffold_idx;
						assert (scaff_idx != -1);
						isos_in_tsses[j].push_back(scaff_idx);
					}
				}
				
				const ublas::matrix<double>& gamma_cov = locus_isoforms[i].gamma_covariance;
				//cerr << "locus isoform gamma cov" << gamma_cov << endl;
				for (size_t L = 0; L < tsses_in_gene.size(); ++L)
				{
					const tss_cluster& L_isos = isos_in_tsses[L];
					for (size_t K = 0; K < tsses_in_gene.size(); ++K)
					{
						const tss_cluster& K_isos = isos_in_tsses[K];
						for (size_t l = 0; l < L_isos.size(); ++l)
						{
							for (size_t k = 0; k < K_isos.size(); ++k)
							{
								//cerr << L_isos[l] << "," << K_isos[k] << endl;
								combined(L,K) += gamma_cov(L_isos[l],K_isos[k]);
							}
						}
					}
				}
				//QuantGroup tsses;
				//tsses.sub_quants = tss_clusters;
				//cerr << "promoter gamma covariance: "<< combined << endl;
				
				calc_kappas(tsses_in_gene,
							tss_quant_group,
							combined,
							gene_quant);
				for (size_t L = 0; L < tsses_in_gene.size(); ++L)
				{
					for (size_t K = 0; K < tsses_in_gene.size(); ++K)
					{
						if (isinf(gene_quant.kappa_covariance(L,K)) ||
							isnan(gene_quant.kappa_covariance(L,K)))
						{
							fprintf(stderr, "Error: found illegal kappa in %s\n", gene_quant.locus_tag.c_str());
							exit(1);
						}
					}
				}
				//cerr << "promoter kappa covariance" << gene_quant.kappa_covariance << endl;
				
				const vector<size_t>& isoforms_in_gene = gene_isoforms[curr_gene];
				calc_group_abundance(scaffolds,
									 isoform_quant_group,
									 isoforms_in_gene,
									 mass,
									 gene_quant);
			}
		}
	}
}



void test_differential(const RefSequenceTable& rt, 
					   const vector<HitBundle*>& sample_bundles,
					   const vector<long double>& sample_masses,
					   Tests& tests,
					   Tracking& tracking)
{
	if (sample_bundles.empty())
		return;
	
	vector<QuantGroup> locus_isoforms(sample_bundles.size());
	vector<bool> successes(sample_bundles.size(), false);
	vector<double> bundle_masses(sample_bundles.size(), 0);
	for (size_t i = 0; i < sample_bundles.size(); ++i)
	{
		bundle_masses[i] = sample_bundles[i]->hits().size();
	}
	
	// now run the gamma calculation on each bundle.
	quantitate_locus_gammas(sample_bundles, successes, locus_isoforms);
	
	make_isoform_quants(rt, sample_bundles, successes, sample_masses, locus_isoforms);
	
	bool multi_transcript_locus = locus_isoforms.front().sub_quants.size() > 1;
	
	// each bundle gets a list of tss_clusters, which are lists of transcripts
	// that start at the same spot in the genome, and probably have a common 
	// promoter.  One tss cluster == one primary transcript.  
	
	// vector<vector<vector<size_t> > > >
	
	vector<QuantGroup> tss_cluster_quants(sample_bundles.size());
	
	// create the TSS group level quantitation records.  The Isoform quant records
	// that go in each TSS group will get copied in 

	make_tss_quants(rt, 
					sample_bundles,
					successes,
					sample_masses,
					locus_isoforms,
					tss_cluster_quants);
	
	vector<QuantGroup> isoform_cds_cluster_quants(sample_bundles.size());
	vector<QuantGroup> cds_cluster_quants(sample_bundles.size());
	
	// create the CDS group level quantitation records.  The Isoform quant records
	// that go in each CDS group will get copied in 
	
	make_cds_quants(rt, 
					sample_bundles,
					successes,
					sample_masses,
					locus_isoforms,
					isoform_cds_cluster_quants);
	make_gene_quants(rt, 
					 sample_bundles,
					 successes,
					 sample_masses,
					 locus_isoforms,
					 isoform_cds_cluster_quants,
					 cds_cluster_quants);
	
	
	vector<QuantGroup> promoter_quants(sample_bundles.size());
	
	// "Promoter" level quants measure relative TSS usage within a single gene.
	// Thus, there is one promoter QuantGroup per gene.
	make_gene_quants(rt, 
					 sample_bundles,
					 successes,
					 sample_masses,
					 locus_isoforms,
					 tss_cluster_quants,
					 promoter_quants);
	
	// Perform isoform-level differential expression tests
#if ENABLE_THREADS
	test_storage_lock.lock();
#endif
	
	for (size_t i = 1; i < locus_isoforms.size(); ++i)
	{
		const QuantGroup& curr_quant = locus_isoforms[i];
		const QuantGroup& prev_quant = locus_isoforms[i - 1];
		
		// Don't perform any testing if either locus has too few reads
		// for a reliable calculation
		bool enough_reads = !(multi_transcript_locus &&
							  (bundle_masses[i] < min_read_count ||
							   bundle_masses[i-1] < min_read_count));

#if VERBOSE
		fprintf(stderr, "Testing for differential isoform transcription in locus %d-%d\n",
				sample_bundles.front()->left(),
				sample_bundles.front()->right());
#endif
		
		get_de_tests(i,
					 curr_quant,
					 sample_masses[i],
					 i-1,
					 prev_quant,
					 sample_masses[i - 1],
					 tests.isoform_de_tests[i-1],
					 enough_reads);
	}
	
	for (size_t i = 0; i < locus_isoforms.size(); ++i)
	{
		const QuantGroup& isoforms = locus_isoforms[i];
		double log_mass_curr = log(sample_masses[i]);
		for (size_t j = 0; j < isoforms.sub_quants.size(); ++j)
		{
			pair<FPKMTrackingTable::iterator,bool> inserted;
			pair<string, FPKMTracking > p;
			p = make_pair(isoforms.sub_quants[j].description, FPKMTracking());
			inserted = tracking.isoform_fpkm_tracking.insert(p);
			
			FPKMTracking& fpkm_track = inserted.first->second;
			const QuantGroup& curr_jq = isoforms.sub_quants[j]; 
			double curr = curr_jq.FPKM;
			double curr_fpkm_var = curr_jq.FPKM_variance;
			double curr_counts = curr_jq.count;
			
			if (inserted.second)
			{
				fpkm_track.locus_tag = curr_jq.locus_tag;
				fpkm_track.tss_id = curr_jq.tss_id;
				fpkm_track.gene_names.insert(curr_jq.gene_names.begin(), 
											 curr_jq.gene_names.end());
				fpkm_track.protein_ids.insert(curr_jq.protein_ids.begin(), 
											  curr_jq.protein_ids.end());
				fpkm_track.names.insert(fpkm_track.names.end(),
										curr_jq.names.begin(), 
										curr_jq.names.end());
				fpkm_track.ref_match_ids.insert(fpkm_track.ref_match_ids.end(),
												curr_jq.closest_ref_matches.begin(), 
												curr_jq.closest_ref_matches.end());
				fpkm_track.classcode = curr_jq.classcode;
			}
			
			FPKMContext r1(curr_counts, curr, curr_fpkm_var, log_mass_curr);
			inserted.first->second.fpkm_series.push_back(r1);
		}
	}
	
	// Perform TSS-cluster level differential expression tests
	for (size_t i = 1; i < tss_cluster_quants.size(); ++i)
	{
		const QuantGroup& curr_quant = tss_cluster_quants[i];
		const QuantGroup& prev_quant = tss_cluster_quants[i - 1];
		long double curr_mass = sample_masses[i];
		long double prev_mass = sample_masses[i-1];
		SampleDiffs& de_tests = tests.tss_group_de_tests[i-1];
		SampleDiffs& ds_tests = tests.diff_splicing_tests[i-1];
		
		// Don't perform any testing if either locus has too few reads
		// for a reliable calculation
		bool enough_reads = !(multi_transcript_locus &&
							  (bundle_masses[i] < min_read_count ||
							   bundle_masses[i-1] < min_read_count));
		
#if VERBOSE
		fprintf(stderr, "Testing for differential TSS group expression in locus %d-%d\n",
				sample_bundles.front()->left(),
				sample_bundles.front()->right());
#endif
		get_de_tests(i,
					 curr_quant,
					 curr_mass,
					 i-1,
					 prev_quant,
					 prev_mass,
					 de_tests,
					 enough_reads);
		

#if VERBOSE
		fprintf(stderr, "Testing for differential TSS group splicing in locus %d-%d\n",
				sample_bundles.front()->left(),
				sample_bundles.front()->right());
#endif
		
		get_ds_tests(i,
					 curr_quant,
					 i-1,
					 prev_quant,
					 ds_tests,
					 enough_reads);
	}
	for (size_t i = 0; i < tss_cluster_quants.size(); ++i)
	{
		const QuantGroup& genes = tss_cluster_quants[i];
		double log_mass_curr = log(sample_masses[i]);
		for (size_t j = 0; j < genes.sub_quants.size(); ++j)
		{
			pair<FPKMTrackingTable::iterator,bool> inserted;
			pair<string, FPKMTracking > p;
			p = make_pair(genes.sub_quants[j].description, FPKMTracking());
			inserted = tracking.tss_group_fpkm_tracking.insert(p);
			
			FPKMTracking& fpkm_track = inserted.first->second;
			const QuantGroup& curr_jq = genes.sub_quants[j]; 
			double curr = curr_jq.FPKM;
			double curr_fpkm_var = curr_jq.FPKM_variance;
			double curr_counts = curr_jq.count;
			
			if (inserted.second)
			{
				fpkm_track.locus_tag = curr_jq.locus_tag;
				fpkm_track.tss_id = curr_jq.description;
				fpkm_track.gene_names.insert(curr_jq.gene_names.begin(), 
											 curr_jq.gene_names.end());
				fpkm_track.protein_ids.insert(curr_jq.protein_ids.begin(), 
											  curr_jq.protein_ids.end());
				fpkm_track.names.insert(fpkm_track.names.end(),
										curr_jq.names.begin(), 
										curr_jq.names.end());
				fpkm_track.ref_match_ids.insert(fpkm_track.ref_match_ids.end(),
												curr_jq.closest_ref_matches.begin(), 
												curr_jq.closest_ref_matches.end());
				fpkm_track.classcode = curr_jq.classcode;
			}
			
			FPKMContext r1(curr_counts, curr, curr_fpkm_var, log_mass_curr);
			inserted.first->second.fpkm_series.push_back(r1);
		}
	}

	// Perform CDS-cluster level differential expression tests
	for (size_t i = 1; i < isoform_cds_cluster_quants.size(); ++i)
	{
		const QuantGroup& curr_quant = isoform_cds_cluster_quants[i];
		const QuantGroup& prev_quant = isoform_cds_cluster_quants[i - 1];
		long double curr_mass = sample_masses[i];
		long double prev_mass = sample_masses[i-1];
		SampleDiffs& de_tests = tests.cds_de_tests[i-1];
		SampleDiffs& ds_tests = tests.diff_cds_tests[i-1];
		
		// Don't perform any testing if either locus has too few reads
		// for a reliable calculation
		bool enough_reads = !(multi_transcript_locus &&
							  (bundle_masses[i] < min_read_count ||
							   bundle_masses[i-1] < min_read_count));

		
#if VERBOSE
		fprintf(stderr, "Testing for differential CDS expression in locus %d-%d\n",
				sample_bundles.front()->left(),
				sample_bundles.front()->right());
#endif
		
		get_de_tests(i,
					 curr_quant,
					 curr_mass,
					 i-1,
					 prev_quant,
					 prev_mass,
					 de_tests,
					 enough_reads);
		
#if VERBOSE
		fprintf(stderr, "Testing for differential relative CDS output in locus %d-%d\n",
				sample_bundles.front()->left(),
				sample_bundles.front()->right());
#endif
		
		get_ds_tests(i,
					 curr_quant,
					 i-1,
					 prev_quant,
					 ds_tests,
					 enough_reads);
	}
	for (size_t i = 0; i < cds_cluster_quants.size(); ++i)
	{
		const QuantGroup& genes = cds_cluster_quants[i];
		double log_mass_curr = log(sample_masses[i]);
		for (size_t j = 0; j < genes.sub_quants.size(); ++j)
		{
			pair<FPKMTrackingTable::iterator,bool> inserted;
			pair<string, FPKMTracking > p;
			p = make_pair(genes.sub_quants[j].description, FPKMTracking());
			inserted = tracking.cds_fpkm_tracking.insert(p);
			
			FPKMTracking& fpkm_track = inserted.first->second;
			const QuantGroup& curr_jq = genes.sub_quants[j]; 
			double curr = curr_jq.FPKM;
			double curr_fpkm_var = curr_jq.FPKM_variance;
			double curr_counts = curr_jq.count;
			
			if (inserted.second)
			{
				fpkm_track.locus_tag = curr_jq.locus_tag;
				fpkm_track.tss_id = "";
				fpkm_track.gene_names.insert(curr_jq.gene_names.begin(), 
											 curr_jq.gene_names.end());
				fpkm_track.protein_ids.insert(curr_jq.protein_ids.begin(), 
											  curr_jq.protein_ids.end());
				fpkm_track.names.insert(fpkm_track.names.end(),
										curr_jq.names.begin(), 
										curr_jq.names.end());
				fpkm_track.ref_match_ids.insert(fpkm_track.ref_match_ids.end(),
												curr_jq.closest_ref_matches.begin(), 
												curr_jq.closest_ref_matches.end());
				fpkm_track.classcode = curr_jq.classcode;
			}
			
			FPKMContext r1(curr_counts, curr, curr_fpkm_var, log_mass_curr);
			inserted.first->second.fpkm_series.push_back(r1);
		}
	}
	
	// Perform Gene-cluster level differential transcription start tests

	for (size_t i = 1; i < promoter_quants.size(); ++i)
	{
		const QuantGroup& curr_quant = promoter_quants[i];
		const QuantGroup& prev_quant = promoter_quants[i - 1];
		long double curr_mass = sample_masses[i];
		long double prev_mass = sample_masses[i-1];
		SampleDiffs& de_tests = tests.gene_de_tests[i-1];
		SampleDiffs& ds_tests = tests.diff_promoter_tests[i-1];
		
		// Don't perform any testing if either locus has too few reads
		// for a reliable calculation
		bool enough_reads = !(multi_transcript_locus &&
							  (bundle_masses[i] < min_read_count ||
							   bundle_masses[i-1] < min_read_count));
		
#if VERBOSE
		fprintf(stderr, "Testing for differential gene expression in locus %d-%d\n",
				sample_bundles.front()->left(),
				sample_bundles.front()->right());
#endif
		get_de_tests(i,
					 curr_quant,
					 curr_mass,
					 i-1,
					 prev_quant,
					 prev_mass,
					 de_tests,
					 enough_reads);
		
#if VERBOSE
		fprintf(stderr, "Testing for differential TSS preference in locus %d-%d\n",
				sample_bundles.front()->left(),
				sample_bundles.front()->right());
#endif
		
		get_ds_tests(i,
					 curr_quant,
					 i-1,
					 prev_quant,
					 ds_tests,
					 enough_reads);
	}
	
	for (size_t i = 0; i < promoter_quants.size(); ++i)
	{
		const QuantGroup& genes = promoter_quants[i];
		double log_mass_curr = log(sample_masses[i]);
		for (size_t j = 0; j < genes.sub_quants.size(); ++j)
		{
			pair<FPKMTrackingTable::iterator,bool> inserted;
			pair<string, FPKMTracking > p;
			p = make_pair(genes.sub_quants[j].description, FPKMTracking());
			inserted = tracking.gene_fpkm_tracking.insert(p);
			
			FPKMTracking& fpkm_track = inserted.first->second;
			const QuantGroup& curr_jq = genes.sub_quants[j]; 
			double curr = curr_jq.FPKM;
			double curr_fpkm_var = curr_jq.FPKM_variance;
			double curr_counts = curr_jq.count;
			
			if (inserted.second)
			{
				fpkm_track.locus_tag = curr_jq.locus_tag;
				fpkm_track.tss_id = "-";
				fpkm_track.gene_names.insert(curr_jq.gene_names.begin(), 
											 curr_jq.gene_names.end());
				fpkm_track.protein_ids.insert(curr_jq.protein_ids.begin(), 
											  curr_jq.protein_ids.end());
				fpkm_track.names.insert(fpkm_track.names.end(),
										curr_jq.names.begin(), 
										curr_jq.names.end());
				fpkm_track.ref_match_ids.insert(fpkm_track.ref_match_ids.end(),
												curr_jq.closest_ref_matches.begin(), 
												curr_jq.closest_ref_matches.end());
				fpkm_track.classcode = curr_jq.classcode;
			}
			
			FPKMContext r1(curr_counts, curr, curr_fpkm_var, log_mass_curr);
			inserted.first->second.fpkm_series.push_back(r1);
		}
	}
	
#if ENABLE_THREADS
	test_storage_lock.unlock();
#endif	
}

void quantitation_worker(const RefSequenceTable& rt,
						 vector<HitBundle*>* sample_bundles,
						 const vector<long double>& sample_masses,
						 Tests& tests,
						 Tracking& tracking)
{
#if ENABLE_THREADS
	boost::this_thread::at_thread_exit(decr_pool_count);
#endif
	test_differential(rt, *sample_bundles, sample_masses, tests, tracking);
	
	for (size_t i = 0; i < sample_bundles->size(); ++i)
	{
		delete (*sample_bundles)[i];
	}
	
	delete sample_bundles;
}

template<typename T>
string cat_strings(const T& container)
{
	string cat;
	if (container.empty())
	{
		cat = "";
	}
	else
	{
		typename T::const_iterator itr = container.begin();
		cat = *(itr);
		for (++itr; itr != container.end(); ++itr)
		{
			cat += "," + *itr;
		}
	}

	return cat;
}

void print_tests(FILE* fout,
				 const char* label,
				 const SampleDiffs& de_tests)
{
	fprintf(fout, "test_id\tgene\tlocus\tstatus\tvalue_1\tvalue_2\t%s\ttest_stat\tp_value\tsignificant\n", label);
	for (SampleDiffs::const_iterator itr = de_tests.begin(); 
		 itr != de_tests.end(); 
		 ++itr)
	{
		const SampleDifference& test = itr->second;
		
		string all_iso_names = cat_strings(test.names);
		if (all_iso_names == "")
			all_iso_names = "-";
		
		string all_gene_names = cat_strings(test.gene_names);
		if (all_gene_names == "")
			all_gene_names = "-";
		
		string all_protein_ids = cat_strings(test.protein_ids);	
		if (all_protein_ids == "")
			all_protein_ids = "-";
		
		fprintf(fout, "%s\t%s\t%s", itr->first.c_str(), all_gene_names.c_str(), test.locus_desc.c_str());
		
		if (test.test_status != FAIL)
		{
			double t = test.test_stat;
			double r1 = test.value_1;
			double r2 = test.value_2;
			double d = test.differential;
			double p = test.p_value;
			const char* sig;
			if (test.significant && test.test_status == OK)
				sig = "yes";
			else
				sig = "no";
			
			const char* status;
			if (test.test_status == OK)
				status = "OK";
			else
				status = "NOTEST";
			
			fprintf(fout, "\t%s\t%lg\t%lf\t%lg\t%lg\t%lg\t%s", status, r1, r2, d, t, p, sig);
			fprintf(fout, "\n");
		}
		else
		{
			fprintf(fout, "\tFAIL\t0.0\t0.0\t0.0\t0.0\t1.0\tno\n");
		}
	}
}

void print_FPKM_tracking(FILE* fout, 
						 const FPKMTrackingTable& tracking)
{
	fprintf(fout,"ref_trans_id\tclass_code\tgene_short_name\ttss_id\tlocus");
	FPKMTrackingTable::const_iterator first_itr = tracking.begin();
	if (first_itr != tracking.end())
	{
		const FPKMTracking& track = first_itr->second;
		const vector<FPKMContext>& fpkms = track.fpkm_series;
		for (size_t i = 0; i < fpkms.size(); ++i)
		{
			fprintf(fout, "\tq%lu_FPKM\tq%lu_conf_lo\tq%lu_conf_hi", i, i, i);
		}
	}
	fprintf(fout, "\tref_id\n");
	for (FPKMTrackingTable::const_iterator itr = tracking.begin(); itr != tracking.end(); ++itr)
	{
		const string& description = itr->first;
		const FPKMTracking& track = itr->second;
		const vector<FPKMContext>& fpkms = track.fpkm_series;
		
		string all_gene_names = cat_strings(track.gene_names);
		if (all_gene_names == "")
			all_gene_names = "-";
		
		fprintf(fout, "%s\t%c\t%s\t%s\t%s", 
				description.c_str(),
				track.classcode ? track.classcode : '-',
				all_gene_names.c_str(), 
				track.tss_id == "" ? "-" : track.tss_id.c_str(),
				track.locus_tag.c_str());
		
		for (size_t i = 0; i < fpkms.size(); ++i)
		{
			double fpkm = fpkms[i].FPKM;
			double std_dev = sqrt(fpkms[i].FPKM_variance);
			double fpkm_conf_hi = fpkm + 2.0 * std_dev;
			double fpkm_conf_lo = max(0.0, fpkm - 2.0 * std_dev);
			fprintf(fout, "\t%lg\t%lg\t%lg", fpkm, fpkm_conf_lo, fpkm_conf_hi);
		}
		
		string all_ref_names = cat_strings(itr->second.ref_match_ids);
		if (all_ref_names == "")
			all_ref_names = "-";
		
		fprintf(fout, "\t%s\n", all_ref_names.c_str());
	}
}

bool p_value_lt(const SampleDifference* lhs, const SampleDifference* rhs)
{
	return lhs->p_value < rhs->p_value;
}

// Benjamani-Hochberg procedure
void fdr_significance(double fdr, 
					  vector<SampleDifference*>& tests)
{
	sort(tests.begin(), tests.end(), p_value_lt);
	int rank = 0;
	for (int k = 0; k < (int)tests.size(); ++k)
	{
		if (tests[k]->test_status == OK)
		{
			rank++;
			double r = (double)tests.size() / (rank);
			double corrected_p = tests[k]->p_value * r;
			tests[k]->significant = (corrected_p <= fdr);
		}
		else
		{
			tests[k]->significant = false;
		}
	}
}

void extract_sample_diffs(SampleDiffs& diff_map,
						  vector<SampleDifference*>& diffs)
{
	for (SampleDiffs::iterator itr = diff_map.begin();
		 itr != diff_map.end();
		 ++itr)
	{
		diffs.push_back(&(itr->second));
	}
}

void driver(FILE* ref_gtf, vector<FILE*>& sam_hit_files, Outfiles& outfiles)
{
	ReadTable it;
	RefSequenceTable rt(true, false);
	
	vector<Scaffold> ref_mRNAs;
	load_ref_rnas(ref_gtf, rt, ref_mRNAs);
	if (ref_mRNAs.empty())
		return;
	
	vector<LocusBundleFactory> bundle_factories;
	vector<long double> map_masses;
	for (size_t i = 0; i < sam_hit_files.size(); ++i)
	{
		SAMHitFactory hs(it, rt);
		LocusBundleFactory lf(hs, sam_hit_files[i]);
		bundle_factories.push_back(lf);
		BundleFactory standard_factory(hs, sam_hit_files[i], NULL);
		
		fprintf(stderr, "Counting hits in sample %lu\n", i);
		long double map_mass = get_map_mass(standard_factory);
		map_masses.push_back(map_mass);
	}
	
	vector<Scaffold>::iterator curr_ref_scaff = ref_mRNAs.begin();
	
	RefID last_ref_seen = curr_ref_scaff->ref_id();
	int left_boundary = curr_ref_scaff->left();
	int right_boundary = curr_ref_scaff->right();
	
	vector<Scaffold>::iterator ref_scaff_bundle_start = curr_ref_scaff;
	Tests tests;
	
	tests.isoform_de_tests = vector<SampleDiffs>((int)sam_hit_files.size() - 1);
	tests.tss_group_de_tests = vector<SampleDiffs>((int)sam_hit_files.size() - 1);
	tests.gene_de_tests = vector<SampleDiffs>((int)sam_hit_files.size() - 1);
	tests.cds_de_tests = vector<SampleDiffs>((int)sam_hit_files.size() - 1);
	tests.diff_splicing_tests = vector<SampleDiffs>((int)sam_hit_files.size() - 1);
	tests.diff_promoter_tests = vector<SampleDiffs>((int)sam_hit_files.size() - 1);
	tests.diff_cds_tests = vector<SampleDiffs>((int)sam_hit_files.size() - 1);
	
	Tracking tracking;
	
	while (curr_ref_scaff != ref_mRNAs.end())
	{
		if (curr_ref_scaff->left() > right_boundary ||
			curr_ref_scaff->ref_id() != last_ref_seen)
		{
#if ENABLE_THREADS			
			while(1)
			{
				thread_pool_lock.lock();
				if (curr_threads < num_threads)
				{
					thread_pool_lock.unlock();
					break;
				}
				
				thread_pool_lock.unlock();
				
				boost::this_thread::sleep(boost::posix_time::milliseconds(5));
				
			}
#endif
			
			vector<Scaffold> ref_mrnas;
			
			ref_mrnas.insert(ref_mrnas.end(), 
							 ref_scaff_bundle_start, 
							 curr_ref_scaff);
			
			vector<HitBundle*>* sample_bundles = new vector<HitBundle*>();
			
			// grab the alignments for this locus in each of the samples
			make_sample_bundles(ref_mrnas, bundle_factories, *sample_bundles);
			bool non_empty_bundle = false;
			for (size_t i = 0; i < sample_bundles->size(); ++i)
			{
				if (!(*sample_bundles)[i]->hits().empty())
				{
					non_empty_bundle = true;
					break;
				}
			}
			if (non_empty_bundle)
			{
				RefID bundle_chr_id = sample_bundles->front()->ref_id();
				assert (bundle_chr_id != 0);
				const char* chr_name = rt.get_name(bundle_chr_id);
				assert (chr_name);
				fprintf(stderr, "Quantitating samples in locus [ %s:%d-%d ] \n", 
						chr_name,
						sample_bundles->front()->left(),
						sample_bundles->front()->right());
			
			
#if ENABLE_THREADS			
				thread_pool_lock.lock();
				curr_threads++;
				thread_pool_lock.unlock();
				
				thread quantitate(quantitation_worker,
								  boost::cref(rt), 
								  sample_bundles, 
								  boost::cref(map_masses), 
								  boost::ref(tests),
								  boost::ref(tracking));
#else
				quantitation_worker(boost::cref(rt), 
									sample_bundles, 
									boost::cref(map_masses), 
									boost::ref(tests),
									boost::ref(tracking));
#endif
			}
			left_boundary = curr_ref_scaff->left();
			if (curr_ref_scaff->ref_id() != last_ref_seen)
			{
				right_boundary = curr_ref_scaff->right();
			}
			last_ref_seen = curr_ref_scaff->ref_id();
			ref_scaff_bundle_start = curr_ref_scaff;
		}
		right_boundary = max(right_boundary, curr_ref_scaff->right());
		++curr_ref_scaff;
	}
	
	if (ref_scaff_bundle_start != ref_mRNAs.end())
	{
		vector<Scaffold> ref_mrnas;
		
		ref_mrnas.insert(ref_mrnas.end(), 
						 ref_scaff_bundle_start, 
						 curr_ref_scaff);
		
		vector<HitBundle*> sample_bundles;
		
		// grab the alignments for this locus in each of the samples
		make_sample_bundles(ref_mrnas, bundle_factories, sample_bundles);
		bool non_empty_bundle = false;
		for (size_t i = 0; i < sample_bundles.size(); ++i)
		{
			if (!sample_bundles[i]->hits().empty())
			{
				non_empty_bundle = true;
				break;
			}
		}
		if (non_empty_bundle)
		{
			RefID bundle_chr_id = sample_bundles.front()->ref_id();
			assert (bundle_chr_id != 0);
			const char* chr_name = rt.get_name(bundle_chr_id);
			assert (chr_name);
			fprintf(stderr, "Quantitating samples in locus [ %s:%d-%d ] \n", 
					chr_name,
					sample_bundles.front()->left(),
					sample_bundles.front()->right());
			test_differential(rt, sample_bundles, map_masses, tests, tracking);
			
			for (size_t i = 0; i < sample_bundles.size(); ++i)
			{
				delete sample_bundles[i];
			}
		}
	}
	
	// wait for the workers to finish up before reporting everthing.
#if ENABLE_THREADS	
	while(1)
	{
		thread_pool_lock.lock();
		if (curr_threads == 0)
		{
			thread_pool_lock.unlock();
			break;
		}
		
		thread_pool_lock.unlock();
		//fprintf(stderr, "waiting to for all workers to finish\n");
		boost::this_thread::sleep(boost::posix_time::milliseconds(5));
	}
#endif
	
	//double FDR = 0.05;
	int total_iso_de_tests = 0;
	
	vector<SampleDifference*> isoform_exp_diffs;
	for (size_t i = 0; i < tests.isoform_de_tests.size(); ++i)
	{
		total_iso_de_tests += tests.isoform_de_tests[i].size();
		extract_sample_diffs(tests.isoform_de_tests[i], isoform_exp_diffs);
	}
	fdr_significance(FDR, isoform_exp_diffs);
	fprintf(stderr, "Reporting %d isoform-level transcription differences\n", total_iso_de_tests);
	for (size_t i = 0; i < tests.isoform_de_tests.size(); ++i)
	{
		FILE* fout = outfiles.isoform_de_outfiles[i];
		print_tests(fout, "log(fold_change)", tests.isoform_de_tests[i]);
	}
	
	int total_group_de_tests = 0;
	vector<SampleDifference*> tss_group_exp_diffs;
	for (size_t i = 0; i < tests.tss_group_de_tests.size(); ++i)
	{
		extract_sample_diffs(tests.tss_group_de_tests[i], tss_group_exp_diffs);
		total_group_de_tests += tests.tss_group_de_tests[i].size();
	}
	fdr_significance(FDR, tss_group_exp_diffs);
	fprintf(stderr, "Reporting %d tss-group-level transcription differences\n", total_group_de_tests);
	for (size_t i = 0; i < tests.tss_group_de_tests.size(); ++i)
	{
		FILE* fout = outfiles.group_de_outfiles[i];
		print_tests(fout, "log(fold_change)", tests.tss_group_de_tests[i]);
	}
	
	int total_gene_de_tests = 0;
	vector<SampleDifference*> gene_exp_diffs;
	for (size_t i = 0; i < tests.gene_de_tests.size(); ++i)
	{
		total_gene_de_tests += tests.gene_de_tests[i].size();
		extract_sample_diffs(tests.gene_de_tests[i], gene_exp_diffs);
	}
	fdr_significance(FDR, gene_exp_diffs);
	fprintf(stderr, "Reporting %d gene-level transcription differences\n", total_gene_de_tests);
	for (size_t i = 0; i < tests.gene_de_tests.size(); ++i)
	{
		FILE* fout = outfiles.gene_de_outfiles[i];
		print_tests(fout, "log(fold_change)", tests.gene_de_tests[i]);
	}	

	int total_cds_de_tests = 0;
	vector<SampleDifference*> cds_exp_diffs;
	for (size_t i = 0; i < tests.cds_de_tests.size(); ++i)
	{
		total_cds_de_tests += tests.cds_de_tests[i].size();
		extract_sample_diffs(tests.cds_de_tests[i], cds_exp_diffs);
	}
	fdr_significance(FDR, cds_exp_diffs);
	fprintf(stderr, "Reporting %d CDS-level transcription differences\n", total_cds_de_tests);
	for (size_t i = 0; i < tests.cds_de_tests.size(); ++i)
	{
		FILE* fout = outfiles.cds_de_outfiles[i];
		print_tests(fout, "log(fold_change)", tests.cds_de_tests[i]);
	}
	
	int total_diff_splice_tests = 0;
	vector<SampleDifference*> splicing_diffs;
	for (size_t i = 0; i < tests.diff_splicing_tests.size(); ++i)
	{
		total_diff_splice_tests += tests.diff_splicing_tests[i].size();
		extract_sample_diffs(tests.diff_splicing_tests[i], splicing_diffs);
	}
	fprintf(stderr, "Reporting %d splicing differences\n", total_diff_splice_tests);
	fdr_significance(FDR, splicing_diffs);
	for (size_t i = 0; i < tests.diff_splicing_tests.size(); ++i)
	{
		FILE* fout = outfiles.diff_splicing_outfiles[i];
		const SampleDiffs& diffs = tests.diff_splicing_tests[i];
		print_tests(fout, "sqrt(JS)", diffs);
	}
	
	int total_diff_promoter_tests = 0;
	vector<SampleDifference*> promoter_diffs;
	for (size_t i = 0; i < tests.diff_splicing_tests.size(); ++i)
	{
		total_diff_promoter_tests += tests.diff_promoter_tests[i].size();
		extract_sample_diffs(tests.diff_promoter_tests[i], promoter_diffs);

	}
	fdr_significance(FDR, promoter_diffs);
	fprintf(stderr, "Reporting %d transcription start differences\n", total_diff_promoter_tests);
	for (size_t i = 0; i < tests.diff_promoter_tests.size(); ++i)
	{
		FILE* fout = outfiles.diff_promoter_outfiles[i];
		print_tests(fout, "sqrt(JS)", tests.diff_promoter_tests[i]);
	}

	int total_diff_cds_tests = 0;
	vector<SampleDifference*> cds_use_diffs;
	for (size_t i = 0; i < tests.diff_cds_tests.size(); ++i)
	{
		extract_sample_diffs(tests.diff_cds_tests[i], cds_use_diffs);
		total_diff_cds_tests += tests.diff_cds_tests[i].size();
	}
	fdr_significance(FDR, cds_use_diffs);
	fprintf(stderr, "Reporting %d relative CDS differences\n", total_diff_cds_tests);
	for (size_t i = 0; i < tests.diff_cds_tests.size(); ++i)
	{
		FILE* fout = outfiles.diff_cds_outfiles[i];
		print_tests(fout, "sqrt(JS)", tests.diff_cds_tests[i]);
	}
	
	FILE* fiso_fpkm_tracking =  outfiles.isoform_fpkm_tracking_out;
	fprintf(stderr, "Writing isoform-level FPKM tracking\n");
	print_FPKM_tracking(fiso_fpkm_tracking,tracking.isoform_fpkm_tracking); 
	
	FILE* ftss_fpkm_tracking =  outfiles.tss_group_fpkm_tracking_out;
	fprintf(stderr, "Writing TSS group-level FPKM tracking\n");
	print_FPKM_tracking(ftss_fpkm_tracking,tracking.tss_group_fpkm_tracking);
	
	FILE* fgene_fpkm_tracking =  outfiles.gene_fpkm_tracking_out;
	fprintf(stderr, "Writing gene-level FPKM tracking\n");
	print_FPKM_tracking(fgene_fpkm_tracking,tracking.gene_fpkm_tracking);
	
	FILE* fcds_fpkm_tracking =  outfiles.cds_fpkm_tracking_out;
	fprintf(stderr, "Writing CDS-level FPKM tracking\n");
	print_FPKM_tracking(fcds_fpkm_tracking,tracking.cds_fpkm_tracking);
}

int main(int argc, char** argv)
{
	int parse_ret = parse_options(argc,argv);
    if (parse_ret)
        return parse_ret;
	
	if(optind >= argc)
    {
        print_usage();
        return 1;
    }
	
    string ref_gtf_filename = argv[optind++];
	
	vector<FILE*> sam_hit_files;
	vector<string> sam_hit_file_names;
    while(optind < argc)
    {
        string sam_hits_file_name = argv[optind++];
		// Open the approppriate files
		FILE* sam_hits_file = fopen(sam_hits_file_name.c_str(), "r");
		if (sam_hits_file == NULL)
		{
			fprintf(stderr, "Error: cannot open SAM file %s for reading\n",
					sam_hits_file_name.c_str());
			exit(1);
		}
		
		sam_hit_files.push_back(sam_hits_file);
		sam_hit_file_names.push_back(sam_hits_file_name);
    }
    	
	while (sam_hit_files.size() < 2)
    {
        fprintf(stderr, "Error: cuffdiff requires at least 2 SAM files\n");
        exit(1);
    }
	
	// seed the random number generator - we'll need it for the importance
	// sampling during MAP estimation of the gammas
	srand48(time(NULL));
	
	FILE* ref_gtf = NULL;
	if (ref_gtf_filename != "")
	{
		ref_gtf = fopen(ref_gtf_filename.c_str(), "r");
		if (!ref_gtf)
		{
			fprintf(stderr, "Error: cannot open GTF file %s for reading\n",
					ref_gtf_filename.c_str());
			exit(1);
		}
	}
	
	
	// Note: we don't want the assembly filters interfering with calculations 
	// here
	min_isoform_fraction = 0.0;
	pre_mrna_fraction = 0.0;
	
	Outfiles outfiles;
	
	for (size_t i = 1; i < sam_hit_files.size(); ++i)
	{
		char out_file_prefix[64];
		sprintf(out_file_prefix, "%lu_%lu", i - 1, i);
		char iso_out_file_name[256];
		sprintf(iso_out_file_name, "%s_isoform_exp.diff", out_file_prefix);
		FILE* iso_out = fopen(iso_out_file_name, "w");
		if (!iso_out)
		{
			fprintf(stderr, "Error: cannot open differential isoform transcription file %s for writing\n",
					iso_out_file_name);
			exit(1);
		}
		
		char group_out_file_name[256];
		sprintf(group_out_file_name, "%s_tss_group_exp.diff", out_file_prefix);
		FILE* group_out = fopen(group_out_file_name, "w");
		if (!group_out)
		{
			fprintf(stderr, "Error: cannot open differential TSS group transcription file %s for writing\n",
					group_out_file_name);
			exit(1);
		}
		
		char gene_out_file_name[256];
		sprintf(gene_out_file_name, "%s_gene_exp.diff", out_file_prefix);
		FILE* gene_out = fopen(gene_out_file_name, "w");
		if (!group_out)
		{
			fprintf(stderr, "Error: cannot open gene expression file %s for writing\n",
					gene_out_file_name);
			exit(1);
		}
		
		char cds_out_file_name[256];
		sprintf(cds_out_file_name, "%s_cds_exp.diff", out_file_prefix);
		FILE* cds_out = fopen(cds_out_file_name, "w");
		if (!cds_out)
		{
			fprintf(stderr, "Error: cannot open cds expression file %s for writing\n",
					cds_out_file_name);
			exit(1);
		}
		
		char diff_splicing_out_file_name[256];
		sprintf(diff_splicing_out_file_name, "%s_splicing.diff", out_file_prefix);
		FILE* diff_splicing_out = fopen(diff_splicing_out_file_name, "w");
		if (!diff_splicing_out)
		{
			fprintf(stderr, "Error: cannot open differential splicing file %s for writing\n",
					diff_splicing_out_file_name);
			exit(1);
		}
		
		char diff_promoter_out_file_name[256];
		sprintf(diff_promoter_out_file_name, "%s_promoters.diff", out_file_prefix);
		FILE* diff_promoter_out = fopen(diff_promoter_out_file_name, "w");
		if (!diff_promoter_out)
		{
			fprintf(stderr, "Error: cannot open differential transcription start file %s for writing\n",
					diff_promoter_out_file_name);
			exit(1);
		}
		
		char diff_cds_out_file_name[256];
		sprintf(diff_cds_out_file_name, "%s_cds.diff", out_file_prefix);
		FILE* diff_cds_out = fopen(diff_cds_out_file_name, "w");
		if (!diff_cds_out)
		{
			fprintf(stderr, "Error: cannot open differential relative CDS file %s for writing\n",
					diff_cds_out_file_name);
			exit(1);
		}
		
		outfiles.isoform_de_outfiles.push_back(iso_out);
		outfiles.group_de_outfiles.push_back(group_out);
		outfiles.gene_de_outfiles.push_back(gene_out);
		outfiles.cds_de_outfiles.push_back(cds_out);
		outfiles.diff_splicing_outfiles.push_back(diff_splicing_out);
		outfiles.diff_promoter_outfiles.push_back(diff_promoter_out);
		outfiles.diff_cds_outfiles.push_back(diff_cds_out);
	}
	
	char isoform_fpkm_tracking_name[256];
	sprintf(isoform_fpkm_tracking_name, "isoforms.fpkm_tracking");
	FILE* isoform_fpkm_out = fopen(isoform_fpkm_tracking_name, "w");
	if (!isoform_fpkm_out)
	{
		fprintf(stderr, "Error: cannot open isoform-level FPKM tracking file %s for writing\n",
				isoform_fpkm_tracking_name);
		exit(1);
	}
	outfiles.isoform_fpkm_tracking_out = isoform_fpkm_out;

	char tss_group_fpkm_tracking_name[256];
	sprintf(tss_group_fpkm_tracking_name, "tss_groups.fpkm_tracking");
	FILE* tss_group_fpkm_out = fopen(tss_group_fpkm_tracking_name, "w");
	if (!tss_group_fpkm_out)
	{
		fprintf(stderr, "Error: cannot open TSS group-level FPKM tracking file %s for writing\n",
				tss_group_fpkm_tracking_name);
		exit(1);
	}
	outfiles.tss_group_fpkm_tracking_out = tss_group_fpkm_out;

	char cds_fpkm_tracking_name[256];
	sprintf(cds_fpkm_tracking_name, "cds.fpkm_tracking");
	FILE* cds_fpkm_out = fopen(cds_fpkm_tracking_name, "w");
	if (!cds_fpkm_out)
	{
		fprintf(stderr, "Error: cannot open CDS level FPKM tracking file %s for writing\n",
				cds_fpkm_tracking_name);
		exit(1);
	}
	outfiles.cds_fpkm_tracking_out = cds_fpkm_out;
	
	char gene_fpkm_tracking_name[256];
	sprintf(gene_fpkm_tracking_name, "genes.fpkm_tracking");
	FILE* gene_fpkm_out = fopen(gene_fpkm_tracking_name, "w");
	if (!gene_fpkm_out)
	{
		fprintf(stderr, "Error: cannot open gene-level FPKM tracking file %s for writing\n",
				gene_fpkm_tracking_name);
		exit(1);
	}
	outfiles.gene_fpkm_tracking_out = gene_fpkm_out;
	
    driver(ref_gtf, sam_hit_files, outfiles);
	
	return 0;
}

