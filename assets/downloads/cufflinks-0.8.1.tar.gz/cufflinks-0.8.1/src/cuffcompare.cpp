#ifdef HAVE_CONFIG_H
#include <config.h>
#else
#define PACKAGE_VERSION "INTERNAL"
#endif

#include "GArgs.h"
#include "GStr.h"
#include "GHash.hh"
#include "GList.hh"
//#include "GFastaFile.h"
#include "GFaSeqGet.h"
#include "gff.h"
#include <ctype.h>
#include "gtf_tracking.h"

#define USAGE "Usage:\n\
cuffcompare [-r <reference_mrna.gtf>][-R][-V][-s <seq_path>][-o <stats.txt>] \n\
    [-p <cprefix>] <input1.gtf> [<input2.gtf> .. <inputN.gtf>]\n\
\n\
 Provides various statistics for GTF mRNA data.\n\
 Tracks expression changes of loci across multiple input files, writing\n\
 matching transcripts (intron chains) into <stats>.tracking, and a GTF\n\
 file <stats>.combined.gtf showing a nonredundant set of transcripts \n\
 across all input files, with a single representative transcript selected\n\
 for each set of matching transcripts.\n\
 A file <input>.tmap is created for each input file, showing\n\
 how its transcripts overlap reference transcripts, while the file \n\
 <input>.refmap shows the matching and contained transcripts for each\n\
 reference transcript.\n\
\n\
Options:\n\
-o  write the stats into given file name <stats.txt> (instead of stdout)\n\
\n\
-d  max distance (range) for grouping transcript start sites (100)n\
\n\
-r  a set of known mRNAs to use as a reference for assessing \n\
    the accuracy of mRNAs or gene models given in <input.gtf>\n\
\n\
-R  for -r option, reduce the set of reference transcripts to \n\
    only those found to overlap any of the input loci\n\
\n\
-s  look into <seq_dir> for fasta files with the \n\
    underlying genomic sequences (one file per contig) and use\n\
    lower case bases to classify input transcripts as repeats\n\
\n\
-p  the name prefix to use for consensus transcripts in the \n\
    <stats>.combined.gtf file (default: 'TCONS')\n\
\n\
-V  (mildly) verbose processing mode\n\
"

bool debug=false;
bool perContigStats=true;
bool reduceRefs=false;
bool checkFasta=false;
bool verbose=false;
bool qtracking=true;
int dbgCounter=0;

//FILE* xpfile=NULL;
/* special request, report xloci with:
    1) multiple ref isoforms where at least 2 of the isoforms share the first exon
      while their CDS differs!
    2) there are matching cufflinks assemblies in different timepoints for at least 2 these ref isoforms
    3) the relative abundances of the matching cufflinks isoforms change over the time course
       (suggesting differential splicing)

  ATTENTION: the CDS data should be provided in the reference input file !
 */

int polyrun_range=2000; //polymerase run range 2KB
double scoreThreshold=0;
double exprThreshold=0;
char* cprefix=NULL;
FILE* ffasta=NULL; //genomic seq file
FILE *f_ref=NULL; //reference mRNA GFF, if provided
FILE* f_in=NULL; //sequentially, each input GFF file
FILE* f_out=NULL; //stdout if not provided
const char* fastadir=NULL;
int xlocnum=0;
int tsscl_num=0; //for tss cluster IDs
int protcl_num=0; //for "unique" protein IDs within TSS clusters
double code_version=0.82;
int tssDist=100;
//int total_tcons=0;
int total_xloci_alt=0;

#define EQCHAIN_TAG     0x80000
#define EQCHAIN_TAGMASK 0xFFFFF

void printFasta(FILE* f, GStr& defline, char* seq, int seqlen=-1) {
 if (seq==NULL) return;
 int len=(seqlen>0)?seqlen:strlen(seq);
 if (len<=0) return;
 if (!defline.is_empty())
     fprintf(f, ">%s\n",defline.chars());
 int ilen=0;
 for (int i=0; i < len; i++, ilen++) {
   if (ilen == 70) {
     fputc('\n', f);
     ilen = 0;
     }
   putc(seq[i], f);
   } //for
 fputc('\n', f);

}

//callback for a parsed GFF record

void openfw(FILE* &f, GArgs& args, char opt) {
  GStr s=args.getOpt(opt);
  if (!s.is_empty()) {
      if (s=='-')
       f=stdout;
      else {
       f=fopen(s,"w");
       if (f==NULL) GError("Error creating file: %s\n", s.chars());
       }
     }
}

//-- structure to keep track of data from multiple qry input files for a single genomic seq
class GSeqTrack {
 public:
  int gseq_id;
  GList<GLocus>* rloci_f; //reference loci for this genomic sequence
  GList<GLocus>* rloci_r;
  GList<GXLocus> xloci_f; // extended super-loci across all qry datasets
  GList<GXLocus> xloci_r; // extended super-loci across all qry datasets
  GList<GXLocus> xloci_u; // extended super-loci across all qry datasets
  GSeqData* qdata[MAX_QFILES]; //fixed order array with GSeqData for each qry input
                 //element in array is NULL if a qry file has no transcripts on this genomic sequence
  GSeqTrack(int gid=-1):xloci_f(true,true,false),
        xloci_r(true,true,false), xloci_u(true,true,false) {
    gseq_id=gid;
    rloci_f=NULL;
    rloci_r=NULL;
    for (int i=0;i<MAX_QFILES;i++) qdata[i]=NULL;
    }
  bool operator==(GSeqTrack& d){
      return (gseq_id==d.gseq_id);
      }
  bool operator>(GSeqTrack& d){
     return (gseq_id>d.gseq_id);
     }
  bool operator<(GSeqTrack& d){
     return (gseq_id<d.gseq_id);
     }
};


char* getFastaFile(int gseq_id);

// ref globals
bool haveRefs=false;  //if a reference is given => full metrics generated

GList<GSeqData> ref_data(true,true,true); //list of reference mRNAs and loci data for each genomic seq
              //each locus will keep track of any superloci which includes it, formed during the analysis

void processLoci(GSeqData& seqdata, GSeqData* refdata=NULL, GFaSeqGet* faseq=NULL, int qfidx=0);

void reportStats(FILE* fout, char* setname, GSuperLocus& stotal,
       GSeqData* seqdata=NULL, GSeqData* refdata=NULL);

char* getGSeqName(int gid); //returns the name of a genomic sequence

GSeqData* getQryData(int gid, GList<GSeqData>& qdata);
void trackGData(int qcount, GList<GSeqTrack>& gtracks, GStr& fbasename, FILE** ftr, FILE** frs);

#define FWCLOSE(fh) if (fh!=NULL && fh!=stdout) fclose(fh)
#define FRCLOSE(fh) if (fh!=NULL && fh!=stdin) fclose(fh)

/*FILE* f_nloci=NULL; //non-matching/imperfect matching ref loci
FILE* f_mloci=NULL; //missed ref loci
FILE* f_nintr=NULL; //imperfectly matching ref introns
FILE* f_mintr=NULL; //missed ref introns
FILE* f_qintr=NULL; //"bad" qry introns, overlapping but
                // not perfectly matching ref introns
*/                
bool multiexon_only=false;

GHash<GStr> refdescr;
void loadRefDescr(const char* fname);

GList<GStr> qryfiles(false,true,false);

//list of GSeqTrack data, sorted by gseq_id
GList<GSeqTrack> gseqtracks(true,true,true);
GSeqTrack* findGSeqTrack(int gsid);

int main(int argc, char * const argv[]) {
	GArgs args(argc, argv, "XDMVGCKRLp:c:d:s:i:r:o:");
	int e;
	if ((e=args.isError())>0)
		GError("%s\nInvalid argument: %s\n", USAGE, argv[e]);
	if (args.getOpt('h')!=NULL){
		GError("cuffcompare v%s\n", PACKAGE_VERSION); 
		GError("-----------------------------\n"); 
		GError("%s\n", USAGE);
	}
	debug=(args.getOpt('D')!=NULL);
	bool checkseq=(args.getOpt('s')!=NULL);
	multiexon_only=(args.getOpt('M')!=NULL);
	perContigStats=(args.getOpt('G')==NULL);
	//XPeriment=(args.getOpt('X')!=NULL);

	//qtracking=(args.getOpt('T')==NULL); //use -T to disable tracking
	checkFasta=(args.getOpt('K')!=NULL);
	verbose=(args.getOpt('V')!=NULL);
        int numqryfiles=args.startNonOpt();
        if (numqryfiles==0) 
		{
			GError("cuffcompare v%s\n-----------------------------\n%s\n", PACKAGE_VERSION, USAGE);
		}
        if (numqryfiles>MAX_QFILES) {
           GMessage("Error: too many input files (limit set to %d at compile time)\n",MAX_QFILES);
           GMessage("(if you need to raise this limit set a new value for\nMAX_QFILES in gtf_tracking.h and recompile)\n");
           exit(0x5000);
           }
	//if (s.is_empty()) GError("Error: required parameter -g missing!\n");
	GStr s=args.getOpt('c');
	if (!s.is_empty()) scoreThreshold=s.asReal();
	s=args.getOpt('p');
	if (!s.is_empty()) cprefix=Gstrdup(s.chars());
   	             else  cprefix=Gstrdup("TCONS");
	s=args.getOpt('e');
	if (!s.is_empty()) exprThreshold=s.asReal();
	s=args.getOpt('d');
  if (!s.is_empty()) {
     tssDist=s.asInt();
     }
	s=args.getOpt('i');
	if (!s.is_empty()) loadRefDescr(s.chars());
	s=args.getOpt('r');
	if (!s.is_empty()) {
		f_ref=fopen(s,"r");
		if (f_ref==NULL) GError("Error opening reference gff: %s\n",s.chars());
		haveRefs=true;
		if (verbose) GMessage("Loading reference transcripts..\n");
		read_mRNAs(f_ref, checkseq, ref_data, ref_data, s.chars());
		haveRefs=(ref_data.Count()>0);
		reduceRefs=(args.getOpt('R')!=NULL);
		if (verbose) GMessage("..ref data loaded\n");
	}

	s=args.getOpt('o');
	if (s.is_empty()) s="stdout";
	else {
		int di=s.rindex('.');
		if (di>0) s.cut(di);
	}
	GStr fbasename=s;
	
	fastadir=args.getOpt('s');
	//bool reportLoci=(args.getOpt('L')!=NULL);
	openfw(f_out, args, 'o');
	if (f_out==NULL) f_out=stdout;
	fprintf(f_out, "# Cuffcompare version %4.2f | Command line was:\n#", code_version);
	for (int i=0;i<argc-1;i++) 
		fprintf(f_out, "%s ", argv[i]);
	fprintf(f_out, "%s\n#\n", argv[argc-1]);
	int qfileno=0;
	GList<GSeqData>** qrysdata=NULL;
	FILE** tfiles=NULL;
	FILE** rtfiles=NULL;
        GMALLOC(qrysdata, numqryfiles*sizeof(GList<GSeqData>*));
	if (qtracking) {
	    GMALLOC(tfiles, numqryfiles*sizeof(FILE*));
	    GMALLOC(rtfiles, numqryfiles*sizeof(FILE*));
	    }
	char* infile;
        args.startNonOpt();
	while ((infile=args.nextNonOpt())!=NULL) {
            GStr infname(infile);
            if (verbose) GMessage("Processing file: %s\n",infile);
            qryfiles.Add(new GStr(infname));
            //GMessage("%s added to qryfiles\n",infname.chars());
            if (strcmp(infile,"-")==0) { f_in=stdin; infname="stdin"; }
			else {
				f_in=fopen(infile,"r");
				if (f_in==NULL)
                    GError("Cannot open input file %s!\n",infile);
			}
			//f_in is the opened gff file to process
			if (qtracking) {
				s=infname;
				int di=s.rindex('.');
				if (di>0) s.cut(di);
				//now s is the base name of the qryfile
				GStr sbase(s);
				s.append(".tmap");
				tfiles[qfileno]=fopen(s.chars(),"w");
				if (tfiles[qfileno]==NULL)
					GError("Error creating file '%s'!\n",s.chars());
				fprintf(tfiles[qfileno],"ref_gene_id\tref_id\tclass_code\tcuff_gene_id\tcuff_id\tFMI\tFPKM\tFPKM_conf_hi\tFPKM_conf_lo\tcov\tlen\tmajor_iso_id\n");
				s=sbase;
				s.append(".refmap");
				rtfiles[qfileno]=fopen(s.chars(),"w");
				if (rtfiles[qfileno]==NULL)
					GError("Error creating file '%s'!\n",s.chars());
				fprintf(rtfiles[qfileno],"ref_gene_id\tref_id\tclass_code\tcuff_id_list\n");
        }

			GList<GSeqData>* pdata=new GList<GSeqData>(true,true,true);
			qrysdata[qfileno]=pdata;
			if (verbose) GMessage("Loading transcripts from %s..\n",infname.chars());
			read_mRNAs(f_in, checkseq, ref_data, *pdata, infname.chars(),qfileno);
			GSuperLocus gstats;
			GFaSeqGet *faseq=NULL;
			for (int g=0;g<pdata->Count();g++) { //for each seqdata related to a genomic sequence
				int gsid=pdata->Get(g)->gseq_id;
				GSeqData* refdata=getRefData(gsid, ref_data);//ref data for this contig
				//read sequence if requested
				//faseq=NULL;
                                /*
				if (fastadir && reportLoci) {
					char* sfile=getFastaFile(gsid);
					if (sfile!=NULL) {
						if (verbose) GMessage("Processing sequence from fasta file '%s'\n",sfile);
						faseq=new GFaSeqGet(sfile,0,checkFasta);
						faseq->loadall();
						GFREE(sfile);
					}
				 }
                                */
				processLoci(*(pdata->Get(g)), refdata, faseq, qfileno);
				GSeqTrack* seqtrack=findGSeqTrack(gsid); //this will add a gseqtrack if it doesn't exist
				// for gsid
				if (refdata!=NULL) {
					seqtrack->rloci_f=&(refdata->loci_f);
					seqtrack->rloci_r=&(refdata->loci_r);
				}
				seqtrack->qdata[qfileno]=pdata->Get(g);
				//will only gather data into stats if perContig==false
				reportStats(f_out, getGSeqName(gsid), gstats,
							pdata->Get(g), refdata);
				if (faseq!=NULL) delete faseq;
			} //for each genomic sequence data
			//there could be genomic sequences with no qry transcripts
			//but with reference transcripts
			if (haveRefs && !reduceRefs) {
				for (int r=0;r<ref_data.Count();r++) {
					GSeqData* refdata=ref_data[r];
					int gsid=refdata->gseq_id;
					if (getQryData(gsid, *pdata)==NULL) {
						reportStats(f_out, getGSeqName(gsid), gstats, NULL, refdata);
					}//completely missed all refdata on this contig
				}
            }
			//now report the summary:
			reportStats(f_out, infile, gstats);
			if (f_in!=stdin) fclose(f_in);
			/*if (reportLoci) {
				fclose(f_nloci);
				fclose(f_mloci);
				fclose(f_nintr);
				fclose(f_mintr);
				fclose(f_qintr);
			        }*/
			qfileno++;
	}//while input files
	if (qtracking) {
		if (verbose) GMessage("Tracking transcripts..\n");
		/*
		if (numqryfiles>1 && XPeriment) {
		   GStr sp(fbasename);
		   sp.append(".xp");
		   xpfile=fopen(sp.chars(),"w");
		   if (xpfile==NULL)
             GError("Error creating file '%s'!\n",sp.chars());
		   }
		*/
		trackGData(numqryfiles, gseqtracks, fbasename, tfiles, rtfiles);
        //if (xpfile!=NULL) fclose(xpfile);
        fprintf(f_out, "\n Total union super-loci across all datasets: %d \n", xlocnum);
        fprintf(f_out, "  (%d multi-transcript, ~%.1f transcripts per locus)\n",
            total_xloci_alt, ((double)(GXConsensus::count))/xlocnum);

	    }
	if (verbose) GMessage("Cleaning up..\n");
	GFREE(cprefix);
	// clean up
	GFREE(tfiles);
	for (int i=0;i<numqryfiles;i++) {
		delete qrysdata[i];
    }
	GFREE(qrysdata);
	if (qtracking) {
		GFREE(tfiles);
		GFREE(rtfiles);
	}
	gseqtracks.Clear();
	FRCLOSE(f_ref);
	FWCLOSE(f_out);
	if (verbose) GMessage("Done.\n");
	ref_data.Clear();
	//getchar();
} //main ends here

void show_exons(FILE* f, GffObj& m) {
  fprintf(f,"(");
  int imax=m.exons.Count()-1;
  for (int i=0;i<=imax;i++) {
    if (i==imax) fprintf(f,"%d-%d)",m.exons[i]->start, m.exons[i]->end);
            else fprintf(f,"%d-%d,",m.exons[i]->start, m.exons[i]->end);
    }
}

bool ichainMatch(GffObj* t, GffObj* r, bool& exonMatch, int fuzz=0) {
  //t's intron chain is considered matching to reference r
  //if r chain is the same or a subset of  t's chain
  exonMatch=false;
  int imax=r->exons.Count()-1;
  int jmax=t->exons.Count()-1;
  //single-exon mRNAs ?
  if (imax==0 || jmax==0) {
     //only consider match if both are single exon
     if (imax!=jmax) return false;
     exonMatch=r->exons[0]->coordMatch(t->exons[0],fuzz);
     /*if (exonMatch) return true;
       else return (r->exons[0]->start>=t->exons[0]->start &&
                    r->exons[0]->end<=t->exons[0]->end);*/
     return exonMatch;
     }

  if (r->exons[imax]->start<t->exons[0]->end ||
      t->exons[jmax]->start<r->exons[0]->end ) //intron chains do not overlap at all
          {
           return false;
          }
  //check intron overlaps
  int i=1;
  int j=1;
  bool exmism=false; //any mismatch
  while (i<=imax && j<=jmax) {
     uint rstart=r->exons[i-1]->end;
     uint rend=r->exons[i]->start;
     uint tstart=t->exons[j-1]->end;
     uint tend=t->exons[j]->start;
     if (tend<rstart) { j++; continue; }
     if (rend<tstart) { i++; continue; }
     break; //here we have an intron overlap
     }
  if (i>1 || i>imax || j>jmax) {
      return false; //no intron overlaps found at all
                   //or first intron of ref not overlapping
      }
  //from now on we expect intron matches up to imax
  if (i!=j || imax!=jmax) { exmism=true; if (fuzz==0) return false; }
  for (;i<=imax && j<=jmax;i++,j++) {
    if (abs((int)(r->exons[i-1]->end-t->exons[j-1]->end))>fuzz ||
        abs((int)(r->exons[i]->start-t->exons[j]->start))>fuzz) {
        return false; //just run away
        }
    }
  //if we made it here, we have matching intron chains up to MIN(imax,jmax)
  if (imax!=jmax) {
     exmism=true;
     if (jmax<imax) return false; // qry ichain included in ref ichain
                     else //ref ichain included in qry ichain
                      if (fuzz==0) return false;
     }
  if (exmism) {
          //exonMatch=false; -- it's default
          return true;
          }
  exonMatch = ( abs((int)(r->exons[0]->start-t->exons[0]->start))<=fuzz &&
               abs((int)(r->exons[imax]->end-t->exons[jmax]->end))<=fuzz );
  return true;
}


void compareLoci2R(GList<GLocus>& loci, GList<GSuperLocus>& cmpdata,
                             GList<GLocus>& refloci, int qfidx) {
 cmpdata.Clear();//a new list of superloci will be built
 if (refloci.Count()==0 || loci.Count()==0) return;
 //reset cmpovl and stats
 for (int i=0;i<refloci.Count();i++) refloci[i]->creset();
 //find loci with overlapping refloci
 //and store cmpovl links both ways for ALL loci and refloci on this strand
 for (int l=0;l<loci.Count();l++) {
   GLocus* locus=loci[l];
   locus->creset();
   for (int j=0;j<refloci.Count();j++) {
     if (refloci[j]->start>locus->end) break;
     if (locus->start>refloci[j]->end) continue;
     // then we must have overlap here:
     //if (locus->overlap(refloci[j]->start, refloci[j]->end)) {
        locus->cmpovl.Add(refloci[j]);
        refloci[j]->cmpovl.Add(locus);
        //}
     }//for each reflocus
   } //for each locus

 //create corresponding "superloci" from transitive overlapping between loci and ref
 for (int l=0;l<loci.Count();l++) {
  if (loci[l]->v!=0) continue; //skip, already processed
  GSuperLocus* super=new GSuperLocus();
  super->qfidx=qfidx;
  //try to find all other loci connected to this locus loci[l]
  GList<GLocus> lstack(false,false,false);  //traversal stack
  lstack.Push(loci[l]);
  while (lstack.Count()>0) {
      GLocus* locus=lstack.Pop();
      if (locus->v!=0 || locus->cmpovl.Count()==0) continue;
      super->addQlocus(*locus);
      locus->v=1;
      for (int r=0;r<locus->cmpovl.Count();r++) {
        GLocus* rloc=locus->cmpovl[r];
        if (rloc->v==0) {
          super->addRlocus(*rloc);
          rloc->v=1;
          for (int ll=0;ll<rloc->cmpovl.Count();ll++) {
              if (rloc->cmpovl[ll]->v==0) lstack.Push(rloc->cmpovl[ll]);
              }
           }
        } //for each overlapping reflocus
      } //while linking

  if (super->qloci.Count()==0) {
    delete super;
    continue; //try next query loci
    }
  //--here we have a "superlocus" region data on both qry and ref
  // -- analyze mexons matching (base level metrics)
  cmpdata.Add(super);
  //make each ref locus keep track of all superloci containing it
    for (int rl=0;rl<super->rloci.Count();rl++) {
      super->rloci[rl]->superlst->Add(super);
      }
  for (int x=0;x<super->rmexons.Count();x++) {
    super->rbases_all += super->rmexons[x].end-super->rmexons[x].start+1;
    }
  for (int x=0;x<super->qmexons.Count();x++) {
    super->qbases_all += super->qmexons[x].end-super->qmexons[x].start+1;
    }
  int i=0; //locus mexons
  int j=0; //refmexons
  while (i<super->qmexons.Count() && j<super->rmexons.Count()) {
     uint istart=super->qmexons[i].start;
     uint iend=super->qmexons[i].end;
     uint jstart=super->rmexons[j].start;
     uint jend=super->rmexons[j].end;
     if (iend<jstart) { i++; continue; }
     if (jend<istart) { j++; continue; }
     //v--overlap here:
     uint ovlstart = jstart>istart? jstart : istart;
     uint ovlend = iend<jend ? iend : jend;
     uint ovlen=ovlend-ovlstart+1;
     super->baseTP+=ovlen; //qbases_cov
     if (iend<jend) i++;
               else j++;
     } //while mexons ovl search
  /* if (reduceRefs) {
    super->baseFP=super->qbases_all-super->baseTP;
    super->baseFN=super->rbases_all-super->baseTP;
    }
  */
  // -- exon level comparison:
  int* qexovl; //flags for qry exons with ref overlap
  GCALLOC(qexovl,super->quexons.Count()*sizeof(int));
  int* rexovl; //flags for ref exons with qry overlap
  GCALLOC(rexovl,super->ruexons.Count()*sizeof(int));
  for (int i=0;i<super->quexons.Count();i++) {
    uint istart=super->quexons[i].start;
    uint iend=super->quexons[i].end;
    for (int j=0;j<super->ruexons.Count();j++) {
      uint jstart=super->ruexons[j].start;
      uint jend=super->ruexons[j].end;
      if (iend<jstart) break;
      if (jend<istart) continue;
      //--- overlap here between quexons[i] and ruexons[j]
      qexovl[i]++;
      rexovl[j]++;
      if (super->quexons[i].coordMatch(&super->ruexons[j],5)) {
         super->exonATP++;
         if (super->quexons[i].coordMatch(&super->ruexons[j])) {
             super->exonTP++;
             } //exact match
         } //fuzzy match
      } //ref uexon loop
   } //qry uexon loop
  super->m_exons=0; //ref exons with no query overlap
  super->w_exons=0; //qry exons with no ref overlap
  for (int x=0;x<super->quexons.Count();x++)
       if (qexovl[x]==0) super->w_exons++;
  for (int x=0;x<super->ruexons.Count();x++)
       if (rexovl[x]==0) super->m_exons++;
  GFREE(rexovl);
  GFREE(qexovl);

  //-- intron level stats:
  //query:
  int* qinovl=NULL; //flags for qry introns with at least some ref overlap
  int* qtpinovl=NULL; //flags for qry introns with perfect ref overlap
  if (super->qintrons.Count()>0) {
   GCALLOC(qinovl,super->qintrons.Count()*sizeof(int));
   GCALLOC(qtpinovl,super->qintrons.Count()*sizeof(int));
   }
  //-- reference:
  int* rinovl=NULL; //flags for ref introns with qry overlap
  int* rtpinovl=NULL; //ref introns with perfect qry intron overlap
  if (super->rintrons.Count()>0) {
   GCALLOC(rinovl,super->rintrons.Count()*sizeof(int));
   GCALLOC(rtpinovl,super->rintrons.Count()*sizeof(int));
   }
  for (int i=0;i<super->qintrons.Count();i++) {
    uint istart=super->qintrons[i].start;
    uint iend=super->qintrons[i].end;
    for (int j=0;j<super->rintrons.Count();j++) {
      uint jstart=super->rintrons[j].start;
      uint jend=super->rintrons[j].end;
      if (iend<jstart) break;
      if (jend<istart) continue;
      //--- overlap here between qintrons[i] and rintrons[j]
      qinovl[i]++;
      rinovl[j]++;
      if (super->qintrons[i].coordMatch(&super->rintrons[j],5)) {
         super->intronATP++;
         if (super->qintrons[i].coordMatch(&super->rintrons[j])) {
             super->intronTP++;
             qtpinovl[i]++;
             rtpinovl[j]++;
             } //exact match
         } //fuzzy match
      } //ref intron loop
   } //qry intron loop
  super->m_introns=0; //ref introns with no query overlap
  super->w_introns=0; //qry introns with no ref overlap
  for (int x=0;x<super->qintrons.Count();x++) {
       if (qinovl[x]==0) { super->w_introns++;
                 //qry introns with no ref intron overlap AT ALL
                 super->i_qwrong.Add(super->qintrons[x]);
                 }
          else
             if (qtpinovl[x]==0) {
               super->i_qnotp.Add(super->qintrons[x]);
             }
       }
  for (int x=0;x<super->rintrons.Count();x++) {
       if (rinovl[x]==0) { //no intron overlap at all
             super->m_introns++;
             super->i_missed.Add(super->rintrons[x]);
             }
       else if (rtpinovl[x]==0) { //no perfect intron match
            super->i_notp.Add(super->rintrons[x]);
            }
       }
  GFREE(rinovl);
  GFREE(rtpinovl);
  GFREE(qinovl);
  GFREE(qtpinovl);

  // ---- now intron-chain and transcript comparison
  for (int i=0;i<super->qmrnas.Count();i++) {
    uint istart=super->qmrnas[i]->exons.First()->start;
    uint iend=super->qmrnas[i]->exons.Last()->end;
    for (int j=0;j<super->rmrnas.Count();j++) {
      uint jstart=super->rmrnas[j]->exons.First()->start;
      uint jend=super->rmrnas[j]->exons.Last()->end;
      if (iend<jstart) break;
      if (jend<istart) continue;
      //--- overlap here --
      bool exonMatch=false;
      if ((super->qmrnas[i]->udata & 3) > 1) continue; //already counted a ichainTP for this qry
      if (ichainMatch(super->qmrnas[i],super->rmrnas[j],exonMatch, 5)) { //fuzzy match
         GLocus* qlocus=((CTData*)super->qmrnas[i]->uptr)->locus;
         if (super->qmrnas[i]->exons.Count()>1) {
              super->ichainATP++;
              qlocus->ichainATP++;
              }
          if (exonMatch) {
                super->mrnaATP++;
                qlocus->mrnaATP++;
                }
         if (ichainMatch(super->qmrnas[i],super->rmrnas[j],exonMatch)) { //exact match
             //if (debug) GMessage(" => MATCH ");
             /* if (exonMatch && i!=j) {
                GMessage("%s/i=%d  vs %s/j=%d :\n",super->qmrnas[i]->getID(),i,
                                                    super->rmrnas[j]->getID(),j);
                show_exons(stderr, *super->qmrnas[i]);
                GMessage(" vs ");
                show_exons(stderr, *super->rmrnas[j]);
                GMessage("\n");
                } */
             if (super->qmrnas[i]->exons.Count()>1) {
                super->qmrnas[i]->udata|=1;
                super->ichainTP++;
                qlocus->ichainTP++;
                }
             if (exonMatch) {
                super->qmrnas[i]->udata|=2;
                super->mrnaTP++;
                qlocus->mrnaTP++;
                }
             } //exact match
         } //fuzzy match
      } //ref mrna loop
    } //qry mrna loop
  for (int ql=0;ql<super->qloci.Count();ql++) {
      if (super->qloci[ql]->ichainTP+super->qloci[ql]->mrnaTP >0 )
                 super->locusTP++;
      if (super->qloci[ql]->ichainATP+super->qloci[ql]->mrnaATP>0)
                 super->locusATP++;
      }

  }//for each unlinked locus

}

char* getGSeqName(int gseq_id) {
 return GffObj::names->gseqs.getName(gseq_id);
}

char* getFastaFile(int gseq_id) {
 if (fastadir==NULL) return NULL;
 GStr s(fastadir);
 s.trimR('/');
 s.appendfmt("/%s",getGSeqName(gseq_id));
 GStr sbase=s;
 if (!fileExists(s.chars())) s.append(".fa");
 if (!fileExists(s.chars())) s.append("sta");
 if (fileExists(s.chars())) return Gstrdup(s.chars());
     else {
         GMessage("Warning: cannot find genomic sequence file %s{.fa,.fasta}\n",sbase.chars());
         return NULL;
         }
}

//look for qry data for a specific genomic sequence
GSeqData* getQryData(int gid, GList<GSeqData>& qdata) {
  int qi=-1;
  GSeqData f(gid);
  GSeqData* q=NULL;
  if (qdata.Found(&f,qi))
        q=qdata[qi];
  return q;
}

const char* findDescr(GffObj* gfobj) {
  if (refdescr.Count()==0) return NULL;
  GStr* s=refdescr.Find(gfobj->getID());
  if (s==NULL) s=refdescr.Find(gfobj->getGene());
  if (s!=NULL) 
     return s->chars();
  return NULL;
}

const char* getGeneID(GffObj* gfobj) {
 const char* s=gfobj->getAttr(ATTR_GENE_NAME);
 if (s!=NULL) return s;
 s=gfobj->getGene();
 return (s==NULL) ? gfobj->getID() : s;
}

const char* getGeneID(GffObj& gfobj) {
 return getGeneID(&gfobj);
}

void writeLoci(FILE* f, GList<GLocus> & loci) {
 for (int l=0;l<loci.Count();l++) {
   GLocus& loc=*(loci[l]);
   fprintf(f,"%s\t%s[%c]%d-%d\t", loc.mrna_maxcov->getID(),
       loc.mrna_maxcov->getGSeqName(),
           loc.mrna_maxcov->strand, loc.start,loc.end);
   //now print all transcripts in this locus, comma delimited
   int printed=0;
   for (int i=0;i<loc.mrnas.Count();i++) {
      if (loc.mrnas[i]==loc.mrna_maxcov) continue;
      if (printed==0) fprintf(f,"%s",loc.mrnas[i]->getID());
          else fprintf(f,",%s",loc.mrnas[i]->getID());
      printed++;
      }
   const char* rdescr=findDescr(loc.mrna_maxcov);
   if (rdescr==NULL)  fprintf(f,"\t\n");
                 else fprintf(f,"\t%s\n",rdescr);
   }
}

void printXQ1(FILE* f, int qidx, GList<GLocus>& qloci) {
  int printed=0;
  //print
  for (int i=0;i<qloci.Count();i++) {
     if (qloci[i]->qfidx!=qidx) continue;
      for (int j=0;j<qloci[i]->mrnas.Count();j++) {
        if (printed==0) fprintf(f,"%s",qloci[i]->mrnas[j]->getID());
            else fprintf(f,",%s",qloci[i]->mrnas[j]->getID());
        printed++;
        }
      }
  if (printed==0) fprintf(f,"-");
 }

void numXLoci(GList<GXLocus>& xloci, int& last_id) {
  for (int l=0;l<xloci.Count();l++) {
    if (xloci[l]->qloci.Count()==0) continue; //we never print ref-only xloci
    last_id++;
    xloci[l]->id=last_id;
    }
}


class GProtCl {
 public:
   GList<GXConsensus> protcl;
   GProtCl(GXConsensus* c=NULL):protcl(true,false,false) {
    if (c!=NULL)
       protcl.Add(c);
    }
   bool add_Pcons(GXConsensus* c) {
    if (c==NULL || c->aalen==0) return false;
    if (protcl.Count()==0) {
        protcl.Add(c);
        return true;
        }
    if (protcl[0]->aalen!=c->aalen) return false;
    if (strcmp(protcl[0]->aa,c->aa)!=0) return false;
    protcl.Add(c);
    return true;
    }

   void addMerge(GProtCl& pcl, GXConsensus* pclnk) {
    for (int i=0;i<pcl.protcl.Count();i++) {
      if (pcl.protcl[i]!=pclnk) {
          protcl.Add(pcl.protcl[i]);
          }
      }
    }

   int aalen() {
    if (protcl.Count()==0) return 0;
    return protcl[0]->aalen;
   }
   bool operator==(GProtCl& cl) {
    return this==&cl;
    }
   bool operator>(GProtCl& cl) {
     return (this>&cl);
    }
   bool operator<(GProtCl& cl) {
    return (this<&cl);
    }
};

class GTssCl:public GSeg { //experiment cluster of ref loci (isoforms)
 public:
   uint fstart; //lowest coordinate of the first exon
   uint fend; //highest coordinate of the first exon
   GList<GXConsensus> tsscl;
   GTssCl(GXConsensus* c=NULL):tsscl(true,false,false) {
     start=0;
     end=0;
     fstart=0;
     fend=0;
     if (c!=NULL) addFirst(c);
     }

   void addFirst(GXConsensus* c) {
     tsscl.Add(c);
     start=c->start;
     end=c->end;
     GffExon* fexon=(c->tcons->strand=='-') ? c->tcons->exons.Last() :
                                             c->tcons->exons.First();
     fstart=fexon->start;
     fend=fexon->end;
     }
   bool add_Xcons(GXConsensus* c) {
     if (tsscl.Count()==0) {
            addFirst(c);
            return true;
            }
     //check if it can be added to existing xconsensi
     uint nfend=0;
     uint nfstart=0;
     if (c->tcons->strand=='-') {
        //no, the first exons don't have to overlap
        //if (!c->tcons->exons.Last()->overlap(fstart,fend)) return false;
        nfstart=c->tcons->exons.Last()->start;
        nfend=c->tcons->exons.Last()->end;
        //proximity check for the transcript start:
        if (nfend>fend+tssDist || fend>nfend+tssDist) return false;
        }
      else {
        //if (!c->tcons->exons.First()->overlap(fstart,fend)) return false;
        nfstart=c->tcons->exons.First()->start;
        nfend=c->tcons->exons.First()->end;
        if (nfstart>fstart+tssDist || fstart>nfstart+tssDist) return false;
        }
     // -- if we are here, we can add to tss cluster

     tsscl.Add(c);
     if (fstart>nfstart) fstart=nfstart;
     if (fend<nfend) fend=nfend;
     if (start>c->start) start=c->start;
     if (end<c->end) end=c->end;
     return true;
     }

   void addMerge(GTssCl& cl, GXConsensus* clnk) {
     for (int i=0;i<cl.tsscl.Count();i++) {
         if (cl.tsscl[i]==clnk) continue;
         tsscl.Add(cl.tsscl[i]);
         }
     if (fstart>cl.fstart) fstart=cl.fstart;
     if (fend<cl.fend) fend=cl.fend;
     if (start>cl.start) start=cl.start;
     if (end<cl.end) end=cl.end;
     }
};
/*
class IntArray { //two dimensional int array
    int* mem;
    int xsize;
    int ysize;
  public:
   IntArray(int xlen, int ylen) {
     xsize=xlen;
     ysize=ylen;
     GMALLOC(mem, xsize*ysize*sizeof(int));
     }
   ~IntArray() {
     GFREE(mem);
     }
   int& data(int x, int y) {
    return mem[y*xsize+x];
    }
};

int aa_diff(GXConsensus* c1, GXConsensus* c2) {
 int diflen=abs(c1->aalen-c2->aalen);
 if (diflen>=6) return diflen;
 //obvious case: same CDS
 if (diflen==0 && strcmp(c1->aa, c2->aa)==0) return 0;
 //simple edit distance calculation
 IntArray dist(c1->aalen+1, c2->aalen+1);
 for (int i=0;i<=c1->aalen;i++) {
     dist.data(i,0) = i;
     }
 for (int j = 0; j <= c2->aalen; j++) {
     dist.data(0,j) = j;
     }
 for (int i = 1; i <= c1->aalen; i++)
     for (int j = 1; j <= c2->aalen; j++) {
         dist.data(i,j) = GMIN3( dist.data(i-1,j)+1,
             dist.data(i,j-1)+1,
                 dist.data(i-1,j-1)+((c1->aa[i-1] == c2->aa[j-1]) ? 0 : 1) );
         }
 int r=dist.data(c1->aalen,c2->aalen);
 return r;
}
*/
void printConsGTF(FILE* fc, GXConsensus* xc, int xlocnum) {
 //CTData* mdata=((CTData*)m->uptr);
 for (int i=0;i<xc->tcons->exons.Count();i++) {
   fprintf(fc,
    "%s\t%s\texon\t%d\t%d\t.\t%c\t.\tgene_id \"XLOC_%06d\"; transcript_id \"%s_%08d\"; exon_number \"%d\";",
     xc->tcons->getGSeqName(),xc->tcons->getTrackName(),xc->tcons->exons[i]->start, xc->tcons->exons[i]->end, xc->tcons->strand,
       xlocnum, cprefix, xc->id, i+1);
   //if (i==0) {
         if (xc->ref!=NULL) 
		 { 
			 const char* s = xc->ref->getAttr(ATTR_GENE_NAME);
			 if (s != NULL)
			 {
				 fprintf (fc, " gene_name \"%s\";",s); 
			 }
		 }
         fprintf(fc, " oId \"%s\";",xc->tcons->getID());
	 if (xc->ref)
	 {
		 fprintf(fc, " nearest_ref \"%s\";",xc->ref->getID());
	 }
	 fprintf(fc, " class_code \"%c\";",xc->refcode ? xc->refcode: '.');
         if (xc->tss_id>0)
           fprintf(fc, " tss_id \"TSS%d\";",xc->tss_id);
         if (xc->p_id>0)
           fprintf(fc, " p_id \"P%d\";",xc->p_id);
   //      }
   fprintf(fc,"\n");
   }
}
/*
void processTssCl(int& cds_num, GTssCl* cl, GFaSeqGet* faseq) {
 if (faseq==NULL) return; //we need genomic sequence for this
 for (int i=0;i<cl->tsscl.Count()-1;i++) {
   GXConsensus* ci=cl->tsscl[i];
   if (ci->ref==NULL || ci->ref->CDstart==0) continue; //skip if no CDS annotation
   if (ci->aa==NULL) {
      ci->aa=ci->ref->getSplicedTr(faseq, true, &ci->aalen);
      if (ci->aalen>0 && ci->aa[ci->aalen-1]=='.') {
            //discard the final stop codon
            ci->aalen--;
            ci->aa[ci->aalen]=0;
            }
      }
   for (int j=i+1;j<cl->tsscl.Count();j++) {
     GXConsensus* cj=cl->tsscl[j];
     if (cj->ref==NULL || cj->ref->CDstart==0) continue; //skip if no CDS annotation
     if (cj->aa==NULL) {
        cj->aa=cj->ref->getSplicedTr(faseq, true, &cj->aalen);
        if (cj->aalen>0 && cj->aa[cj->aalen-1]=='.') {
             //discard the final stop codon
              cj->aalen--;
              cj->aa[cj->aalen]=0;
              }
        }
     if (aa_diff(ci, cj)<6) { //less then 6 aa difference
        //they are too similar for our purposes so we assign the same ID
       if (ci->p_id==0) {
          if (cj->p_id>0) ci->p_id=cj->p_id;
              else { cds_num++; cj->p_id=cds_num; ci->p_id=cds_num; } //new CDS id
          }
       else { //ci->p_id>0
         if (cj->p_id==0) cj->p_id=ci->p_id;
            else if (cj->p_id!=ci->p_id) { //both>0, find all previously set and change
              int tochange=cj->p_id; //change all to ci->p_id
              int into=ci->p_id;
              if (ci->p_id>cj->p_id) {tochange=ci->p_id; into=cj->p_id; }
              for (int k=0;k<cl->tsscl.Count();k++) {
                 if (cl->tsscl[k]->p_id==tochange) cl->tsscl[k]->p_id=into;
                 }
              }
         }
       }//the "same" protein
     }//for j>i
   } //for i

 //those left with p_id==0 have "unique" CDS
 for (int i=0;i<cl->tsscl.Count();i++) {
   GXConsensus* c=cl->tsscl[i];
   //if (c->ref==NULL || c->ref->CDstart==0) continue;
   if (c->aa==NULL) continue; //no CDS or CDS never processed
   if (c->p_id==0) { cds_num++; c->p_id=cds_num; }
   GFREE(c->aa);
   }
}
*/
void tssCluster(GXLocus& xloc, GFaSeqGet *faseq) {
  GList<GTssCl> xpcls(true,true,false);
  for (int i=0;i<xloc.tcons.Count();i++) {
    GXConsensus* c=xloc.tcons[i];
    if (c->tcons->exons.Count()<2) continue;  //skip single-exon transcripts (?)
    GArray<int> mrgloci(true);
    int lfound=0;
    for (int l=0;l<xpcls.Count();l++) {
        if (xpcls[l]->end<c->tcons->exons.First()->start) continue;
        if (xpcls[l]->start>c->tcons->exons.Last()->end) break;
        if (xpcls[l]->add_Xcons(c)) {
            lfound++;
            mrgloci.Add(l);
            }
        } // for each xpcluster
    if (lfound==0) {
        //create a xpcl with only this xconsensus
        xpcls.Add(new GTssCl(c));
        }
      else if (lfound>1) {
        for (int l=1;l<lfound;l++) {
              int mlidx=mrgloci[l]-l+1;
              xpcls[mrgloci[0]]->addMerge(*xpcls[mlidx], c);
              xpcls.Delete(mlidx);
              }
        }
    //process the generated xpcls with more than 1 member
    //this will also assign tss_id and p_id
    }//for each xconsensus in this xlocus
 for (int l=0;l<xpcls.Count();l++) {
      //if (xpcls[l]->tsscl.Count()<2) continue;
      tsscl_num++;
      for (int i=0;i<xpcls[l]->tsscl.Count();i++)
           xpcls[l]->tsscl[i]->tss_id=tsscl_num;
      //processTssCl(xcds_num, xpcls[l], faseq);
      }
}

void protCluster(GXLocus& xloc, GFaSeqGet *faseq) {
	if (!faseq)
		return;
  GList<GProtCl> xpcls(true,true,false);
  for (int i=0;i<xloc.tcons.Count();i++) {
    GXConsensus* c=xloc.tcons[i];
    if (c->ref==NULL || c->ref->CDstart==0) continue;  //no ref or CDS available
    if (c->refcode!='=') continue;
    //get the CDS translation here
    if (c->aa==NULL) {
       c->aa=c->ref->getSplicedTr(faseq, true, &c->aalen);
       if (c->aalen>0 && c->aa[c->aalen-1]=='.') {
             //discard the final stop codon
             c->aalen--;
             c->aa[c->aalen]=0;
             }
       }
    GArray<int> mrgloci(true);
    int lfound=0;
    for (int l=0;l<xpcls.Count();l++) {
        if (xpcls[l]->aalen()!=c->aalen) continue;
        if (xpcls[l]->add_Pcons(c)) {
            lfound++;
            mrgloci.Add(l);
            }
        } // for each xpcluster
    if (lfound==0) {
        //create a xpcl with only this xconsensus
        xpcls.Add(new GProtCl(c));
        }
      else if (lfound>1) {
        for (int l=1;l<lfound;l++) {
              int mlidx=mrgloci[l]-l+1;
              xpcls[mrgloci[0]]->addMerge(*xpcls[mlidx], c);
              xpcls.Delete(mlidx);
              }
        }
    //process the generated xpcls with more than 1 member
    //this will also assign tss_id and p_id
    }//for each xconsensus in this xlocus
 for (int l=0;l<xpcls.Count();l++) {
      protcl_num++;
      for (int i=0;i<xpcls[l]->protcl.Count();i++)
           xpcls[l]->protcl[i]->p_id=protcl_num;
      }
 for (int i=0;i<xloc.tcons.Count();i++) {
   GXConsensus* c=xloc.tcons[i];
   if (c->aa!=NULL) { GFREE(c->aa); }
   }
}


void printXLoci(FILE* f, FILE* fc, int qcount, GList<GXLocus>& xloci, GFaSeqGet *faseq) {
  for (int l=0;l<xloci.Count();l++) {
    if (xloci[l]->qloci.Count()==0) continue;
    GXLocus& xloc=*(xloci[l]);
    tssCluster(xloc, faseq);//cluster and assign tss_id and cds_id to each xconsensus in xloc
    protCluster(xloc,faseq);
    for (int c=0;c<xloc.tcons.Count();c++) {
       printConsGTF(fc,xloc.tcons[c],xloc.id);
       }
    fprintf(f,"XLOC_%06d\t%s[%c]%d-%d\t", xloc.id,
        xloc.qloci[0]->mrna_maxcov->getGSeqName(),
            xloc.strand, xloc.start,xloc.end);
    //now print all transcripts in this locus, comma delimited
    //first, ref loci, if any
    int printed=0;
    if (xloc.rloci.Count()>0) {
       for (int i=0;i<xloc.rloci.Count();i++) {
          for (int j=0;j<xloc.rloci[i]->mrnas.Count();j++) {
            if (printed==0) fprintf(f,"%s|%s",getGeneID(xloc.rloci[i]->mrnas[j]),
                                                    xloc.rloci[i]->mrnas[j]->getID());
                else fprintf(f,",%s|%s",getGeneID(xloc.rloci[i]->mrnas[j]),
                                                    xloc.rloci[i]->mrnas[j]->getID());
            printed++;
            }
          }
       }
    else {
      fprintf(f,"-");
      }
   //second, all the cufflinks transcripts
    for (int qi=0;qi<qcount;qi++) {
       fprintf(f,"\t");
       printXQ1(f,qi,xloc.qloci);
       }
    fprintf(f,"\n");
    }
}

void writeIntron(FILE* f, char strand, GFaSeqGet* faseq, GSeg& iseg,
                GList<GffObj>& mrnas, bool wrong=false) {
//find a ref mrna having this intron
  GffObj* rm=NULL;
  for (int i=0;i<mrnas.Count();i++) {
   GffObj* m=mrnas[i];
   if (m->start>iseg.end) break;
   if (m->end<iseg.start) continue;
   //intron coords overlaps mrna region
   for (int j=1;j<m->exons.Count();j++) {
      if (iseg.start==m->exons[j-1]->end+1 &&
            iseg.end==m->exons[j]->start-1) { rm=m; break; } //match found
      }//for each intron
   if (rm!=NULL) break;
   } //for each ref mrna in this locus
 if (rm==NULL) GError("Error: couldn't find ref mrna for intron %d-%d! (BUG)\n",
                         iseg.start,iseg.end);
 int ilen=iseg.end-iseg.start+1;
 fprintf(f,"%s\t%s\tintron\t%d\t%d\t.\t%c\t.\t",
            rm->getGSeqName(),rm->getTrackName(),iseg.start,iseg.end,strand);
 if (faseq!=NULL) {
   const char* gseq=faseq->subseq(iseg.start, ilen);
   char* cseq=Gstrdup(gseq, gseq+ilen-1);
   if (strand=='-') reverseComplement(cseq, ilen);
   fprintf(f,"spl=\"%c%c..%c%c\"; ", toupper(cseq[0]),toupper(cseq[1]),
           toupper(cseq[ilen-2]),toupper(cseq[ilen-1]));
   GFREE(cseq);
   }
  fprintf(f,"transcript_id \"%s\";", rm->getID());
  if (wrong) fprintf(f," noOvl=1;");
  fprintf(f,"\n");

}

void reportIntrons(FILE* fm, FILE* fn, FILE* fq, GFaSeqGet* faseq, char strand,
            GList<GSuperLocus>& cmpdata) {
  if (fm==NULL) return;
  for (int l=0;l<cmpdata.Count();l++) {
    GSuperLocus *sl=cmpdata[l];
    //cache the whole locus sequence if possible
    //write these introns and their splice sites into the file
    for (int i=0;i<sl->i_missed.Count();i++)
      writeIntron(fm, strand, faseq, sl->i_missed[i], sl->rmrnas);
    for (int i=0;i<sl->i_notp.Count();i++)
      writeIntron(fn, strand, faseq, sl->i_notp[i], sl->rmrnas);
    for (int i=0;i<sl->i_qwrong.Count();i++) {
      writeIntron(fq, strand, faseq, sl->i_qwrong[i], sl->qmrnas, true);
      }
    for (int i=0;i<sl->i_qnotp.Count();i++) {
      writeIntron(fq, strand, faseq, sl->i_qnotp[i], sl->qmrnas);
      }
    }
}

void processLoci(GSeqData& seqdata, GSeqData* refdata, GFaSeqGet* faseq, int qfidx) {
    //GList<GSeqLoci>& glstloci, GList<GSeqCmpRegs>& cmpdata)

  if (refdata!=NULL) {
     //if (verbose) GMessage(" ..comparing to reference loci..\n") ;
     compareLoci2R(seqdata.loci_f, seqdata.gstats_f, refdata->loci_f, qfidx);
     compareLoci2R(seqdata.loci_r, seqdata.gstats_r, refdata->loci_r, qfidx);
     // -- report
     /*
     if (f_mintr!=NULL) {
       if (verbose) GMessage(" ..reporting problematic introns..\n") ;
       reportIntrons(f_mintr, f_nintr, f_qintr, faseq, '+', seqdata.gstats_f);
       reportIntrons(f_mintr, f_nintr, f_qintr, faseq, '-', seqdata.gstats_r);
       }
     */
     }
}

//adjust stats for a list of unoverlapped (completely missed) ref loci
void collectRLocData(GSuperLocus& stats, GLocus& loc) {
stats.total_rmrnas+=loc.mrnas.Count();
stats.total_rexons+=loc.uexons.Count();
stats.total_rintrons+=loc.introns.Count();
stats.total_rmexons+=loc.mexons.Count();
stats.total_richains+=loc.ichains;
stats.m_exons+=loc.uexons.Count();
stats.m_introns+=loc.introns.Count();
stats.total_rloci++;
for (int e=0;e<loc.mexons.Count();e++) {
   stats.rbases_all+=loc.mexons[e].end-loc.mexons[e].start+1;
   }
}

void collectRData(GSuperLocus& stats, GList<GLocus>& loci) {
 for (int l=0;l<loci.Count();l++)
      collectRLocData(stats,*loci[l]);
}

//adjust stats for a list of unoverlapped (completely "wrong" or novel) qry loci
void collectQLocData(GSuperLocus& stats, GLocus& loc) {
 stats.total_qmrnas+=loc.mrnas.Count();
 stats.total_qexons+=loc.uexons.Count();
 stats.total_qmexons+=loc.mexons.Count();
 stats.total_qintrons+=loc.introns.Count();
 stats.total_qichains+=loc.ichains;
 stats.total_qloci++;
 if (loc.ichains>0 && loc.mrnas.Count()>1)
    stats.total_qloci_alt++;
 stats.w_exons+=loc.uexons.Count();
 stats.w_introns+=loc.introns.Count();
 for (int e=0;e<loc.mexons.Count();e++) {
   stats.qbases_all+=loc.mexons[e].end-loc.mexons[e].start+1;
   }
}

void collectQData(GSuperLocus& stats, GList<GLocus>& loci, GList<GLocus>& nloci) {
 for (int l=0;l<loci.Count();l++) {
     //this is called when no refdata is given, so all these loci are nloci
     nloci.Add(loci[l]);
     collectQLocData(stats,*loci[l]);
     }
}

void collectQNOvl(GSuperLocus& stats, GList<GLocus>& loci, GList<GLocus>& nloci) {
  for (int l=0;l<loci.Count();l++) {
    if (loci[l]->cmpovl.Count()==0) {//locus with no ref loci overlaps
      stats.w_loci++; //novel/wrong loci
      nloci.Add(loci[l]);
      collectQLocData(stats,*loci[l]);
      }
  }
}

void collectQU(GSuperLocus& stats, GList<GLocus>& nloci) {
  for (int l=0;l<nloci.Count();l++) {
    stats.w_loci++; //novel/wrong loci
    collectQLocData(stats, *nloci[l]);
    }
}

void printLocus(FILE* f, GLocus& loc, const char* gseqname) {
  fprintf(f, "## Locus %s:%d-%d\n",gseqname, loc.start, loc.end);
  for (int m=0;m<loc.mrnas.Count();m++) {
    loc.mrnas[m]->printGtf(f);
    }
}

void collectRNOvl(GSuperLocus& stats, GList<GLocus>& loci, const char* gseqname) {
  for (int l=0;l<loci.Count();l++) {
    if (loci[l]->cmpovl.Count()==0) {
      stats.m_loci++; //missed ref loci
      //if (f_mloci!=NULL)
      //      printLocus(f_mloci,*loci[l], gseqname);
      collectRLocData(stats,*loci[l]);
      }
  }
}


void collectCmpData(GSuperLocus& stats, GList<GSuperLocus>& cmpdata, const char* gseqname) {
 for (int c=0;c<cmpdata.Count();c++) {
   stats.addStats(*cmpdata[c]);
   /*
   if (f_nloci!=NULL && cmpdata[c]->locusTP==0 && cmpdata[c]->rloci.Count()>0) {       
      fprintf(f_nloci, "# Superlocus %s:%d-%d\n",gseqname, cmpdata[c]->start, cmpdata[c]->end);
      for (int l=0;l<cmpdata[c]->rloci.Count();l++) {
         printLocus(f_nloci,*cmpdata[c]->rloci[l], gseqname);
         }
      }
   */   
   }
}

void collectStats(GSuperLocus& stats, GSeqData* seqdata, GSeqData* refdata) {
 //collect all stats for a single genomic sequence into stats
 if (seqdata==NULL) {
   if (reduceRefs || refdata==NULL) return;
   //special case with completely missed all refs on a contig/chromosome
   collectRData(stats, refdata->loci_f);
   collectRData(stats, refdata->loci_r);
   return;
   }
 if (refdata==NULL) {//reference data missing on this contig
   collectQData(stats, seqdata->loci_f, seqdata->nloci_f);
   collectQData(stats, seqdata->loci_r, seqdata->nloci_r);
   collectQU(stats, seqdata->nloci_u);
   return;
   }

 /*stats.total_qloci+=seqdata->loci_f.Count();
 stats.total_qloci+=seqdata->loci_r.Count();
 if (reduceRefs) { //only collect ref loci from superloci

    }
   else {
    stats.total_rloci+=refdata->loci_f.Count();
    stats.total_rloci+=refdata->loci_r.Count();
    }
 */
 //collect data for overlapping superloci (already in seqdata->gstats_f/_r)
 char* gseqname=getGSeqName(seqdata->gseq_id);
 collectCmpData(stats, seqdata->gstats_f, gseqname);
 collectCmpData(stats, seqdata->gstats_r, gseqname);
 //for non-overlapping qry loci, always add them as false positives FP
 collectQNOvl(stats, seqdata->loci_f, seqdata->nloci_f);
 collectQNOvl(stats, seqdata->loci_r, seqdata->nloci_r);
 collectQU(stats, seqdata->nloci_u);
 if (!reduceRefs) { //find ref loci with empty cmpovl and add them
  collectRNOvl(stats, refdata->loci_f, gseqname);
  collectRNOvl(stats, refdata->loci_r, gseqname);
  }
}

void reportStats(FILE* fout, char* setname, GSuperLocus& stotal,
                          GSeqData* seqdata, GSeqData* refdata) {
  GSuperLocus stats;
  bool finalSummary=(seqdata==NULL && refdata==NULL);
  GSuperLocus *ps=(finalSummary ? &stotal : &stats );
  if (!finalSummary) { //collecting contig stats
    //gather statistics for all loci/superloci here
    collectStats(stats, seqdata, refdata);
    stotal.addStats(stats);
    if (!perContigStats) return;
    }
  ps->calcF();
  if (seqdata!=NULL) fprintf(fout, "#> Genomic sequence: %s \n", setname);
                else fprintf(fout, "\n#= Summary for dataset: %s :\n", setname);

  fprintf(fout,   "#     Query mRNAs : %7d in %7d loci  (%d multi-exon transcripts)\n",
          ps->total_qmrnas, ps->total_qloci, ps->total_qichains);
  fprintf(fout, "#            (%d multi-transcript loci, ~%.1f transcripts per locus)\n",
          ps->total_qloci_alt, ((double)ps->total_qmrnas/ps->total_qloci));

  if (haveRefs) {
    fprintf(fout, "# Reference mRNAs : %7d in %7d loci  (%d multi-exon)\n",
            ps->total_rmrnas, ps->total_rloci, ps->total_richains);
    if (ps->baseTP+ps->baseFP==0 || ps->baseTP+ps->baseFN==0) return;
    fprintf(fout, "# Corresponding super-loci:        %7d\n",ps->total_superloci);

    /*if (seqdata!=NULL) {
      fprintf(fout, "          ( %d/%d on forward/reverse strand)\n",
             seqdata->gstats_f.Count(),seqdata->gstats_r.Count());
       }*/
    fprintf(fout, "#--------------------|   Sn   |  Sp   |  fSn |  fSp  \n");
    double sp=(100.0*(double)ps->baseTP)/(ps->baseTP+ps->baseFP);
    double sn=(100.0*(double)ps->baseTP)/(ps->baseTP+ps->baseFN);
    fprintf(fout, "        Base level: \t%5.1f\t%5.1f\t  - \t  - \n",sn, sp);
    sp=(100.0*(double)ps->exonTP)/(ps->exonTP+ps->exonFP);
    sn=(100.0*(double)ps->exonTP)/(ps->exonTP+ps->exonFN);
    double fsp=(100.0*(double)ps->exonATP)/(ps->exonATP+ps->exonAFP);
    double fsn=(100.0*(double)ps->exonATP)/(ps->exonATP+ps->exonAFN);
    if (fsp>100.0) fsp=100.0;
    if (fsn>100.0) fsn=100.0;
    fprintf(fout, "        Exon level: \t%5.1f\t%5.1f\t%5.1f\t%5.1f\n",sn, sp, fsn, fsp);
  if (ps->total_rintrons>0) {
    //intron level
    sp=(100.0*(double)ps->intronTP)/(ps->intronTP+ps->intronFP);
    sn=(100.0*(double)ps->intronTP)/(ps->intronTP+ps->intronFN);
    fsp=(100.0*(double)ps->intronATP)/(ps->intronATP+ps->intronAFP);
    fsn=(100.0*(double)ps->intronATP)/(ps->intronATP+ps->intronAFN);
    if (fsp>100.0) fsp=100.0;
    if (fsn>100.0) fsn=100.0;
    fprintf(fout, "      Intron level: \t%5.1f\t%5.1f\t%5.1f\t%5.1f\n",sn, sp, fsn, fsp);
    //intron chains:
    sp=(100.0*(double)ps->ichainTP)/(ps->ichainTP+ps->ichainFP);
    sn=(100.0*(double)ps->ichainTP)/(ps->ichainTP+ps->ichainFN);
    if (sp>100.0) sp=100.0;
    if (sn>100.0) sn=100.0;
    fsp=(100.0*(double)ps->ichainATP)/(ps->ichainATP+ps->ichainAFP);
    fsn=(100.0*(double)ps->ichainATP)/(ps->ichainATP+ps->ichainAFN);
    if (fsp>100.0) fsp=100.0;
    if (fsn>100.0) fsn=100.0;
    fprintf(fout, "Intron chain level: \t%5.1f\t%5.1f\t%5.1f\t%5.1f\n",sn, sp, fsn, fsp);
    //DEBUG only:
    /* fprintf(fout, "ichain TP:%d\tref_total: %d\tqry_total: %d\n",
      ps->ichainTP, ps->total_richains, ps->total_qichains);
    //DEBUG only:
    fprintf(fout, "locus  TP:%d\tref_total: %d\tqry_total: %d\n",
      ps->locusTP, ps->total_rloci, ps->total_qloci);
      */
    }
  else {
    fprintf(fout, "      Intron level: \t  -  \t  -  \t  -  \t  -  \n");
    fprintf(fout, "Intron chain level: \t  -  \t  -  \t  -  \t  -  \n");
    }
    sp=(100.0*(double)ps->mrnaTP)/(ps->mrnaTP+ps->mrnaFP);
    sn=(100.0*(double)ps->mrnaTP)/(ps->mrnaTP+ps->mrnaFN);
    fsp=(100.0*(double)ps->mrnaATP)/(ps->mrnaATP+ps->mrnaAFP);
    fsn=(100.0*(double)ps->mrnaATP)/(ps->mrnaATP+ps->mrnaAFN);
    if (fsp>100.0) fsp=100.0;
    if (fsn>100.0) fsn=100.0;
    fprintf(fout, "  Transcript level: \t%5.1f\t%5.1f\t%5.1f\t%5.1f\n",sn, sp,fsn,fsp);
    sp=(100.0*(double)ps->locusTP)/(ps->locusTP+ps->locusFP);
    sn=(100.0*(double)ps->locusTP)/(ps->locusTP+ps->locusFN);
    fsp=(100.0*(double)ps->locusATP)/(ps->locusATP+ps->locusAFP);
    fsn=(100.0*(double)ps->locusATP)/(ps->locusATP+ps->locusAFN);
    fprintf(fout, "       Locus level: \t%5.1f\t%5.1f\t%5.1f\t%5.1f\n",sn, sp, fsn, fsp);
    sn=(100.0*(double)ps->m_exons)/(ps->total_rexons);
    fprintf(fout, "   Missed exons:\t%d/%d (%5.1f%%)\n",ps->m_exons, ps->total_rexons, sn);
    sn=(100.0*(double)ps->w_exons)/(ps->total_qexons);
    fprintf(fout, "    Wrong exons:\t%d/%d (%5.1f%%)\n",ps->w_exons, ps->total_qexons,sn);
    if (ps->total_rintrons>0) {
      sn=(100.0*(double)ps->m_introns)/(ps->total_rintrons);
      fprintf(fout, " Missed introns:\t%d/%d (%5.1f%%)\n",ps->m_introns, ps->total_rintrons, sn);
      }
    if (ps->total_qintrons>0) {
      sn=(100.0*(double)ps->w_introns)/(ps->total_qintrons);
      fprintf(fout, "  Wrong introns:\t%d/%d (%5.1f%%)\n",ps->w_introns, ps->total_qintrons,sn);
      }
    if (ps->total_rloci>0) {
      sn=(100.0*(double)ps->m_loci)/(ps->total_rloci);
      fprintf(fout, " Missed loci:\t%d/%d (%5.1f%%)\n",ps->m_loci, ps->total_rloci, sn);
      }
    if (ps->total_qloci>0) {
      sn=(100.0*(double)ps->w_loci)/(ps->total_qloci);
      fprintf(fout, "  Wrong loci:\t%d/%d (%5.1f%%)\n",ps->w_loci, ps->total_qloci,sn);
      }

  }
}

int inbuf_len=1024; //starting inbuf capacity
char* inbuf=NULL; // incoming buffer for sequence lines.

void loadRefDescr(const char* fname) {
  if (inbuf==NULL)  { GMALLOC(inbuf, inbuf_len); }
  FILE *f=fopen(fname, "rb");
  if (f==NULL) GError("Error opening exon file: %s\n",fname);
  char* line;
  int llen=0;
  off_t fpos;
  while ((line=fgetline(inbuf, inbuf_len, f, &fpos, &llen))!=NULL) {
   if (strlen(line)<=2) continue;
   int idlen=strcspn(line,"\t ");
   char* p=line+idlen;
   if (idlen<llen && idlen>0) {
     *p=0;
      p++;
      refdescr.Add(line, new GStr(p));
      }
  }
}

GSeqTrack* findGSeqTrack(int gsid) {
  GSeqTrack f(gsid);
  int fidx=-1;
  if (gseqtracks.Found(&f,fidx))
     return gseqtracks[fidx];
  fidx=gseqtracks.Add(new GSeqTrack(gsid));
  return gseqtracks[fidx];
}



GffObj* findRefMatch(GffObj& m, GLocus& rloc, int& ovlen) {
 ovlen=0;
 CTData* mdata=((CTData*)m.uptr);
 if (mdata->eqref!=NULL && ((CTData*)(mdata->eqref->uptr))->locus==&rloc) {

      mdata->eqref=mdata->ovls.First()->mrna; //this should be unnecessary
      //check it?
      return mdata->ovls.First()->mrna;
      }
 //if (rloc==NULL|| m==NULL) return NULL;
 GffObj* ret=NULL;
 for (int r=0;r<rloc.mrnas.Count();r++) {
    int olen=0;
    if (tMatch(m, *(rloc.mrnas[r]),olen, true)) { //return rloc->mrnas[r];
      if (ovlen<olen) {
          ovlen=olen;
          ret=rloc.mrnas[r]; //keep the longest matching ref
             //but this is unnecessary, there can be only one matching ref (?)
             // (because ref "duplicates" were discarded)
          }
      mdata->addOvl('=',rloc.mrnas[r], olen);
      //this must be called only for the head of an equivalency chain
      CTData* rdata=(CTData*)rloc.mrnas[r]->uptr;
      rdata->addOvl('=',&m,olen);
      if (rdata->eqnext==NULL) rdata->eqnext=&m;
      }
    }
 if (ret!=NULL)
   mdata->eqref=ret;
 return ret;
 }


void addXCons(GXLocus* xloc, GffObj* ref, char ovlcode, GffObj* tcons, GList<GffObj>& ts) {
 GXConsensus* c=new GXConsensus(tcons,ts, ref, ovlcode);
 xloc->tcons.Add(c);
}


const uint pre_mrna_threshold = 100;

char getOvlCode(GffObj& m, GffObj& r, int& ovlen) {
  ovlen=0;
  if (!m.overlap(r.start,r.end)) return 'u';
  int jmax=r.exons.Count()-1;
  if (m.exons.Count()==1) { //single-exon mRNA
     GSeg mseg(m.start, m.end);
     if (jmax==0) { //also single-exon ref
         ovlen=mseg.overlapLen(r.start,r.end);
         int lmax=GMAX(r.covlen, m.covlen);
         if (ovlen > lmax/2) return '=';
         if (m.covlen<=ovlen+12 && m.covlen<r.covlen) return 'c'; //contained
         return 'o'; //just overlapping
         }
     //single-exon qry overlaping multi-exon ref
     for (int j=0;j<=jmax;j++) {
       //check if it's contained in an exon
        ovlen+=mseg.overlapLen(r.exons[j]->start,r.exons[j]->end);
        //if (r.exons[j]->start<m.start+10 && m.end<r.exons[j]->end+10)
        if (r.exons[j]->start<m.start && m.end<r.exons[j]->end)
            return 'c';
        if (j==jmax) break;
        // check if it's a pre-mRNA transcript (code 'e')
        // i.e. overlaps an intron at least 10 bases
        uint iovlen=mseg.overlapLen(r.exons[j]->end+1, r.exons[j+1]->start-1);
        //if (iovlen>10 && mseg.len()>iovlen+10) return 'e';
        if (iovlen && mseg.len()>iovlen) return 'e';
        }
     } //single-exon mRNA
  //intra-intron case: whole mRNA contained in an intron
  for (int j=0;j<jmax;j++) {
     uint istart=r.exons[j]->end+1;
     uint iend=r.exons[j+1]->start-1;
     if (m.end<=iend && m.start>=istart) return 'i';
     }
  //int exOvlen=m.exonOverlapLen(r); //exon overlap length
  // --- check if m chain is a subset of  r's chain
  int imax=m.exons.Count()-1;
  if (m.exons[imax]->start<r.exons[0]->end ||
      r.exons[jmax]->start<m.exons[0]->end ) //intron chains do not overlap at all
           return 'o'; //but terminal exons do, otherwise we wouldn't be here
  //check intron overlaps
  int i=1;
  int j=1;
  while (i<=imax && j<=jmax) {
     uint mstart=m.exons[i-1]->end;
     uint mend=m.exons[i]->start;
     uint rstart=r.exons[j-1]->end;
     uint rend=r.exons[j]->start;
     if (rend<mstart) { j++; continue; }
     if (mend<rstart) { i++; continue; }
     break; //here we have an intron overlap
     }
  if (i>imax || j>jmax)
      return 'o'; //no initial intron overlap found (overlap between initial-terminal exons)
  //from now on we look for qry intron matches
  bool jmatch=false;
  bool icmatch=(i==1); //if i>1 surely first intron of qry doesn't match
  //bool exovli=false; // if any terminal exon of qry extends into a ref intron
  uint lbound=0;
  if (icmatch && j>1) {
      lbound=r.exons[j-1]->start;
      //exovli=(lbound > m.exons[0]->start+10);
      }
  while (i<=imax && j<=jmax) {
    //use a fuzz range ?
    uint mstart=m.exons[i-1]->end;
    uint mend=m.exons[i]->start;
    uint rstart=r.exons[j-1]->end;
    uint rend=r.exons[j]->start;
    if (rend<mstart) { j++; icmatch=false; continue; } //skipping intron, surely no ichain match
    if (mend<rstart) { i++; icmatch=false; continue; }
    //overlapping introns here, test junction matching
    bool smatch=(mstart==rstart);
    bool ematch=(mend==rend);
    if (smatch || ematch)  jmatch=true;
    if (smatch && ematch) { i++; j++; }
          else { //at least one junction doesn't match
            icmatch=false;
            if (mend>rend) j++; else i++;
            }
    }//while checking intron overlaps
  if (icmatch && jmax>=imax) { //all overlapping qry introns match
     /* if ((lbound && lbound > m.exons[0]->start+10) ||
         (j<=jmax && m.exons[i-1]->end > r.exons[j-1]->end+10)) return 'j';
            return 'c';
      }
     */
     
		int code = 'c';
		if (lbound)
		{
			uint ref_boundary = lbound;
			uint cuff_boundary = m.exons[0]->start;
			if (ref_boundary > (cuff_boundary + pre_mrna_threshold)) // cuff extends a lot
			{
				code = 'j';
			}
			if (ref_boundary > cuff_boundary) // cuff extends just a bit into a ref intron
			{
				code = 'e';
			}
		}
		if (j <= jmax)
		{
			uint ref_boundary = r.exons[j-1]->end;
			uint cuff_boundary = m.exons[i-1]->end;
			if (cuff_boundary > (ref_boundary + pre_mrna_threshold)) // cuff extends a lot
			{
				code = 'j';
			}
			if (cuff_boundary > ref_boundary) // cuff extends just a bit into a ref intron
			{
				code = 'e';
			}
		}
		//if ((lbound && lbound > m.exons[0]->start+10) ||
		//	(j<=jmax && m.exons[i-1]->end > r.exons[j-1]->end+10)) return 'j';
		return code;
     }
	
//	if (!ichain) // first and last exons more or less match, but there's a different intron somewhere
//	{
//		
//	}
	
  return jmatch ? 'j':'o';
}

char getRefOvl(GffObj& m, GLocus& rloc, GffObj*& rovl, int& ovlen) {
  rovl=NULL;
  ovlen=0;
  if (m.start>rloc.end || m.end<rloc.start) {
     //see if it's a polymerase run
       if ((m.strand=='+' && m.end<=rloc.end+polyrun_range) ||
         (m.strand=='-' && m.start>=rloc.start-polyrun_range)) {
            rovl=rloc.mrna_maxcov;
            ((CTData*)m.uptr)->addOvl('p',rloc.mrna_maxcov);
            return 'p';
            }
     return 0; //unknown -> intergenic space
     }
  for (int i=0;i<rloc.mrnas.Count();i++) {
     GffObj* r=rloc.mrnas[i];
     int olen=0;
     char ovlcode=getOvlCode(m,*r,olen);
     if (ovlcode!=0) { //has some sort of "overlap" with r
       ((CTData*)m.uptr)->addOvl(ovlcode,r,olen);
       if (olen>ovlen) ovlen=olen;
       if (ovlcode=='c' || ovlcode=='=') //keep match/containment for each reference transcript
          ((CTData*)r->uptr)->addOvl(ovlcode,&m,olen);
       }
     }//for each ref in rloc
  // i,j,o
  return ((CTData*)m.uptr)->getBestCode();
}


void findTMatches(GTrackLocus& loctrack, int qcount) {
 //perform an all vs. all ichain-match for all transcripts across all loctrack[i]->qloci
for (int q=0;q<qcount-1;q++) { //for each qry dataset
  if (loctrack[q]==NULL) continue;
  for (int qi=0;qi<loctrack[q]->Count();qi++) { // for each transcript in q dataset
    if ((((CTData*)loctrack[q]->Get(qi)->uptr)->eqdata & EQCHAIN_TAG) !=0) continue; //done before
    for (int n=q+1;n<qcount;n++) { // for each next qry dataset
       if (loctrack[n]==NULL) continue;
       for (int ni=0;ni<loctrack[n]->Count();ni++) {
          if (((CTData*)loctrack[n]->Get(ni)->uptr)->eqdata !=0) continue;
          int ovlen=0;
          if (tMatch(*(loctrack[q]->Get(qi)),*(loctrack[n]->Get(ni)), ovlen, true)) {
             ((CTData*)loctrack[q]->Get(qi)->uptr)->eqnext=loctrack[n]->Get(ni);
             if (((CTData*)loctrack[q]->Get(qi)->uptr)->eqdata ==0) {//only start of chain is tagged

               ((CTData*)loctrack[q]->Get(qi)->uptr)->eqdata= ((q+1) | EQCHAIN_TAG);
               }
             ((CTData*)loctrack[n]->Get(ni)->uptr)->eqdata=n+1;
             }
          }
       if (((CTData*)loctrack[q]->Get(qi)->uptr)->eqnext!=NULL) break;
                //start of chain already set
       } // for each next qry dataset
    } //for each transcript
  } //for qry dataset
}

void printITrack(FILE* ft, GList<GffObj>& mrnas, int qcount, int& cnum) {
  for (int i=0;i<mrnas.Count();i++) {
   GffObj& qt=*(mrnas[i]);
   CTData* qtdata=(CTData*)qt.uptr;
   int qfidx=qtdata->qset;
   char ovlcode=qtdata->classcode;
   GList<GffObj> eqchain(false,false,false);
   GffObj* ref=NULL; //related ref -- it doesn't have to be fully matching
   GffObj* eqref=NULL; //fully ichain-matching ref
   GffObj* tcons=NULL; //"consensus" (largest) transcript for a clique
   int tmaxcov=0;
   eqchain.Add(&qt);
   eqref=qtdata->eqref;
   if (qtdata->ovls.Count()>0 && qtdata->ovls[0]->mrna!=NULL) {
       //if it has ovlcode with a ref
       ref=qtdata->ovls[0]->mrna;
       //consistency check: qtdata->ovls[0]->code==ovlcode
       tcons=eqref;
       if (tcons!=NULL) tmaxcov=tcons->covlen;
       /*
       if (ovlcode=='=') {
          tcons=ref;
          tmaxcov=tcons->covlen;
          }
       */
       }
   //chain pre-check
   if (tcons==NULL || mrnas[i]->covlen>tmaxcov) {
       tcons=mrnas[i];
       tmaxcov=tcons->covlen;
       }
   if ((qtdata->eqdata & EQCHAIN_TAG)!=0) {//head of a equivalency chain
      //if (ovlcode!='=' && qtdata->eqnext!=NULL && () {
      //check if all transcripts in this chain have the same ovlcode
      GffObj* m=mrnas[i];
      while (((CTData*)m->uptr)->eqnext!=NULL) {
        m=((CTData*)m->uptr)->eqnext;
        eqchain.Add(m);
        if (m->covlen>tmaxcov) {
            tmaxcov=m->covlen;
            tcons=m;
            }
        if (ovlcode!='=' && ovlcode!='.' && ((CTData*)m->uptr)->getBestCode()!=ovlcode) {
              ovlcode='.'; //non-uniform ovlcode
              //break;
              }
        } //while elements in chain
      }//chain check
   //if (ovlcode=='p') ref=NULL; //ignore polymerase runs?
   if (ovlcode==0 || ovlcode=='-') ovlcode = (ref==NULL) ? 'u' : '.';
   //-- print columns 1 and 2 as LOCUS_ID and TCONS_ID
   bool chainHead=(qtdata->eqnext!=NULL && ((qtdata->eqdata & EQCHAIN_TAG)!=0));
   bool noChain=((qtdata->eqdata & EQCHAIN_TAGMASK)==0);
   if (chainHead || noChain) {
     cnum++;
     if (ft!=NULL) fprintf(ft,"%s_%08d\t",cprefix,cnum);
     GXLocus* xloc=qtdata->locus->xlocus;
     if (xloc!=NULL) {
         if (ft!=NULL) fprintf(ft, "XLOC_%06d\t",xloc->id);
         if (tcons->exons.Count()>1) {
            //! only multi-exon mRNAs are counted for multi-transcript xloci !
              xloc->num_mtcons++;
              if (xloc->num_mtcons==2)
                 total_xloci_alt++;
              }
         }
      else {
        //if (ft!=NULL) fprintf(ft,"noXLocus\t"); //should NEVER happen!
        int fidx=(qtdata->eqdata & 0x0FFF);
        GError("Error: no XLocus created for transcript %s (file %s) [%d, %d], on %s%c:%d-%d\n", qt.getID(),
                           qryfiles[qtdata->locus->qfidx]->chars(), qtdata->locus->qfidx, fidx, qt.getGSeqName(), qt.strand, qt.start, qt.end);
        }
     addXCons(xloc, ref, ovlcode, &qt, eqchain); //store for now; print later
     } // if chain head or uniq entry (not part of a chain)
   if (ft==NULL) { eqchain.Clear(); continue; }
   if (chainHead) {
     //this is the start of a equivalence class as a printing chain
     if (ref!=NULL) fprintf(ft,"%s|%s\t%c", getGeneID(ref),ref->getID(), ovlcode);
               else {
                 //if (ovlcode=='.') fprintf(ft,"-        \t-");
                 //   else 
                       fprintf(ft,"-        \t%c", ovlcode);
                 }
     GffObj* m=mrnas[i];
     CTData* mdata=(CTData*)m->uptr;

     int lastpq=-1;
     //for (int ptab=(((CTData*)m->uptr)->eqdata & 0x07FF)-lastpq-1;ptab>=0;ptab--)
     for (int ptab=mdata->qset-lastpq; ptab>0;ptab--)
            if (ptab>1) fprintf(ft,"\t-");
                   else fprintf(ft,"\t");
     //lastpq=((CTData*)m->uptr)->eqdata & 0x07FF;
     lastpq=mdata->qset;
     fprintf(ft,"q%d:%s|%s|%d|%8.6f|%8.6f|%8.6f|%8.6f", lastpq+1, getGeneID(m), m->getID(),
         iround(m->gscore/10), mdata->FPKM, mdata->conf_lo, mdata->conf_hi, mdata->cov);
     //traverse linked list of matching transcripts
     while (mdata->eqnext!=NULL) {
        m=mdata->eqnext;
        mdata=(CTData*)m->uptr;
        for (int ptab=mdata->qset-lastpq;ptab>0;ptab--)
            if (ptab>1) fprintf(ft,"\t-");
                   else fprintf(ft,"\t");
        lastpq = mdata->qset;
        fprintf(ft,"q%d:%s|%s|%d|%8.6f|%8.6f|%8.6f|%8.6f", lastpq+1, getGeneID(m), m->getID(),
           iround(m->gscore/10), mdata->FPKM,mdata->conf_lo,mdata->conf_hi,mdata->cov);
        } //traverse and print row
     for (int ptab=qcount-lastpq-1;ptab>0;ptab--)
           fprintf(ft,"\t-");
     fprintf(ft,"\n");
     eqchain.Clear();
     continue;
     } //start of eq class (printing chain)

   if (!noChain) { eqchain.Clear(); continue; }//part of a matching chain, dealt with previously

   //--------- not in an ichain-matching class, print as singleton

   if (ref!=NULL) fprintf(ft,"%s|%s\t%c",getGeneID(ref), ref->getID(), ovlcode);
             else fprintf(ft,"-        \t%c",ovlcode);
   for (int ptab=qfidx;ptab>=0;ptab--)
      if (ptab>0) fprintf(ft,"\t-");
             else fprintf(ft,"\t");
   fprintf(ft,"q%d:%s|%s|%d|%8.6f|%8.6f|%8.6f|%8.6f",qfidx+1, getGeneID(qt), qt.getID(),iround(qt.gscore/10),
       qtdata->FPKM, qtdata->conf_lo,qtdata->conf_hi,qtdata->cov);
   for (int ptab=qcount-qfidx-1;ptab>0;ptab--)
         fprintf(ft,"\t-");
   fprintf(ft,"\n");
   } //for each transcript
}


void findTRMatch(GTrackLocus& loctrack, int qcount, GLocus& rloc) {
 //requires loctrack to be already populated with overlapping qloci by findTMatches()
  // which also found (and tagged) all matching qry transcripts
 for (int q=0;q<qcount;q++) { //for each qry dataset
  if (loctrack[q]==NULL) continue;
  for (int qi=0;qi<loctrack[q]->Count();qi++) { // for each transcript in q dataset
    //if (loctrack[q]->cl[qi]->exons.Count()<2) continue; //skip single-exon transcripts
    GffObj& qt=*(loctrack[q]->Get(qi));
    CTData* qtdata=(CTData*)qt.uptr;
    GffObj* rmatch=NULL; //== ref match for this row
    int rovlen=0;
    if (qtdata->eqnext!=NULL && ((qtdata->eqdata & EQCHAIN_TAG)!=0)) {
           // && qtdata->eqref==NULL) {   //qry equivalency list starts here
        if (qtdata->eqref==NULL) { //find rloc overlap
           if (qt.overlap(rloc.start, rloc.end)) {
              rmatch=findRefMatch(qt, rloc, rovlen);
              }
           } else rmatch=qtdata->eqref;
        GffObj* m=loctrack[q]->Get(qi);
        //int lastpq=((CTData*)m->uptr)->eqdata & 0x07FF;
        //traverse linked list of matching transcripts
        while (((CTData*)m->uptr)->eqnext!=NULL) {
           m=((CTData*)m->uptr)->eqnext;
           if (rmatch!=NULL) {
             ((CTData*)m->uptr)->addOvl('=',rmatch,rovlen);
             }
           //lastpq = ((CTData*)m->uptr)->eqdata & 0x07FF;
           } //traverse qry data sets
        if (rmatch!=NULL) continue;
        } //equivalence class (chain of intron-matching)
    //if ((qtdata->eqdata & EQCHAIN_TAGMASK)!=0) continue; //part of a matching chain, dealt with previously

    //--------- qry mrna not in a '=' matching clique
    if (qtdata->eqref==NULL) { //find any rloc overlap
       if (qt.overlap(rloc.start, rloc.end)) {
          rmatch=findRefMatch(qt, rloc, rovlen);
          if (rmatch==NULL) {
            //not an ichain match, look for other codes
            GffObj* rovl=NULL;
            int rovlen=0;
            //char ovlcode=
            getRefOvl(qt, rloc,rovl,rovlen);
            }
          }
       }
     else rmatch=qtdata->eqref;
    } //for each qry transcript
  }//for each qry dataset
}


bool inPolyRun(char strand, GffObj& m, GList<GLocus>* rloci, int& rlocidx) {
 if (rloci==NULL || rloci->Count()==0) return false;
 if (rlocidx<0 || abs((int)(rloci->Get(rlocidx)->start-m.start))>40000){
     GLocus floc;
     floc.start=m.start;
     floc.end=m.end;
     rloci->Found(&floc,rlocidx);
     if (rlocidx>=rloci->Count()) rlocidx=rloci->Count()-1;
     }
 GLocus* rloc=rloci->Get(rlocidx);
 //make sure rloc is the closest upstream locus
 if (strand=='+') {
    while ((int)(m.start-rloc->end)<-4) { //reposition rlocidx if needed
          if (rlocidx==0) return false;
          rlocidx--;
          rloc=rloci->Get(rlocidx);
          }
    int rd=(int)(m.start-rloc->end);
    int ridx=rlocidx;
    while (ridx<rloci->Count()-1) {
        ridx++;
        int newrd=(int)(m.start-rloci->Get(ridx)->end);
        if (newrd>0 && newrd<rd) {
            rlocidx=ridx;
            rloc=rloci->Get(rlocidx);
            rd=newrd;
            }
         else break;
        }
    return (m.end>rloc->end && m.start<rloc->end+polyrun_range);
    } //forward strand
 else { //reverse strand
   while ((int)(rloc->start-m.end)<-4) { //reposition rlocidx if needed
         if (rlocidx==rloci->Count()-1) return false;
         rlocidx++;
         rloc=rloci->Get(rlocidx);
         }
   int rd=(int)(rloc->start-m.end);
   int ridx=rlocidx;
   while (ridx>0) {
       ridx--;
       int newrd=rloci->Get(ridx)->start-m.end;
       if (newrd>0 && newrd<rd) {
           rlocidx=ridx;
           rloc=rloci->Get(rlocidx);
           rd=newrd;
           }
        else break;
       }
    return (m.start<rloc->start && m.end+polyrun_range>rloc->start);
    }
}

CTData* getBestOvl(GffObj& m) {
 //CTData* mdata=(CTData*)m.uptr;
 //return mdata->getBestCode();
  if ( ((CTData*)m.uptr)->ovls.Count()>0)
     return (CTData*)m.uptr;
  return NULL;
}

void reclass_mRNAs(char strand, GList<GffObj>& mrnas, GList<GLocus>* rloci, GFaSeqGet *faseq) {
  int rlocidx=-1;
  for (int i=0;i<mrnas.Count();i++) {
    GffObj& m=*mrnas[i];
    char ovlcode=((CTData*)m.uptr)->getBestCode();
    if (ovlcode=='u' || ovlcode=='i' || ovlcode==0) {
      if (inPolyRun(strand, m, rloci, rlocidx)) {
         ((CTData*)m.uptr)->addOvl('p',rloci->Get(rlocidx)->mrna_maxcov);
         }
      else { //check for repeat content
         if (faseq!=NULL) {
            int seqlen;
            char* seq=m.getSpliced(faseq, false, &seqlen);
            //get percentage of lowercase
            int numlc=0;
            for (int c=0;c<seqlen;c++) if (seq[c]>='a') numlc++;
            if (numlc > seqlen/2)
               ((CTData*)m.uptr)->addOvl('r');
            GFREE(seq);
            }
         }
      } //for unassigned class
  }//for each mrna

}

void reclassLoci(char strand, GList<GLocus>& qloci, GList<GLocus>* rloci, GFaSeqGet *faseq) {
  for (int ql=0;ql<qloci.Count();ql++) {
    reclass_mRNAs(strand, qloci[ql]->mrnas, rloci, faseq);
    //find closest upstream ref locus for this q locus
  } //for each locus
}

//for a single genomic sequence, all qry data and ref data is stored in gtrack
void umrnaReclass(int qcount,  GSeqTrack& gtrack, FILE** ftr, GFaSeqGet* faseq=NULL) {

  for (int q=0;q<qcount;q++) {
    if (gtrack.qdata[q]==NULL) continue; //no transcripts in this q dataset for this genomic seq
    reclassLoci('+', gtrack.qdata[q]->loci_f, gtrack.rloci_f, faseq); //, ftr[q]);
    reclassLoci('-', gtrack.qdata[q]->loci_r, gtrack.rloci_r, faseq);
    reclass_mRNAs('+', gtrack.qdata[q]->umrnas, gtrack.rloci_f, faseq);
    reclass_mRNAs('-', gtrack.qdata[q]->umrnas, gtrack.rloci_r, faseq);
    // print all tmap data here here:
    // header:
    for (int i=0;i<gtrack.qdata[q]->tdata.Count();i++) {
      CTData* mdata=gtrack.qdata[q]->tdata[i];
      if (mdata->mrna==NULL) continue; //invalidated -- removed earlier
      //GLocus* rlocus=NULL;
      mdata->classcode='u';
      GffObj* ref=NULL;
      if (mdata->ovls.Count()>0) {
            mdata->classcode=mdata->ovls[0]->code;
            ref=mdata->ovls[0]->mrna;
            }
      //if (mdata->classcode<33) mdata->classcode='u';      
      if (mdata->classcode<47) mdata->classcode='u'; // if 0, '-' or '.'
      if (ref!=NULL) {
              fprintf(ftr[q],"%s\t%s\t",getGeneID(ref),ref->getID());
              //rlocus=((CTData*)(ref->uptr))->locus;
              }
          else fprintf(ftr[q],"-          \t-          \t");
      //fprintf(ftr[q],"%c\t%s\t%d\t%8.6f\t%8.6f\t%d\n", ovlcode, mdata->mrna->getID(),
      //    iround(mdata->mrna->gscore/10), mdata->FPKM, mdata->cov, mdata->mrna->covlen);
      const char* mlocname = (mdata->locus!=NULL) ? mdata->locus->mrna_maxcov->getID() : mdata->mrna->getID();
      fprintf(ftr[q],"%c\t%s\t%s\t%d\t%8.6f\t%8.6f\t%8.6f\t%8.6f\t%d\t%s\n", mdata->classcode, getGeneID(mdata->mrna), mdata->mrna->getID(),
          iround(mdata->mrna->gscore/10), mdata->FPKM, mdata->conf_lo,mdata->conf_hi, mdata->cov, mdata->mrna->covlen, mlocname);
    }
  }
 //delete faseq;
}

void buildXLoci(GTrackLocus& loctrack, int qcount, GSeqTrack& gtrack, char strand,
    GList<GXLocus>* retxloci=NULL) {
  GList<GXLocus>* dest_xloci=NULL;
  GList<GXLocus> tmpxloci(true,false,true); //local set of newly created xloci
  GList<GXLocus>* xloci=&tmpxloci;
  if (strand=='+') {
       dest_xloci=& gtrack.xloci_f;
       }
    else if (strand=='-') {
      dest_xloci = & gtrack.xloci_r;
      }
   else dest_xloci= & gtrack.xloci_u;

  if (retxloci==NULL) {
     //if no return set of build xloci was given
     //take it as a directive to work directly on the global xloci
     xloci=dest_xloci;
     dest_xloci=NULL;
   }

 for (int q=-1;q<qcount;q++) {
   GList<GLocus>* wrkloci=NULL;
   if (q<0) {
      if (loctrack.rloci.Count()==0) continue;
      //loci=new GList<GLocus>(true,false,false);
      //loci->Add(loctrack.rloc);
      wrkloci = &(loctrack.rloci);
      }
     else {
      if (loctrack[q]==NULL) continue;
      wrkloci = &(loctrack[q]->qloci);
      }
   for (int t=0;t<wrkloci->Count();t++) {
      GLocus* loc=wrkloci->Get(t);
      int xfound=0; //count of parent xloci
      if (loc->xlocus!=NULL) continue; //already assigned a superlocus
      GArray<int> mrgxloci(true);
      for (int xl=0;xl<xloci->Count();xl++) {
         GXLocus& xloc=*(xloci->Get(xl));
         if (xloc.start>loc->end) break;
         if (loc->start>xloc.end) continue;
         if (xloc.add_Locus(loc)) {
            xfound++;
            mrgxloci.Add(xl);
            }
         } //for each existing Xlocus
      //if (xfound<0) continue;
      if (xfound==0) {
         xloci->Add(new GXLocus(loc));
         }
      else if (xfound>1) {
         for (int l=1;l<xfound;l++) {
           int mlidx=mrgxloci[l]-l+1;
           xloci->Get(mrgxloci[0])->addMerge(*(xloci->Get(mlidx)));
           GXLocus* ldel=xloci->Get(mlidx);
           xloci->Delete(mlidx);
           if (retxloci!=NULL)
                 delete ldel;
           }
         }
      }//for each locus
   }//for each set of loci in the region (refs and each qry set)
  //-- add xloci to the global set of xloci unless retxloci was given,
  if (retxloci!=NULL) retxloci->Add(*xloci);
                 else dest_xloci->Add(*xloci);
}

void singleQData(GList<GLocus>& qloci, GList<GTrackLocus>& loctracks) {
 for (int i=0;i<qloci.Count();i++) {
  if (qloci[i]->t_ptr==NULL) {
    GTrackLocus* tloc=new GTrackLocus();
    tloc->addQLocus(qloci[i],0);
    loctracks.Add(tloc);
    }
  }
}

//recheckUmrnas(gtrack.qdata[q1], gtrack.qdata[q1]->mrnas_f,
//            loci                       nloci                      oloci
//   gtrack.qdata[q1]->loci_f, gtrack.qdata[q1]->nloci_f,  gtrack.qdata[q2]->loci_f);

void recheckUmrnas(GSeqData* gseqdata, GList<GffObj>& mrnas,
     GList<GLocus>& loci, GList<GLocus>& nloci,  GList<GLocus>& oloci) {
 GList<GLocus> reassignedLocs(false,false);
 for (int u=0;u<gseqdata->umrnas.Count();u++) {
   for (int l=0;l<oloci.Count();l++) {
     if (gseqdata->umrnas[u]==NULL) break;
     if (gseqdata->umrnas[u]->end<oloci[l]->start) break; //try next umrna
     if (oloci[l]->end<gseqdata->umrnas[u]->start) continue; //try next locus
     if (gseqdata->umrnas[u]->strand=='+' || gseqdata->umrnas[u]->strand=='-') {
       gseqdata->umrnas.Forget(u);
       continue; //already reassigned earlier
       }
     //umrna overlaps locus region
     GffObj* umrna=gseqdata->umrnas[u];
     for (int m=0;m<oloci[l]->mrnas.Count();m++) {
        if (oloci[l]->mrnas[m]->exonOverlap(umrna)) {
            gseqdata->umrnas.Forget(u);
            CTData* umdata=((CTData*)umrna->uptr);
            //must be in a Loci anyway
            if (umdata==NULL || umdata->locus==NULL)
                GError("Error: no locus pointer for umrna %s!\n",umrna->getID());
            for (int i=0;i<umdata->locus->mrnas.Count();i++) {
               GffObj* um=umdata->locus->mrnas[i];
               um->strand=oloci[l]->mrnas[m]->strand;
               }
            reassignedLocs.Add(umdata->locus);
            break;
            }
        } //for each mrna in locus
      } //for each locus
   } //for each umrna
 if (reassignedLocs.Count()>0) {
   gseqdata->umrnas.Pack();
   gseqdata->nloci_u.setFreeItem(false);
   for (int i=0;i<reassignedLocs.Count();i++) {
     GLocus* loc=reassignedLocs[i];
     for (int m=0;m<loc->mrnas.Count();m++) {
        mrnas.Add(loc->mrnas[m]);
        }
     loci.Add(loc);
     nloci.Add(loc);
     gseqdata->nloci_u.Remove(loc);
     }
   gseqdata->nloci_u.setFreeItem(true);
   }
}

//this should be called inside a loctrack !
//   a loctrack should be clustering nloci_u with each strand
//
//
/*
  for (int q1=0;q1<qcount;q1++) {
     for (int q2=0;q2<qcount;q2++) {
       if (q1==q2) continue;
       if (gtrack.qdata[q1]==NULL || gtrack.qdata[q2]==NULL) continue;
         recheckUmrnas(gtrack.qdata[q1], gtrack.qdata[q1]->mrnas_f, gtrack.qdata[q1]->loci_f,
              gtrack.qdata[q1]->nloci_f, gtrack.qdata[q2]->loci_f);
         recheckUmrnas(gtrack.qdata[q1], gtrack.qdata[q1]->mrnas_r, gtrack.qdata[q1]->loci_r,
              gtrack.qdata[q1]->nloci_r, gtrack.qdata[q2]->loci_r);
         }
     }
*/
void umrnasXStrand(GList<GXLocus>& xloci, int qcount, GSeqTrack& gtrack) {
 for (int x=0;x<xloci.Count();x++) {
   if (xloci[x]->strand=='.') continue;
   if (xloci[x]->qloci.Count()==0) continue;
   //go through all qloci in this xlocus
   for (int l = 0; l < xloci[x]->qloci.Count(); l++) {
     char locstrand=xloci[x]->qloci[l]->mrna_maxcov->strand;
     if (locstrand=='.') {
        //this is a umrna cluster
        GLocus* qloc=xloci[x]->qloci[l];
        //we don't really need to update loci lists (loci_f, nloci_f etc.)
        /*
        if (xloci[x]->strand=='+') {
           }
         else { // - strand
           }
        */
        for (int i=0;i<qloc->mrnas.Count();i++) {
           qloc->mrnas[i]->strand=xloci[x]->strand;
           int uidx=gtrack.qdata[qloc->qfidx]->umrnas.IndexOf(qloc->mrnas[i]);
           if (uidx>=0) {
                gtrack.qdata[qloc->qfidx]->umrnas.Forget(uidx);
                gtrack.qdata[qloc->qfidx]->umrnas.Delete(uidx);
                if (xloci[x]->strand=='+')
                     gtrack.qdata[qloc->qfidx]->mrnas_f.Add(qloc->mrnas[i]);
                   else
                     gtrack.qdata[qloc->qfidx]->mrnas_r.Add(qloc->mrnas[i]);
                }
           }
        } //unknown strand
     } //for each xloci[x].qloci (l)

   } //for each xloci (x)
}

//cluster loci across all datasets
void xclusterLoci(int qcount, int gsid, char strand, GSeqTrack& gtrack, FILE* fl) {
	//gtrack holds data for all input qry datasets for a chromosome/contig
	//cluster QLoci
	GList<GTrackLocus> loctracks(true,true,false);
	//all vs all clustering across all qry data sets + ref
   //one-strand set of loci from all datasets + ref loci
  //GList<GLocus> all_loci(true,false,false);
  GList<GLocus>* wrkloci=NULL;
  //build xloci without references first
  //then add references only if they overlap an existing xloci
  int nq=0;
 	for (int q=0;q<=qcount+1;q++) {
    bool refcheck=false;
    if (q==qcount) { // check the unoriented loci
       while (nq<qcount &&
              (gtrack.qdata[nq]==NULL || gtrack.qdata[nq]->nloci_u.Count()==0))
                 nq++;
       if (nq<qcount) {
             wrkloci=&(gtrack.qdata[nq]->nloci_u);
             nq++;
             if (nq<qcount) q--; //so we can fetch the next nq in the next q cycle
             }
       }
    else if (q==qcount+1) { // check the reference loci
           if (strand=='+') wrkloci=gtrack.rloci_f;
                       else wrkloci=gtrack.rloci_r;
           if (wrkloci==NULL) break; //no ref loci here
           refcheck=true;
           }
     else  {
    	 if (gtrack.qdata[q]==NULL) continue;
       if (strand=='+') wrkloci=&(gtrack.qdata[q]->loci_f);
          else if (strand=='-') wrkloci=&(gtrack.qdata[q]->loci_r);
         }
   // now do the all-vs-all clustering thing:
   for (int t=0;t<wrkloci->Count();t++) {
      GLocus* loc=wrkloci->Get(t);
      int xfound=0; //count of parent loctracks
      if (loc->t_ptr!=NULL) continue; //already assigned a loctrack
      GArray<int> mrgloctracks(true);
      for (int xl=0;xl<loctracks.Count();xl++) {
         GTrackLocus& trackloc=*loctracks[xl];
         if (trackloc.start>loc->end) break;
         if (loc->start>trackloc.end) continue;
         if (trackloc.add_Locus(loc)) {
            xfound++;
            mrgloctracks.Add(xl);
            }
         } //for each existing Xlocus
      //if (xfound<0) continue;
      if (xfound==0) {
         if (!refcheck) //we really don't care about ref-only clusters
           loctracks.Add(new GTrackLocus(loc));
         }
      else if (xfound>1) {
         for (int l=1;l<xfound;l++) {
           int mlidx=mrgloctracks[l]-l+1;
           loctracks.Get(mrgloctracks[0])->addMerge(loctracks[mlidx], qcount, loc);
           loctracks.Delete(mlidx);
           }
         }
      }//for each wrklocus
     } //for each set of loci (q)
 	//loctracks is now set with all x-clusters on this strand
 for (int i=0;i<loctracks.Count();i++) {
    if (!loctracks[i]->hasQloci)
          continue; //we really don't care here about reference-only clusters
		GTrackLocus& loctrack=*loctracks[i];
		//fprintf(fl,"-      \t%s:%d-%d(%c)", getGSeqName(gsid), loctrack.start,loctrack.end,strand);
		findTMatches(loctrack, qcount);
    for (int rl=0; rl < loctrack.rloci.Count(); rl++) {
    		findTRMatch(loctrack, qcount, *(loctrack.rloci[rl]));
       }
    GList<GXLocus> xloci(false,false,false);
		buildXLoci(loctrack, qcount, gtrack, strand, &xloci);
    //the newly created xloci are in xloci
    umrnasXStrand(xloci,qcount,gtrack);
    //also merge these xloci into the global list of xloci
    for (int l=0; l < xloci.Count(); l++) {
       if (xloci[l]->strand=='+') {
           gtrack.xloci_f.Add(xloci[l]);
           }
          else if (xloci[l]->strand=='-') {
              gtrack.xloci_r.Add(xloci[l]);
              }
            else gtrack.xloci_u.Add(xloci[l]);
      }
	  }//for each xcluster
}


void printRefMap(FILE** frs, int qcount, GList<GLocus>* rloci) {
	if (rloci==NULL) return;

	for (int l=0;l<rloci->Count(); l++) {
		for (int r=0;r<rloci->Get(l)->mrnas.Count(); r++) {
			GffObj& ref = *(rloci->Get(l)->mrnas[r]);
			CTData* refdata = ((CTData*)ref.uptr);
			GStr* clist = new GStr[qcount];
			GStr* eqlist = new GStr[qcount];
			for (int i = 0; i<refdata->ovls.Count(); i++) {
				GffObj* m=refdata->ovls[i]->mrna;
				char ovlcode=refdata->ovls[i]->code;
				if (m==NULL) {
					GMessage("Warning: NULL mRNA found for ref %s with ovlcode '%c'\n",
							 ref.getID(), refdata->ovls[i]->code);
					continue;
				}
				int qfidx = ((CTData*)m->uptr)->qset;
				if (ovlcode == '=') {
					eqlist[qfidx].append(getGeneID(m));
					eqlist[qfidx].append('|');
					eqlist[qfidx].append(m->getID());
					eqlist[qfidx].append(',');
				}
				else if (ovlcode == 'c') {
					clist[qfidx].append(getGeneID(m));
					clist[qfidx].append('|');
					clist[qfidx].append(m->getID());
					clist[qfidx].append(',');
				}
			}//for each reference overlap
			for (int q=0;q<qcount;q++) {
				if (!eqlist[q].is_empty()) {
					eqlist[q].trimR(',');
					fprintf(frs[q],"%s\t%s\t=\t%s\n", getGeneID(ref), ref.getID(),eqlist[q].chars());
				}
				if (!clist[q].is_empty()) {
					clist[q].trimR(',');
					fprintf(frs[q],"%s\t%s\tc\t%s\n",getGeneID(ref), ref.getID(),clist[q].chars());
				}
			}
			delete[] clist;
			delete[] eqlist; 
		}// ref loop
	}//ref locus loop
}

void trackGData(int qcount, GList<GSeqTrack>& gtracks, GStr& fbasename, FILE** ftr, FILE** frs) {
  FILE* f_ltrack=NULL;
  /* s.append(".locus_tracking.tab");
   f_ltrack=fopen(s.chars(),"w");
  if (f_ltrack==NULL) GError("Error creating file %s\n",s.chars());
  //print header:
  fprintf(f_ltrack,"# ref_id\tlocation\t");
  for (int q=0;q<qcount;q++) {
    fprintf(f_ltrack,"\tq%d=%s", q+1, qryfiles[q]->chars());
    }

  fprintf(f_ltrack,"\tref_descr\n");
  s=fbasename;
  */
  FILE* f_itrack=NULL;
  FILE* f_ctrack=NULL;
  FILE* f_xloci=NULL;
  int cnum=0; //consensus numbering for printITrack()
  GStr s=fbasename;
  //this doesn't make much sense if only 1 input file was given:
  if (qcount>1) {
    s.append(".tracking");
    f_itrack=fopen(s.chars(),"w");
    if (f_itrack==NULL) GError("Error creating file %s !\n",s.chars());
    s=fbasename;
    s.append(".combined.gtf");
    f_ctrack=fopen(s.chars(),"w");
    if (f_ctrack==NULL) GError("Error creating file %s !\n",s.chars());
    s=fbasename;
    }
  s.append(".loci");
  f_xloci=fopen(s.chars(),"w");
  if (f_xloci==NULL) GError("Error creating file %s !\n",s.chars());

  for (int g=0;g<gtracks.Count();g++) { //for each genomic sequence
    GSeqTrack& gseqtrack=*gtracks[g];

    xclusterLoci(qcount, gseqtrack.gseq_id, '+', gseqtrack, f_ltrack);
    xclusterLoci(qcount, gseqtrack.gseq_id, '-', gseqtrack, f_ltrack);

    //count XLoci, setting their id
    numXLoci(gseqtrack.xloci_f, xlocnum);
    numXLoci(gseqtrack.xloci_r, xlocnum);
    numXLoci(gseqtrack.xloci_u, xlocnum);
    //transcript accounting: for all those transcripts with 'u' or 0 class code
    // we have to check for polymerase runs 'p' or repeats 'r'

    GFaSeqGet *faseq=NULL;
    if (fastadir) {
       char* sfile=getFastaFile(gseqtrack.gseq_id);
       if (sfile!=NULL) {
          if (verbose)
             GMessage("Processing sequence from fasta file '%s'\n",sfile);
          faseq=new GFaSeqGet(sfile,checkFasta);
          faseq->loadall();
          GFREE(sfile);
          }
       }

    umrnaReclass(qcount, gseqtrack, ftr, faseq);

    // print transcript tracking (ichain_tracking)
    if (qcount>1)
       for (int q=0;q<qcount;q++) {
         if (gseqtrack.qdata[q]==NULL) continue;
         printITrack(f_itrack, gseqtrack.qdata[q]->mrnas_f, qcount, cnum);
         printITrack(f_itrack, gseqtrack.qdata[q]->mrnas_r, qcount, cnum);
         //just for the sake of completion:
         printITrack(f_itrack, gseqtrack.qdata[q]->umrnas, qcount, cnum);
         }
    //print XLoci and XConsensi within each xlocus
    //also TSS clustering and protein ID assignment for XConsensi
    printXLoci(f_xloci, f_ctrack, qcount, gseqtrack.xloci_f, faseq);
    printXLoci(f_xloci, f_ctrack, qcount, gseqtrack.xloci_r, faseq);
    printXLoci(f_xloci, f_ctrack, qcount, gseqtrack.xloci_u, faseq);

    printRefMap(frs, qcount, gseqtrack.rloci_f);
    printRefMap(frs, qcount, gseqtrack.rloci_r);
    if (faseq!=NULL) delete faseq;
    }

  for (int q=0;q<qcount;q++) { fclose(ftr[q]); fclose(frs[q]); }
  if (f_ltrack!=NULL) fclose(f_ltrack);
  if (f_itrack!=NULL) fclose(f_itrack);
  if (f_ctrack!=NULL) fclose(f_ctrack);
  if (f_xloci!=NULL) fclose(f_xloci);

}
